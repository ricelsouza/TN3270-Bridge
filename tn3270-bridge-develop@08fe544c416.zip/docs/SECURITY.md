# Security Standard

## Production Baseline

- Keep `tn3270Bridge.requireApiToken` enabled.
- Use TLS on the mainframe connection, normally port 992.
- Keep `tls.rejectUnauthorized=true` and configure the corporate CA bundle.
- Store login passwords and private-key passphrases only in VS Code SecretStorage.
- Keep `tn3270Bridge.enableDiagnostics=false` except during supervised diagnosis.
- Run agents with least-privilege mainframe IDs and separate production profiles.
- Require human approval for MCP tools marked `destructiveHint=true`.

## Local API

The bridge binds to `127.0.0.1`. Localhost is not treated as authentication:
every endpoint except `/health` requires either:

```text
Authorization: Bearer <token>
```

or `X-TN3270-Token`. The 256-bit token is generated once and stored under
`tn3270.apiToken` in SecretStorage. Browser-originated requests and CORS
preflight requests are rejected.

MCP and the bundled CLI never require users to handle this token. They request
it from the Extension Host over a user-scoped local IPC channel. Windows uses a
named pipe under the current logon identity; Linux/macOS use a Unix-domain
socket with mode `0600`. The token exists only in process memory for the request.

Direct bearer-token export is retained only for legacy REST scripts.

GitHub Copilot uses the VS Code MCP provider and therefore retains the editor's
mandatory first-use trust decision. Claude Code registration is user-scoped and
created only when no unmanaged server with the same name exists.

## Data Protection

- Hidden 3270 fields are masked in full screens, regions, text slices and MCP output.
- Login logs are recursively redacted before entering the Output Channel.
- Raw protocol diagnostics are disabled by default and never return the last outbound buffer.
- Request bodies are limited to 10 MiB.
- Dataset and member names are validated before being sent to ISPF.

## Operational Controls

Dataset writes cancel the ISPF edit session if all requested lines cannot be
inserted. Agents must inspect `linesWritten` and the returned panel before
continuing. Production change workflows should additionally use site-standard
dataset versioning, approvals and RACF controls.

Rotate the API token by deleting `tn3270.apiToken` from SecretStorage and
reloading VS Code. A new token is generated automatically.