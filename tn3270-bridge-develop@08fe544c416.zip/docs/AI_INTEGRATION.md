# AI Integration

The bundled MCP server is the supported integration for GitHub Copilot and
Claude Code. REST remains available for scripts and diagnostics.

## Prerequisites

1. Install the 2.2.0 VSIX and reload VS Code.
2. On first Copilot use, review and accept the mandatory VS Code MCP trust prompt.

No MCP configuration, token, environment variable or setup command is required.

## VS Code / GitHub Copilot

The extension contributes a native MCP server definition through the stable VS
Code API. Copilot discovers and starts it automatically. VS Code requires a
one-time trust confirmation before any newly installed local MCP server runs.

## Claude Code

When `claude` is available on `PATH`, extension activation registers the bundled
server automatically at user scope, making it available in every project. An
existing registration not owned by the extension is preserved. Restart an
already-running Claude Code session after installing or updating the VSIX.

Providing `http://127.0.0.1:7327` to Claude Code is not required and does not
bypass REST authentication. Claude should call the registered `mainframe_*` MCP
tools; those tools obtain the bearer token transparently from the same-user
credential broker.

To verify discovery after reload, `claude mcp get tn3270-bridge` should show the
user-scoped stdio server. If Claude Code was open during installation, start a
new session so it reloads the MCP registry.

## Terminal Automation

Use the bundled CLI instead of constructing authenticated REST headers:

```powershell
node out/bridge-cli.js GET /status
node out/bridge-cli.js GET '/screen?nonblank=true'
node out/bridge-cli.js POST /key/PF3

# Use stdin for JSON bodies on PowerShell/RTK to avoid native quoting rules
'{"fieldName":"OPTION","text":"3.4","aid":"ENTER"}' |
  node out/bridge-cli.js POST /send -
```

`TN3270_BRIDGE_TOKEN` remains an optional override for legacy automation only.

## Tools

- `mainframe_status`, `mainframe_sessions`, `mainframe_read_screen`
- `mainframe_login`, `mainframe_send`, `mainframe_wait`, `mainframe_exec`
- `mainframe_read_dataset`, `mainframe_write_dataset`
- `mainframe_submit_job`, `mainframe_interrupt`

Agents should read status before acting, use semantic fields instead of fixed
coordinates, wait without sleeps, inspect `panelId` and `ispfMessage` after
every mutation, and stop when the observed panel differs from the expected one.