# Migration from 1.8 to 2.0

Version 2.0 intentionally breaks unauthenticated REST clients.

1. Install 2.0 and reload VS Code.
2. Replace direct `curl` agent workflows with MCP or `bridge-cli.js`; both
	authenticate transparently in 2.0.2.
3. Legacy REST scripts may continue sending `Authorization: Bearer <token>`.
5. Replace CP1047/CP875 settings with CP037 or CP500 until verified tables ship.
6. Keep diagnostics disabled in normal operation.

`GET /health` remains unauthenticated for local process readiness checks.
All operational endpoints, including `/status`, require authentication.