# Release Process

Every source-code, behavior, security, packaging or documentation correction
must produce a new semantic version and a new VSIX. Existing VSIX files and
published releases must never be overwritten.

## Required Steps

1. Choose the next semantic version. Use patch for compatible corrections,
   minor for compatible features, and major for breaking changes.
2. Update `package.json`, `package-lock.json` and runtime version responses.
3. Add `## Release X.Y.Z` to `README.md` with user-visible changes, migration
   impact and validation performed.
4. Update any affected detailed documentation.
5. Run `npm run check`.
6. Run `npm run package` and retain `tn3270-bridge-X.Y.Z.vsix`.
7. Inspect the VSIX file list for source, secrets, tests or operational data.
8. Publish a new repository release with the matching VSIX. Never replace an
   older release artifact.

The `verify-release` gate rejects packaging when the README has no section for
the manifest version or mandatory corporate documentation is absent.