# Test and Release Gates

Run the complete local gate:

```powershell
npm ci
npm run check
npm run package
```

`npm run check` requires TypeScript compilation, Node integration tests and
both extension/MCP bundles to succeed.

The automated suite covers:

- hidden-field masking for positioned reads;
- CP037 and CP500 conversion vectors;
- DSN/member injection rejection;
- constant-time API token comparison;
- recursive login-secret redaction;
- authenticated REST transport and error propagation.
- transparent same-user broker authentication through REST, CLI and MCP.
- native VS Code MCP provider compilation and secret-free Claude registration arguments.

Before corporate release, test against a non-production LPAR:

1. TLS connection and certificate validation.
2. Profile login without password in agent context.
3. ISPF navigation with semantic field resolution.
4. Named-session isolation.
5. Read a disposable PDS member.
6. Write and reread a disposable PDS member, then compare bytes.
7. Submit harmless JCL and verify its job ID/status in SDSF.
8. Interrupt a deliberately long-running test command.
9. Disconnect all sessions and verify no socket remains.

Never run destructive E2E cases against customer production datasets.