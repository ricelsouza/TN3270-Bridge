const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const readme = fs.readFileSync(path.join(root, 'README.md'), 'utf8');
const releaseHeading = `## Release ${manifest.version}`;

if (!readme.includes(releaseHeading)) {
  throw new Error(`README.md must contain "${releaseHeading}" before packaging`);
}

for (const required of [
  'docs/AI_INTEGRATION.md',
  'docs/SECURITY.md',
  'docs/TESTING.md',
  'docs/RELEASING.md',
]) {
  if (!fs.existsSync(path.join(root, required))) {
    throw new Error(`Required release documentation is missing: ${required}`);
  }
}

console.log(`Release metadata verified for ${manifest.version}`);