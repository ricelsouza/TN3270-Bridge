const esbuild = require('esbuild');
const fs = require('fs');

const watch = process.argv.includes('--watch');

if (!watch) fs.rmSync('out', { recursive: true, force: true });

/** @type {import('esbuild').BuildOptions} */
const options = {
  entryPoints: {
    extension: 'src/extension.ts',
    'mcp-server': 'src/mcp-server.ts',
    'bridge-cli': 'src/bridge-cli.ts',
  },
  bundle: true,
  outdir: 'out',
  external: ['vscode'],
  format: 'cjs',
  platform: 'node',
  target: 'node18',
  sourcemap: false,
  minify: false,
};

if (watch) {
  esbuild.context(options).then(ctx => ctx.watch());
} else {
  esbuild.build(options).catch(() => process.exit(1));
}
