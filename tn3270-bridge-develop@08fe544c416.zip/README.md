# TN3270 Mainframe Bridge

**AI-operable TN3270 bridge for z/OS mainframe interaction.**

Version 2.0 is the corporate hardening release. The REST API is protected by a
SecretStorage-backed token, agents authenticate transparently through local
same-user IPC, and an MCP server is bundled for GitHub Copilot and Claude Code. See
`docs/AI_INTEGRATION.md`, `docs/SECURITY.md`, and `docs/MIGRATION_2.0.md`.

## Release 2.6.0

Three feature bundles that move the extension beyond "single interactive
session" into an enterprise multi-tenant tool.

**Bundle AI — structured extraction + multi-session tabs**

- `mainframe_extract` MCP tool (new): three modes — `regex` returns matches
  with capture groups + row/col; `labels` finds a label and returns the value
  that follows it on the same line (ISPF `Name . . . value` shape); `anchor`
  returns lines strictly between two anchor patterns. Cheaper for Copilot /
  Claude Code agents than re-parsing the full screen.
- `POST /screen/extract` endpoint on the bridge for non-MCP callers.
- **Multi-session tabs** on the editor panel. Backend already supported
  named sessions via `extraSessions`; the editor panel now renders a chip
  strip at the top — one per session, `+` opens a new named session via
  a prompt (`host:port[?tls]`), `×` closes one, click switches. Each tab
  keeps its own connection, screen and cursor.

**Bundle OMVS — Fix D dedicated terminal-mode renderer**

- Automatic detection of OMVS / NVT / SSCP-LU line-oriented sessions via
  `Tn3270Client.isTerminalMode()` (panel id `TSO`/`OMVS` OR unformatted
  screen without TN3270E).
- Scrollback buffer expanded to 40 frames in terminal mode (was 10 across
  the board).
- Dedicated scrollable renderer with `<pre>` layout, single command line
  at the bottom, no click-to-position (irrelevant in line mode), and
  auto-scroll to bottom on new content (tail-f style).

**Bundle Produção — auto-reconnect + session recording**

- **Auto-reconnect** (opt-in via `tn3270Bridge.autoReconnect.enabled`).
  On a passive socket drop (network hiccup, host FIN, TLS error), the
  bridge retries with exponential backoff (2s → 4s → 8s → 16s → 32s) up
  to `autoReconnect.maxAttempts` (default 5) using the exact host/port/LU
  /TLS of the last successful connect. User-initiated disconnects never
  trigger reconnect. Status bar shows `$(sync~spin) TN3270: reconnecting
  (n/N)…` while retrying.
- **Session recording** (opt-in via `tn3270Bridge.recording.enabled`).
  Every screenUpdate is captured to an in-memory ring buffer (bounded by
  `recording.maxFrames`, default 2000). PII masking is on by default and
  removes password fields on 3270 logon panels, credit-card-shaped numbers
  and `Bearer:` / `Authorization:` lines. Recordings are memory-only until
  the user runs **TN3270 Bridge: Save Session Recording…** — writes JSONL
  with one metadata line then one frame per line, suitable for `tail`/
  `grep`/replay tooling.

**Other**

- Bumped bridge status/version response and MCP server identity to `2.6.0`.
- Revalidated compile, REST/CLI/MCP integration tests, bundle and
  packaging gates.

## Release 2.5.0

- **Click the 3270 screen to position the cursor** (Fix B) — every line in
  both the sidebar and the editor panel now carries a data-row attribute
  and reacts to clicks. Column is derived from the click X-offset within
  the line's bounding rect. Matches the behavior of Mocha TN3270 / IBM
  Personal Communications / x3270 — click the `Option ===>` prompt, click
  a NP action-code slot in SDSF ST, click any input field, and the 3270
  cursor moves there. The subsequent keystrokes are typed at the picked
  position.
- **Focus theft between sidebar and editor eliminated** (Fix A) — the
  earlier auto-focus of the text input on every render was stealing focus
  each 1.5–2 s between the two panels, dropping keystrokes and making
  OMVS unusable. The panels now use per-webview `vscode.setState` to
  remember whether the user was typing THERE, and only restore focus in
  that case. A plain auto-refresh no longer fights for focus.
- **Sidebar becomes a compact companion when the editor panel is open**
  (Fix C) — no duplicate 3270 screen, no duplicate input area, no AID
  keys competing with the editor. The sidebar shows status, security
  badge, keyboard-lock RESET, field navigation and quick AID actions.
  Close the editor tab and the sidebar returns to full-interactive mode
  automatically (fires `EditorPanelProvider.onVisibilityChange`).
- Bumped bridge status/version response and MCP server identity to `2.5.0`.
- Revalidated compile, REST/CLI/MCP integration tests, bundle and
  packaging gates.

## Release 2.4.0

- **Saved sessions**: named connection profiles that persist across VS Code
  restarts and follow the user across machines via VS Code Settings Sync.
  Mirrors the enterprise-emulator UX (IBM Personal Communications,
  Mocha TN3270). New "📌 Saved sessions" section at the top of the
  sidebar Connect form:
  - Dropdown lists all saved sessions sorted by most-recently-used.
  - **Connect** loads and dials in one click.
  - **💾 Save…** captures the current form values under a user-supplied
    name. If the form was seeded from an existing session, the save
    updates it in place.
  - **🗑** deletes the selected session (with confirm).
- New Command Palette entries: `TN3270 Bridge: Pick Saved Session…`,
  `Save Current Session…`, `Manage Saved Sessions…` (rename / delete /
  duplicate).
- Storage: `context.globalState` under key `tn3270Bridge.savedSessions`,
  opted into Settings Sync via `setKeysForSync`. Not in `settings.json`
  because the existing `tn3270Bridge.loginProfiles` config lives there
  with a completely different (login-script) shape.
- **Pin-portability**: when a saved session's host is trusted via the
  cert-error dialog, the SHA-256 fingerprint is mirrored INTO the saved
  session (pins are integrity anchors, not secrets), so a Trust decision
  on one machine follows to another via Sync. A local per-machine copy
  remains in SecretStorage for backwards compatibility.
- **Locked-keyboard UX fix**: after a slow host response caused
  `sendAID` to time out, the sidebar was showing 🔒 LOCKED forever and
  Enter no longer advanced screens. Fixes:
  - On AID timeout, the client now unlocks the keyboard automatically
    (see `src/tn3270-client.ts` — the `sendAID` timeout branch).
  - New `resetKeyboard()` method — equivalent to the physical 3270 RESET
    key: clears the LOCKED indicator locally without sending anything to
    the host.
  - Sidebar terminal view exposes ⏮ RESET in the AID key row.
  - Status bar `🔒 LOCKED` line is now clickable and runs RESET —
    proximate escape hatch when the user sees the indicator.
- **Idempotent `POST /connect`**: if the bridge is already connected to
  the requested `host:port`, the HTTP endpoint now returns success and
  reuses the existing session instead of tearing it down. Prevents the
  common z/OS gotcha where an AI agent calling `/connect` while the user
  is already logged in via the sidebar caused a rapid FIN+SYN cycle that
  the mainframe rate-limited into `TLS_HANDSHAKE_TIMEOUT`. Pass
  `{"force": true}` in the body to opt out and force a fresh handshake.
- **API layer inherits the sidebar's cert pin**: `resolveTlsOptions` now
  looks up `tn3270.certpin.<host>:<port>` in SecretStorage when the caller
  did not provide a `pinnedFingerprint`. An agent calling `POST /connect
  {"host":"...","port":992,"tls":true}` automatically uses the same
  trusted cert the user pinned in the sidebar — no need to duplicate the
  trust flow or send the SHA-256 through the API.
- **500 ms cooldown** between `disconnectClient()` and the fresh dial so
  the previous socket has time to fully close on both ends. Removes the
  reconnect-storm class of `TLS_HANDSHAKE_TIMEOUT` reports.
- **Bridge autodiscovery for MCP clients and the CLI**: `GET /health`
  now exposes `{ port, connected, host, mainframePort, pid, startedAt,
  extensionPath }` (all wiring metadata, no session data), and
  `BridgeApiClient.discover()` scans `127.0.0.1:7327-7335` in parallel to
  find the right bridge automatically — prefers a bridge already
  connected to a mainframe, then the newest instance. Copilot Chat and
  Claude Code MCP no longer break when VS Code lands the bridge on 7328
  because 7327 was in use; `bridge-cli.js` also picks the live bridge
  without a `TN3270_BRIDGE_URL` env var. Set `TN3270_BRIDGE_URL` to opt
  out of discovery for deterministic wiring.
- Bumped bridge status/version response and MCP server identity to `2.4.0`.
- Revalidated compile, REST/CLI/MCP integration tests, bundle and
  packaging gates.

## Release 2.3.0

- Exposed **TLS directly in the sidebar Connect form** — no more Command Palette
  detour to reach `TN3270 Bridge: Connect with TLS (Secure)`. A `🔒 Use TLS`
  checkbox and preset selector are now the primary connect UX.
- Added TLS presets in the sidebar: Modern verified (TLSv1.2+, OS trust),
  Corporate CA bundle, Legacy host (TLSv1.0+, verified), **Encrypted only
  (≈ Mocha TN3270 "SSL/TLS" checkbox)**, and Custom (uses `tn3270Bridge.tls.*`
  from settings.json).
- **Mocha-parity behavior for self-signed / internal-CA mainframes**: when the
  handshake fails with `TLS_SELF_SIGNED`, `TLS_CA_NOT_TRUSTED`, `TLS_CERT_EXPIRED`
  or `TLS_HOSTNAME_MISMATCH`, the sidebar now offers a one-click **Retry without
  cert verification** dialog (matching what Mocha's SSL checkbox effectively
  does) plus an **Import corporate CA…** shortcut that opens a file picker and
  retries verified against the chosen bundle.
- **SNI-on-IP fix**: when connecting to an IP literal, servername is no longer
  sent (RFC 6066) and altname checking is disabled, so certificates issued for
  the hostname no longer trip `ERR_TLS_CERT_ALTNAME_INVALID`. Chain trust is
  still verified. Explicit SNI overrides keep working.
- **Strictly reactive Telnet negotiation**, aligned with x3270 / IBM Personal
  Communications / Mocha TN3270. Earlier 2.3.0 builds sent a proactive
  `IAC DO/WILL TERMINAL-TYPE/EOR/BINARY` burst after the handshake, which was
  intended to unblock passive servers but actually causes z/OS Communications
  Server TN3270E to back-level or hang (per RFC 2355 §3 — BINARY/EOR are
  IMPLIED by TN3270E, and z/OS treats a proactive burst as an RFC 1576
  legacy-client signature). The client now waits for the server's
  `IAC DO TN3270E` and answers reactively — the pattern proven by the x3270
  reference implementation and every enterprise emulator.
- Resolves the `TN3270_NEGOTIATION_TIMEOUT` observed against real z/OS hosts
  (e.g. Kyndryl PKI environments) where the server was legitimately waiting
  for us to shut up before proceeding.
- **TN3270E constants realigned to RFC 2355 §5** (matches the x3270 reference
  implementation): `IS=0x04` (was `0x00`), `REASON=0x05` (was `0x04`),
  `REJECT=0x06` (was `0x04` — collided with REASON), `ASSOCIATE=0x00` (was
  `0x09`). The wrong values made the client silently ignore the server's
  `DEVICE-TYPE IS <lu>` and `FUNCTIONS IS` responses, so no `FUNCTIONS
  REQUEST` was ever sent and negotiation hung indefinitely.
- **TN3270E subnegotiation handler rewritten to RFC 2355 §6.2 grammar**:
  the payload is `<command> <what> [params...]` — command is `data[0]`, not
  `data[1]` as the earlier code assumed. The switch now correctly dispatches
  `SEND DEVICE-TYPE`, `DEVICE-TYPE IS/REJECT`, and `FUNCTIONS IS/REQUEST`.
  Also extracts and stores the bound LU name from `DEVICE-TYPE IS <term>
  CONNECT <lu>`.
- **Phase-aware timeouts**: the single 30 s wall-clock guard was split into
  a handshake budget and a negotiation budget. Failures now surface as
  `TCP_CONNECT_TIMEOUT` / `TLS_HANDSHAKE_TIMEOUT` / `TN3270_NEGOTIATION_TIMEOUT`
  with targeted hints (port wrong, plain vs TLS, LU/device mismatch) instead
  of a generic timeout.
- **New TLS Diagnose command**: `TN3270 Bridge: Diagnose TLS (host handshake
  report)` — also reachable via a `🔍 Diagnose TLS` button in the sidebar —
  dials the host with cert verification disabled, reports the negotiated
  version, cipher, peer certificate (subject, issuer, validity, SAN, SHA-256)
  and the first bytes the server sends. Interprets common failure modes
  ("port is not TLS", "server requires older TLS") in the report.
- **Certificate pinning (Mocha "trust this cert" parity)**: the cert-error
  dialog now leads with **Trust this cert (pin fingerprint)** — it shows the
  full subject, issuer, validity window and SHA-256, then stores that
  fingerprint under a per-host key in VS Code SecretStorage. Every subsequent
  connect verifies against the pin only, so the corporate CA does NOT need to
  be in the OS trust store yet the connection is authenticated against a
  specific cert (stronger than `rejectUnauthorized: false`).
- **TLS_PIN_MISMATCH error code** surfaces when a pinned host presents a
  different cert (re-issuance or MITM); user can re-run Diagnose TLS and, if
  the new cert is legitimate, click Trust again to update the pin.
- **Deferred verification** so the peer cert is always captured before we
  reject. Previous versions destroyed the socket on Node's chain-trust error
  before we could see the fingerprint — the sidebar now always has the cert
  data to offer for pinning.
- **Handshake budget raised to 20 s** (from 10 s) and phase tracking no
  longer relies on the underlying-socket `connect` event, which fixed
  spurious `TLS_HANDSHAKE_TIMEOUT` errors on slow / jittery corporate VPNs.
- **1.5 s pre-retry delay** avoids the temp lockout some z/OS servers apply
  after a rejected TLS connection.
- Auto-swaps the port between `23` and `992` when the TLS toggle changes so the
  right default is always one click away; users can still override.
- Sidebar and editor terminal panels now show a `🔒 TLS` / `🔓 PLAIN` badge
  with the negotiated version, cipher and peer certificate details on hover.
- Preserved the existing Command Palette flow, the `tn3270Bridge.tls.*`
  configuration keys, per-profile TLS overrides in `loginProfiles`, and the
  SecretStorage-backed passphrase mechanism — no configuration migration needed.
- Insecure profiles (encrypted-only, no cert verification) still require an
  explicit confirmation dialog before connecting.
- Bumped bridge status/version response and MCP server identity to `2.3.0`.
- Revalidated compile, REST/CLI/MCP integration tests, bundle and packaging gates.

## Release 2.2.0

- Added MCP parity for existing REST capabilities without changing REST routes.
- Added masked field inspection, screen find/table/history/read-all, and local
  cursor positioning tools.
- Added named-session create/delete and default connect/disconnect tools.
- Preserved existing send, exec, login, dataset, submit, interrupt, and session
  tools with unchanged names and behavior.
- Classified navigation-only state changes separately from destructive host
  operations in MCP annotations.

## Release 2.1.1

- Fixed automatic Claude Code registration on current Claude CLI versions.
- Places the server name before the variadic `--env` option so activation can
  register `tn3270-bridge` at user scope without user commands or token handling.
- Preserves bearer authentication, the same-user credential broker, MCP and
  SecretStorage behavior without changing the HTTP API.
- Revalidated compile, REST/CLI/MCP integration tests, bundle and packaging gates.

## Release 2.1.0

- Added a native VS Code MCP definition provider. GitHub Copilot discovers the
  mainframe tools directly from the installed extension; no `mcp.json` is needed.
- Added automatic user-scoped Claude Code registration during extension activation.
- Preserves an existing Claude MCP entry if it was not created by this extension.
- Updates extension-managed Claude registration automatically when the VSIX path changes.
- No token, clipboard, environment variable or setup command is required.
- VS Code still displays its mandatory MCP trust confirmation on first use.
- Requires VS Code 1.105 or newer; validated on VS Code 1.129 and Claude Code 2.1.168.

## Release 2.0.3

- Added JSON request bodies over `stdin` to `bridge-cli.js`.
- Eliminated PowerShell and RTK native-argument quoting failures for POST operations.
- Revalidated live read-only navigation on ISPF 3.4, SDSF `ST` and OMVS.
- Confirmed the session returns to `ISR@PRI` connected and unlocked.

## Release 2.0.2

- Removed token copy/paste, prompts and environment variables from normal use.
- Added a same-user IPC credential broker: named pipe on Windows and a `0600`
  Unix-domain socket on Linux/macOS.
- MCP now authenticates automatically with the Extension Host.
- Added `bridge-cli.js` for transparent authenticated terminal automation.
- Added E2E coverage proving REST, CLI and MCP work without a manually supplied token.
- Manual token copy remains available only for legacy direct REST scripts.

## Release 2.0.1

- Added an enforced release gate requiring matching README release notes.
- Added the permanent semantic-version and VSIX retention process.
- Preserved `tn3270-bridge-2.0.0.vsix`; this correction ships as a separate
  `tn3270-bridge-2.0.1.vsix` artifact.
- Revalidated TypeScript, eight automated tests, extension/MCP bundles and npm
  dependency audit.

## Release 2.0.0

- Added bearer-token REST authentication and blocked browser-originated calls.
- Added SecretStorage integration, hidden-field masking and diagnostic redaction.
- Added deterministic multi-session queues and transactional ISPF writes.
- Added CP037/CP500 support, corrected TN3270E model buffer reporting and MCP.
- Added E2E coverage for REST, TN3270 sockets and MCP stdio negotiation.

Connect to IBM mainframes, read 3270 screens, send keystrokes — all via a localhost HTTP API designed for AI agents (GitHub Copilot, Claude, ChatGPT) or terminal automation with `curl`.

![VS Code](https://img.shields.io/badge/VS%20Code-%5E1.105.0-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20Linux%20%7C%20macOS-lightgrey)

---

## Features

- **No External Binaries** — TypeScript TN3270 implementation with audited npm runtime dependencies
- **HTTP REST API** — Localhost server on port `7327` exposing all operations as JSON endpoints
- **MCP and REST** — Typed MCP tools for Copilot/Claude plus an authenticated localhost API
- **Full 3270 Protocol** — Telnet negotiation, TN3270E support, EBCDIC CP-037 translation, all 3270 orders (SBA, SF, SFE, RA, EUA, IC, PT, SA, MF, GE)
- **Screen Parsing** — Read screen text, identify input fields, track cursor position
- **Activity Bar Panel** — Real-time 3270 screen rendering in the VS Code sidebar
- **Editor Panel** — Full-size terminal view in the main editor area (`TN3270 Bridge: Open Terminal in Editor`)
- **Status Bar** — Connection status at a glance
- **Configurable** — Screen dimensions, code page, timeouts, auto-start

---

## Quick Start

### 1. Install

Install from `.vsix` file:
```
code --install-extension tn3270-bridge-2.2.0.vsix
```

### 2. Configure (optional)

Open VS Code Settings and search for `tn3270Bridge`:

| Setting | Default | Description |
|---------|---------|-------------|
| `tn3270Bridge.port` | `7327` | HTTP bridge port |
| `tn3270Bridge.autoStart` | `true` | Start bridge on VS Code launch |
| `tn3270Bridge.defaultHost` | `""` | Default mainframe hostname |
| `tn3270Bridge.defaultPort` | `23` | Default TN3270 port |
| `tn3270Bridge.codePage` | `cp037` | EBCDIC translation table |
| `tn3270Bridge.screenRows` | `24` | Screen rows (Model 2=24, Model 4=43) |
| `tn3270Bridge.screenCols` | `80` | Screen columns (Model 2=80, Model 5=132) |
| `tn3270Bridge.keyboardTimeout` | `30000` | Host response timeout (ms) |

### 3. Connect

Use the bundled CLI for terminal automation; it obtains the bearer token from
the same-user broker automatically:

```powershell

node out/bridge-cli.js GET '/screen?nonblank=true'
```powershell
'{"host":"mainframe.example.com","port":992,"tls":true}' |
'{"text":"TSO MYUSER","aid":"ENTER"}' | node out/bridge-cli.js POST /send -
Or use the Command Palette: `TN3270 Bridge: Connect to Mainframe`

node out/bridge-cli.js POST /key/PF3
```bash
# Read the screen
'{"text":"READY","timeout":10000}' | node out/bridge-cli.js POST /wait -
# Send text and press Enter
curl -X POST http://localhost:7327/send \
  -H "Content-Type: application/json" \
  -d '{"text": "TSO MYUSER", "aid": "ENTER"}'

# Press PF3 (go back)
curl -X POST http://localhost:7327/send \
  -d '{"aid": "PF3"}'

# Wait for specific text to appear
curl -X POST http://localhost:7327/wait \
  -d '{"text": "READY", "timeout": 10000}'
```

---

## HTTP API Reference

The bridge exposes a REST API on `http://127.0.0.1:7327` (localhost only — no external access).
Every endpoint except `/health` requires bearer authentication by default.
MCP and `bridge-cli.js` obtain it transparently; a URL by itself does not grant
Claude Code access. Direct REST examples are for legacy scripts that explicitly
supply `Authorization: Bearer <token>` or `X-TN3270-Token`.

### `GET /status`

Returns bridge and connection status.

**Response:**
```json
{
  "bridge": "running",
  "connected": true,
  "connection": {
    "status": "connected",
    "host": "mainframe.example.com",
    "port": 23,
    "tn3270e": true,
    "deviceType": "IBM-3278-2-E"
  },
  "screen": {
    "rows": 24,
    "cols": 80,
    "cursorRow": 1,
    "cursorCol": 1,
    "fieldCount": 12,
    "keyboardLocked": false
  }
}
```

### `POST /connect`

Connect to a mainframe TN3270 service.

**Body:**
```json
{
  "host": "mainframe.example.com",
  "port": 23
}
```

**Response:**
```json
{
  "success": true,
  "message": "Connected to mainframe.example.com:23",
  "screen": ["line1...", "line2...", "...24 lines..."]
}
```

### `POST /disconnect`

Close the current connection.

**Response:**
```json
{ "success": true, "message": "Disconnected" }
```

### `GET /screen`

Read the current 3270 screen content.

**Response:**
```json
{
  "lines": ["line 1 content...", "...", "line 24 content..."],
  "text": "full screen as single string with newlines",
  "cursor": { "row": 5, "col": 20 },
  "keyboardLocked": false
}
```

### `GET /screen/fields`

List all screen fields (input and protected).

**Response:**
```json
{
  "fields": [
    { "index": 0, "row": 5, "col": 20, "length": 8, "content": "MYUSER", "protected": false },
    { "index": 1, "row": 6, "col": 20, "length": 8, "content": "", "protected": false }
  ],
  "inputFields": [...],
  "protectedFields": [...]
}
```

### `GET /screen/text?row=&col=&length=`

Read text at a specific screen position.

**Parameters:**
- `row` — Row number (1-based)
- `col` — Column number (1-based)
- `length` — Number of characters to read

**Response:**
```json
{ "text": "ISPF PRIMARY OPTION MENU", "row": 1, "col": 28, "length": 24 }
```

### `POST /send`

Send text and/or an AID key (Enter, PF1-PF24, PA1-PA3, Clear).

**Body:**
```json
{
  "text": "LOGON TSO",
  "aid": "ENTER",
  "row": 24,
  "col": 1,
  "field": null
}
```

| Field | Type | Description |
|-------|------|-------------|
| `text` | string | Text to type (optional) |
| `aid` | string | AID key: ENTER, PF1-PF24, PA1-PA3, CLEAR (default: ENTER) |
| `row` | number | Move cursor to row before typing (1-based, optional) |
| `col` | number | Move cursor to column before typing (1-based, optional) |
| `field` | number | Move cursor to field by index (optional, alternative to row/col) |

**Response:**
```json
{
  "success": true,
  "screen": ["...updated screen lines..."],
  "cursor": { "row": 1, "col": 1 }
}
```

### `POST /wait`

Wait until specific text appears on screen (polling internally).

**Body:**
```json
{
  "text": "READY",
  "timeout": 10000
}
```

**Response:**
```json
{
  "found": true,
  "screen": ["...current screen lines..."]
}
```

---

## AI Agent Usage Examples

### GitHub Copilot / Claude (via terminal)

```bash
# Connect to production mainframe
curl -s -X POST localhost:7327/connect -d '{"host":"mfprod01","port":23}' | jq .

# Login to TSO
curl -s -X POST localhost:7327/send -d '{"text":"TSO BATCHUSR","aid":"ENTER"}' | jq .screen
curl -s -X POST localhost:7327/wait -d '{"text":"Password"}' | jq .found
curl -s -X POST localhost:7327/send -d '{"text":"","aid":"ENTER","field":1}' | jq .

# Navigate to ISPF 3.4 (dataset list)
curl -s -X POST localhost:7327/send -d '{"text":"ISPF","aid":"ENTER"}' | jq .
curl -s -X POST localhost:7327/send -d '{"text":"3.4","aid":"ENTER"}' | jq .

# Read the dataset list screen
curl -s localhost:7327/screen | jq '.lines[]'

# Exit cleanly
curl -s -X POST localhost:7327/send -d '{"aid":"PF3"}' | jq .
curl -s -X POST localhost:7327/send -d '{"aid":"PF3"}' | jq .
curl -s -X POST localhost:7327/send -d '{"text":"LOGOFF","aid":"ENTER"}' | jq .
```

### Automation Script (Node.js)

```javascript
const BASE = 'http://localhost:7327';

async function mainframeLogin(host, user, password) {
  await fetch(`${BASE}/connect`, {
    method: 'POST',
    body: JSON.stringify({ host, port: 23 })
  });

  await fetch(`${BASE}/send`, {
    method: 'POST',
    body: JSON.stringify({ text: `TSO ${user}`, aid: 'ENTER' })
  });

  await fetch(`${BASE}/wait`, {
    method: 'POST',
    body: JSON.stringify({ text: 'Password', timeout: 10000 })
  });

  await fetch(`${BASE}/send`, {
    method: 'POST',
    body: JSON.stringify({ text: password, aid: 'ENTER', field: 1 })
  });

  const resp = await fetch(`${BASE}/wait`, {
    method: 'POST',
    body: JSON.stringify({ text: 'READY', timeout: 15000 })
  });

  return resp.json();
}
```

### PowerShell

```powershell
# Connect
Invoke-RestMethod -Uri "http://localhost:7327/connect" -Method POST `
  -Body '{"host":"mainframe.example.com","port":23}' -ContentType "application/json"

# Read screen
$screen = Invoke-RestMethod -Uri "http://localhost:7327/screen"
$screen.lines | ForEach-Object { Write-Host $_ }

# Send command
Invoke-RestMethod -Uri "http://localhost:7327/send" -Method POST `
  -Body '{"text":"TSO","aid":"ENTER"}' -ContentType "application/json"
```

---

## Commands

| Command | Description |
|---------|-------------|
| `TN3270 Bridge: Connect to Mainframe` | Open connection dialog |
| `TN3270 Bridge: Disconnect from Mainframe` | Close active connection |
| `TN3270 Bridge: Open Terminal in Editor` | Full-size terminal in the main editor area |
| `TN3270 Bridge: Read Current Screen` | Open screen content in a new editor tab |
| `TN3270 Bridge: Send Keys to Mainframe` | Interactive text + AID key input |
| `TN3270 Bridge: Toggle Bridge Server` | Start/stop the HTTP bridge |

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│  AI Agent (Copilot, Claude, Scripts)                │
│  → curl http://localhost:7327/...                   │
└──────────────────────┬──────────────────────────────┘
                       │ HTTP (localhost only)
┌──────────────────────▼──────────────────────────────┐
│  VS Code Extension                                  │
│  ┌────────────────┐  ┌───────────────────────────┐  │
│  │ Bridge Server  │  │ Sidebar WebView            │  │
│  │ (port 7327)    │  │ (3270 screen rendering)   │  │
│  └───────┬────────┘  └───────────────────────────┘  │
│          │                                          │
│  ┌───────▼────────────────────────────────────────┐ │
│  │ TN3270 Client (Pure TypeScript)                │ │
│  │ • Telnet negotiation (BINARY, EOR, TN3270E)   │ │
│  │ • 3270 data stream parser (all orders)         │ │
│  │ • EBCDIC ↔ ASCII translation (CP-037)         │ │
│  │ • Screen buffer management (24×80)            │ │
│  │ • Field detection & modification tracking     │ │
│  └───────┬────────────────────────────────────────┘ │
└──────────┼──────────────────────────────────────────┘
           │ TCP/IP (TN3270 protocol)
┌──────────▼──────────────────────────────────────────┐
│  IBM z/OS Mainframe                                 │
│  VTAM → TSO/ISPF / CICS / IMS                      │
└─────────────────────────────────────────────────────┘
```

---

## Supported 3270 Features

### Protocol
- Telnet option negotiation (BINARY, EOR, TERMINAL_TYPE, TN3270E)
- TN3270E mode (with device type negotiation and functions)
- Basic TN3270 mode (fallback when TN3270E not available)
- CCW-format and SNA-format command recognition
- End-of-Record (EOR) framing

### Commands
- Write (W), Erase/Write (EW), Erase/Write Alternate (EWA)
- Read Buffer (RB), Read Modified (RM), Read Modified All (RMA)
- Erase All Unprotected (EAU)
- Write Structured Field (WSF) with Query Reply

### Orders
- Set Buffer Address (SBA)
- Start Field (SF), Start Field Extended (SFE)
- Insert Cursor (IC)
- Repeat to Address (RA), Erase Unprotected to Address (EUA)
- Program Tab (PT)
- Set Attribute (SA), Modify Field (MF)
- Graphic Escape (GE)

### AID Keys
- ENTER, CLEAR
- PF1 through PF24
- PA1, PA2, PA3

### Character Translation
- EBCDIC Code Page 037 (US/Canada/Western Europe)
- EBCDIC Code Page 500 (International)
- Full bidirectional translation table (256 entries)
- Null byte handling (display as spaces)

---

## Security

- **Localhost only** — The HTTP bridge binds exclusively to `127.0.0.1` and rejects non-local connections
- **Transparent authenticated API** — MCP/CLI obtain a 256-bit token from the Extension Host through same-user IPC
- **SecretStorage** — Login passwords and TLS key passphrases are encrypted by the operating system
- **No browser access** — CORS is disabled and requests carrying an `Origin` header are rejected
- **Masked output** — Hidden 3270 fields are redacted from full and positioned reads
- **TLS by default for production** — Use certificate validation and a corporate CA on port 992

See `docs/SECURITY.md` for the production policy and threat model.

---

## Troubleshooting

### Bridge not starting
Check if port 7327 is already in use. The extension tries up to 5 consecutive ports.
```bash
curl http://localhost:7327/status
```

### Connection timeout
- Verify network connectivity: `Test-NetConnection -ComputerName <host> -Port 23`
- Check firewall rules allow outbound TCP port 23
- Increase `tn3270Bridge.keyboardTimeout` in settings

### Screen appears empty
- Some mainframes require an initial ENTER or LOGON command
- Try: `curl -X POST localhost:7327/send -d '{"aid":"ENTER"}'`
- VTAM USS mode may show minimal text before application connection

### TN3270E not negotiated
- The extension falls back to basic TN3270 mode automatically
- Check `/status` endpoint for `tn3270e: false`
- Some mainframes only support basic TN3270

---

## Development

```bash
# Clone and install
git clone <repo-url> && cd tn3270-bridge
npm install

# Build
npm run bundle

# Watch mode (auto-rebuild on save)
npm run watch

# Package as .vsix
npx @vscode/vsce package --no-dependencies

# Install locally
code --install-extension tn3270-bridge-2.2.0.vsix
```

### Project Structure

```
tn3270-bridge/
├── src/
│   ├── extension.ts            # VS Code activation, commands, status bar
│   ├── bridge-server.ts        # HTTP REST API server
│   ├── tn3270-client.ts        # Core TN3270 protocol client
│   ├── tn3270-protocol.ts      # Constants, types, EBCDIC tables
│   ├── sidebar-provider.ts     # Sidebar WebView panel
│   └── editor-panel-provider.ts # Full-size editor panel
├── media/
│   ├── icon.png             # Extension marketplace icon
│   └── activitybar-icon.svg # Activity bar icon
├── out/
│   └── extension.js         # Bundled output (esbuild)
├── package.json             # Extension manifest
├── tsconfig.json            # TypeScript configuration
├── esbuild.js              # Build script
└── README.md               # This file
```

---

## Roadmap

- [x] Multiple concurrent sessions
- [x] CP037 and CP500
- [x] Dataset read/write through ISPF
- [x] MCP integration for Copilot and Claude Code
- [ ] Session recording/playback with secret redaction
- [ ] CP1047 and CP875 after validation against IBM reference vectors
- [ ] Light table (field map visualization)
- [ ] Keyboard shortcut passthrough in sidebar

---

## Author

**Ricel Leite**

---

## License

MIT © 2026 Ricel Leite
