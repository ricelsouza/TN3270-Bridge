import assert from 'node:assert/strict';
import { createServer } from 'node:net';
import test from 'node:test';
import { Tn3270Client } from '../src/tn3270-client';
import { AID, CMD, FA, ORDER, stringToEbcdicBuffer, TELNET, TELOPT, WCC } from '../src/tn3270-protocol';

function record(bytes: number[]): Buffer {
  return Buffer.from([...bytes, TELNET.IAC, TELNET.EOR]);
}

test('client connects to a TN3270 host, reads a screen, and sends modified input', async t => {
  let screenSent = false;
  let outbound = Buffer.alloc(0);
  const host = createServer(socket => {
    socket.write(Buffer.from([
      TELNET.IAC, TELNET.DO, TELOPT.BINARY,
      TELNET.IAC, TELNET.DO, TELOPT.EOR,
    ]));
    socket.on('data', data => {
      if (!screenSent) {
        screenSent = true;
        socket.write(record([
          CMD.EW,
          WCC.KEYBOARD_RESTORE,
          ORDER.SF, FA.PROTECTED,
          ...stringToEbcdicBuffer('READY'),
          ORDER.SF, 0x00,
          ORDER.IC,
        ]));
        return;
      }
      outbound = Buffer.concat([outbound, data]);
      socket.write(record([CMD.W, WCC.KEYBOARD_RESTORE]));
    });
  });
  await new Promise<void>(resolve => host.listen(0, '127.0.0.1', resolve));
  t.after(() => host.close());
  const address = host.address();
  assert.ok(address && typeof address === 'object');

  const client = new Tn3270Client({ host: '127.0.0.1', port: address.port, timeout: 2000 });
  t.after(() => client.disconnect());
  await client.connect();

  assert.match(client.getScreenString(), /READY/);
  assert.equal(client.state.status, 'connected');
  await client.sendText('X', 'ENTER');
  assert.equal(outbound.includes(AID.ENTER), true);
  assert.equal(outbound.includes(stringToEbcdicBuffer('X')[0]), true);
  assert.equal(client.screenState.keyboardLocked, false);
});