import assert from 'node:assert/strict';
import test from 'node:test';
import { apiTokenMatches, redactSecrets, validateDatasetReference } from '../src/security';

test('dataset references accept z/OS names and reject command injection', () => {
  assert.deepEqual(validateDatasetReference('SYS1.PARMLIB', 'IEASYS00'), {
    dsn: 'SYS1.PARMLIB',
    member: 'IEASYS00',
  });
  assert.throws(
    () => validateDatasetReference("SYS1.PARMLIB';CANCEL", 'IEASYS00'),
    /Invalid dataset name/,
  );
  assert.throws(
    () => validateDatasetReference('SYS1.PARMLIB', 'A);DELETE'),
    /Invalid member name/,
  );
});

test('API authentication requires an exact non-empty token', () => {
  assert.equal(apiTokenMatches('company-secret', 'company-secret'), true);
  assert.equal(apiTokenMatches('company-secreu', 'company-secret'), false);
  assert.equal(apiTokenMatches('', 'company-secret'), false);
  assert.equal(apiTokenMatches(undefined, 'company-secret'), false);
});

test('log redaction removes secrets from nested login fields', () => {
  const value = {
    text: 'USER1',
    fields: [{ labelLeft: 'Password', text: 's3cret!' }],
    note: 'credential=s3cret!',
  };

  assert.deepEqual(redactSecrets(value, ['s3cret!']), {
    text: 'USER1',
    fields: [{ labelLeft: 'Password', text: '***' }],
    note: 'credential=***',
  });
});