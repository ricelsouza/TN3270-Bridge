import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { createServer } from 'node:http';
import { promisify } from 'node:util';
import test from 'node:test';
import { BridgeApiClient } from '../src/bridge-api-client';
import { LocalCredentialBroker } from '../src/local-credential-broker';

const execFileAsync = promisify(execFile);

test('REST client authenticates requests and propagates bridge errors', async t => {
  const server = createServer((request, response) => {
    response.setHeader('Content-Type', 'application/json');
    if (request.headers.authorization !== 'Bearer test-token') {
      response.writeHead(401).end(JSON.stringify({ error: 'Unauthorized' }));
      return;
    }
    if (request.url === '/failure') {
      response.writeHead(409).end(JSON.stringify({ error: 'panel changed' }));
      return;
    }
    response.writeHead(200).end(JSON.stringify({ connected: true }));
  });
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(() => server.close());
  const address = server.address();
  assert.ok(address && typeof address === 'object');
  const client = new BridgeApiClient(`http://127.0.0.1:${address.port}`, 'test-token');

  assert.deepEqual(await client.get('/status'), { connected: true });
  await assert.rejects(() => client.get('/failure'), /panel changed/);
});

test('REST client obtains its token transparently from the same-user broker', async t => {
  const server = createServer((request, response) => {
    response.setHeader('Content-Type', 'application/json');
    if (request.headers.authorization !== 'Bearer broker-token') {
      response.writeHead(401).end(JSON.stringify({ error: 'Unauthorized' }));
      return;
    }
    response.writeHead(200).end(JSON.stringify({ transparent: true }));
  });
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(() => server.close());
  const address = server.address();
  assert.ok(address && typeof address === 'object');

  const broker = new LocalCredentialBroker(address.port, async () => 'broker-token');
  await broker.start();
  t.after(() => broker.stop());

  const client = await BridgeApiClient.connect(`http://127.0.0.1:${address.port}`);
  assert.deepEqual(await client.get('/status'), { transparent: true });

  const env = { ...process.env, TN3270_BRIDGE_URL: `http://127.0.0.1:${address.port}` };
  delete env.TN3270_BRIDGE_TOKEN;
  const { stdout } = await execFileAsync(
    process.execPath,
    ['--import', 'tsx', 'src/bridge-cli.ts', 'GET', '/status'],
    { env },
  );
  assert.deepEqual(JSON.parse(stdout), { transparent: true });
});