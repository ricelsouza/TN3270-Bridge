import assert from 'node:assert/strict';
import test from 'node:test';
import { claudeMcpAddArguments } from '../src/claude-mcp-registration';

test('Claude MCP registration is user-scoped and runs the bundled server without secrets', () => {
  const args = claudeMcpAddArguments('C:\\Program Files\\Microsoft VS Code\\Code.exe', 'C:\\extensions\\tn3270\\out\\mcp-server.js');

  assert.deepEqual(args, [
    'mcp', 'add',
    '--scope', 'user',
    '--transport', 'stdio',
    'tn3270-bridge',
    '-e', 'ELECTRON_RUN_AS_NODE=1',
    '--',
    'C:\\Program Files\\Microsoft VS Code\\Code.exe',
    'C:\\extensions\\tn3270\\out\\mcp-server.js',
  ]);
  assert.equal(args.some(value => /token|password|secret/i.test(value)), false);
});