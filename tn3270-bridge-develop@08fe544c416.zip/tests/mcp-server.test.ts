import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import test from 'node:test';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { LocalCredentialBroker } from '../src/local-credential-broker';

test('MCP transparently authenticates and exposes corporate mainframe tools', async t => {
  const requests: Array<{ method?: string; url?: string }> = [];
  const api = createServer((request, response) => {
    requests.push({ method: request.method, url: request.url });
    response.setHeader('Content-Type', 'application/json');
    if (request.headers.authorization !== 'Bearer mcp-broker-token') {
      response.writeHead(401).end(JSON.stringify({ error: 'Unauthorized' }));
      return;
    }
    response.writeHead(200).end(JSON.stringify({ connected: true, source: 'broker' }));
  });
  await new Promise<void>(resolve => api.listen(0, '127.0.0.1', resolve));
  t.after(() => api.close());
  const address = api.address();
  assert.ok(address && typeof address === 'object');
  const broker = new LocalCredentialBroker(address.port, async () => 'mcp-broker-token');
  await broker.start();
  t.after(() => broker.stop());

  const env = Object.fromEntries(
    Object.entries(process.env).filter((entry): entry is [string, string] => entry[1] !== undefined),
  );
  delete env.TN3270_BRIDGE_TOKEN;
  const transport = new StdioClientTransport({
    command: process.execPath,
    args: ['--import', 'tsx', 'src/mcp-server.ts'],
    env: { ...env, TN3270_BRIDGE_URL: `http://127.0.0.1:${address.port}` },
    stderr: 'pipe',
  });
  const client = new Client({ name: 'tn3270-e2e', version: '1.0.0' });

  try {
    await client.connect(transport);
    const result = await client.listTools();
    const names = result.tools.map(tool => tool.name);
    assert.equal(names.includes('mainframe_read_screen'), true);
    assert.equal(names.includes('mainframe_write_dataset'), true);
    assert.equal(names.includes('mainframe_submit_job'), true);
    assert.equal(names.includes('mainframe_cursor'), true);
    assert.equal(names.includes('mainframe_fields'), true);
    assert.equal(names.includes('mainframe_read_all'), true);
    assert.equal(names.includes('mainframe_table'), true);
    assert.equal(names.includes('mainframe_session_create'), true);
    assert.equal(names.includes('mainframe_session_delete'), true);
    assert.equal(names.includes('mainframe_connect'), true);
    assert.equal(names.includes('mainframe_disconnect'), true);
    assert.equal(names.includes('mainframe_extract'), true);
    assert.equal(result.tools.length, 22);
    const status = await client.callTool({ name: 'mainframe_status', arguments: {} });
    assert.equal(status.isError, undefined);
    const content = status.content[0];
    assert.equal(content.type, 'text');
    if (content.type === 'text') {
      assert.deepEqual(JSON.parse(content.text), { connected: true, source: 'broker' });
    }
    await client.callTool({
      name: 'mainframe_cursor',
      arguments: { row: 12, col: 3 },
    });
    await client.callTool({
      name: 'mainframe_session_delete',
      arguments: { sessionId: 'qa-session' },
    });
    assert.equal(requests.some(request => request.method === 'POST' && request.url === '/cursor'), true);
    assert.equal(requests.some(request => request.method === 'DELETE' && request.url === '/session/qa-session'), true);
  } finally {
    await client.close();
  }
});