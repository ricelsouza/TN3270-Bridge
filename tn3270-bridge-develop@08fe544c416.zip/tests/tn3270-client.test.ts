import assert from 'node:assert/strict';
import test from 'node:test';
import { Tn3270Client } from '../src/tn3270-client';
import { ebcdicToAscii, FA, stringToEbcdicBuffer } from '../src/tn3270-protocol';

test('positioned screen reads mask hidden field content', () => {
  const client = new Tn3270Client({ host: 'example.test', port: 23 });
  const screen = client.screenState;

  screen.attributes[0] = FA.DISPLAY_HIDDEN;
  screen.buffer.set([0xE2, 0xC5, 0xC3, 0xD9, 0xC5, 0xE3], 1); // SECRET
  screen.fields = [{
    position: 0,
    attribute: FA.DISPLAY_HIDDEN,
    length: 6,
    protected: false,
    numeric: false,
    hidden: true,
    intense: false,
    modified: false,
  }];

  assert.equal(client.getTextAt(1, 2, 6), '      ');
});

test('configured EBCDIC code page changes punctuation translation', () => {
  assert.equal(stringToEbcdicBuffer('!', 37)[0], 0x5A);
  assert.equal(stringToEbcdicBuffer('!', 500)[0], 0x4F);
  assert.equal(String.fromCharCode(ebcdicToAscii(0x4F, 500)), '!');
  assert.equal(String.fromCharCode(ebcdicToAscii(0x4F, 37)), '|');
});