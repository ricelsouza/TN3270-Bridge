/**
 * TN3270 Client — Pure TypeScript implementation
 * Handles: TCP/TLS connection, Telnet negotiation, TN3270E, screen buffer management
 */
import * as net from 'net';
import * as tls from 'tls';
import * as fs from 'fs';
import { EventEmitter } from 'events';
import {
  TELNET, TELOPT, TN3270E, CMD, CMD_CCW, WCC, ORDER, AID, FA,
  ebcdicToAscii, asciiToEbcdic, stringToEbcdicBuffer,
  decodeBufferAddress, encodeBufferAddress,
  graphicToUnicode,
  Field, ScreenState, ConnectionState, ConnectionStatus,
  TlsOptions, TlsInfo, translateNetworkError,
} from './tn3270-protocol';

export interface Tn3270Options {
  host: string;
  port: number;
  deviceType?: string;
  luName?: string;
  rows?: number;
  cols?: number;
  timeout?: number;
  codePage?: 37 | 500;
  tls?: TlsOptions;
}

export class Tn3270Client extends EventEmitter {
  private socket: net.Socket | tls.TLSSocket | null = null;
  private screen: ScreenState;
  private connection: ConnectionState;
  private telnetBuffer: number[] = [];
  private inIAC = false;
  private inSB = false;
  private sbBuffer: number[] = [];
  private tn3270eMode = false;
  private pendingResolve: (() => void) | null = null;
  private pendingReject: ((error: Error) => void) | null = null;
  private connectPhase: 'idle' | 'tcp' | 'tls' | 'telnet' = 'idle';
  private firstByteReceived = false;
  private opts: Required<Omit<Tn3270Options, 'tls'>> & { tls?: TlsOptions };
  public lastSentResponse: string = ''; // debug: hex of last Read Modified response
  public lastAlarm = false;             // true when the last host write had the WCC ALARM bit set
  private screenHistory: string[][] = []; // circular buffer of last N screen states (10 default, 40 in OMVS/NVT mode)

  constructor(options: Tn3270Options) {
    super();
    this.opts = {
      host: options.host,
      port: options.port,
      deviceType: options.deviceType || 'IBM-3278-2-E',
      luName: options.luName || '',
      rows: options.rows || 24,
      cols: options.cols || 80,
      timeout: options.timeout || 30000,
      codePage: options.codePage || 37,
      tls: options.tls,
    };

    const size = this.opts.rows * this.opts.cols;
    this.screen = {
      rows: this.opts.rows,
      cols: this.opts.cols,
      buffer: new Uint8Array(size).fill(0x00),
      attributes: new Uint8Array(size).fill(0x00),
      graphic: new Uint8Array(size).fill(0x00),
      cursor: 0,
      fields: [],
      keyboardLocked: true,
      formatted: false,
    };

    this.connection = {
      status: 'disconnected',
      host: this.opts.host,
      port: this.opts.port,
      tn3270e: false,
      deviceType: this.opts.deviceType,
    };
  }

  get state(): ConnectionState { return { ...this.connection }; }
  get screenState(): ScreenState { return this.screen; }

  /**
   * Connect to the mainframe (plain TCP or TLS, depending on opts.tls.enabled).
   *
   * Timeline:
   *  1. TCP SYN (phase='tcp')           — up to handshakeTimeout ms
   *  2. TLS handshake (phase='tls')     — up to handshakeTimeout ms (TLS only)
   *  3. Telnet/TN3270 negotiation       — up to negotiationTimeout ms
   *     We proactively send DO TERMINAL-TYPE / DO EOR / DO BINARY so passive
   *     z/OS TN3270 servers that expect the client to initiate don't leave us
   *     hanging (matches Mocha / c3270 / x3270 behavior).
   *  4. First 3270 Write (or SSCP-LU data) → connect() promise resolves.
   */
  async connect(): Promise<void> {
    if (this.socket) {
      throw new Error('Already connected');
    }

    this.setStatus('connecting');
    this.connectPhase = 'tcp';
    this.firstByteReceived = false;

    // Split the wall-clock budget: give the handshake up to two thirds, leave
    // the rest for TN3270 negotiation. Handshake dominates on corp networks
    // with slow TLS chain fetches and jittery MPLS/VPN paths, so bias generous.
    // Clamp to 20s minimum so a well-behaved default `timeout=30000` still
    // gives the handshake 20s and TN3270 negotiation 10s.
    const total = this.opts.timeout;
    const handshakeBudget = Math.max(20000, Math.floor(total * 2 / 3));

    return new Promise((resolve, reject) => {
      let overallTimer: ReturnType<typeof setTimeout> | null = null;
      let handshakeTimer: ReturnType<typeof setTimeout> | null = null;

      const cleanupTimers = () => {
        if (overallTimer) { clearTimeout(overallTimer); overallTimer = null; }
        if (handshakeTimer) { clearTimeout(handshakeTimer); handshakeTimer = null; }
      };

      const failWith = (code: string, message: string) => {
        const err = new Error(message);
        (err as any).code = code;
        cleanupTimers();
        this.captureError(err);
        this.pendingResolve = null;
        this.pendingReject = null;
        reject(err);
        this.socket?.destroy();
      };

      // Handshake timer: must reach 'telnet' phase (i.e. TCP/TLS done, client
      // ready to negotiate) within the handshake budget.
      handshakeTimer = setTimeout(() => {
        if (this.connectPhase === 'tcp') {
          failWith('TCP_CONNECT_TIMEOUT',
            `TCP connect to ${this.opts.host}:${this.opts.port} timed out after ${handshakeBudget}ms. ` +
            `Host unreachable or port blocked by firewall.`);
        } else if (this.connectPhase === 'tls') {
          failWith('TLS_HANDSHAKE_TIMEOUT',
            `TLS handshake to ${this.opts.host}:${this.opts.port} did not complete within ${handshakeBudget}ms. ` +
            `The server may not speak TLS on this port — verify port 992 vs 23, or the host may require a different minVersion / cipher.`);
        }
      }, handshakeBudget);

      // Overall timer: whole connect (including TN3270 negotiation) must
      // finish within the caller-supplied timeout.
      overallTimer = setTimeout(() => {
        if (this.connectPhase === 'telnet') {
          const detail = this.firstByteReceived
            ? `Received some data from the host but the initial 3270 Write never arrived. TN3270 negotiation may have stalled.`
            : `TLS handshake succeeded but the host never sent any Telnet/TN3270 bytes. It may be waiting for a different device type or LU.`;
          failWith('TN3270_NEGOTIATION_TIMEOUT',
            `TN3270 negotiation with ${this.opts.host}:${this.opts.port} timed out after ${total}ms. ${detail}`);
        } else {
          failWith('ETIMEDOUT', `Connection timeout after ${total}ms (phase=${this.connectPhase})`);
        }
      }, total);

      const onError = (err: NodeJS.ErrnoException) => {
        cleanupTimers();
        this.captureError(err);
        this.socket?.destroy();
        reject(err);
      };

      const onClose = () => {
        this.socket = null;
        this.setStatus('disconnected');
        this.emit('disconnected');
      };

      const onData = (data: Buffer) => {
        if (!this.firstByteReceived) {
          this.firstByteReceived = true;
          this.emit('firstByte', data.length);
        }
        this.processIncoming(data);
      };

      const onReady = () => {
        // TCP or TLS handshake complete → begin TN3270 negotiation phase.
        if (this.socket && 'getProtocol' in this.socket) {
          this.captureTlsInfo(this.socket as tls.TLSSocket);

          const sock = this.socket as tls.TLSSocket;
          const cert = sock.getPeerCertificate();
          const actual = normalizeFingerprint((cert as any)?.fingerprint256 || (cert as any)?.fingerprint);
          const pinned = normalizeFingerprint(this.opts.tls?.pinnedFingerprint);
          const wantsVerify = this.opts.tls?.rejectUnauthorized !== false;

          // Verification order:
          //  1. If a pin is set, ONLY the pin decides — matches Mocha "trust
          //     this cert" semantics; the corp CA doesn't need to be in the
          //     OS trust store.
          //  2. Otherwise, if caller requested verification, honor Node's
          //     authorization result (which we captured with the cert).
          if (pinned) {
            if (!actual || actual !== pinned) {
              const err: any = new Error(
                `Pinned certificate mismatch — expected ${pinned}, got ${actual || 'no cert'}. The mainframe presented a certificate that does not match the one you previously trusted.`
              );
              err.code = 'TLS_PIN_MISMATCH';
              cleanupTimers();
              this.captureError(err);
              sock.destroy();
              reject(err);
              return;
            }
          } else if (wantsVerify && sock.authorized === false) {
            const authErr = sock.authorizationError as any;
            const authCode = (authErr && (authErr.code || String(authErr))) || 'UNAUTHORIZED';
            const err: any = new Error(String(authErr || 'certificate not trusted'));
            // Preserve the specific Node code so translateNetworkError picks
            // the right hint (self-signed, unknown CA, expired, altname).
            err.code = authCode;
            cleanupTimers();
            this.captureError(err);
            sock.destroy();
            reject(err);
            return;
          }
        }
        this.connectPhase = 'telnet';
        this.setStatus('negotiating');
        this.pendingResolve = () => {
          cleanupTimers();
          resolve();
        };
        this.pendingReject = reject;

        // NOTE: We deliberately do NOT send any proactive Telnet DO/WILL
        // negotiation here. x3270 (the reference open-source TN3270
        // implementation) and IBM Personal Communications are strictly
        // REACTIVE: they wait for the z/OS Communications Server to send
        // IAC DO TN3270E first, then respond. Sending DO/WILL for
        // TERMINAL-TYPE / EOR / BINARY proactively confuses z/OS TN3270E,
        // which either back-levels to plain TN3270 or hangs waiting for
        // "protocol resynchronization" (an RFC 1576 quirk). RFC 2355 §3
        // additionally states that BINARY and EOR are IMPLIED by TN3270E
        // acceptance — negotiating them separately is redundant.
        // Our reactive handlers (handleTelnetOption / handleTN3270ESubneg)
        // below answer the server's initiation correctly.
      };

      if (this.opts.tls?.enabled) {
        // === TLS path ===
        try {
          const tlsOpts = this.buildTlsConnectOptions();
          // Once we call tls.connect the transport is committed to TCP+TLS;
          // conceptually we're already past the "TCP-only" phase. Marking
          // 'tls' up front avoids relying on the underlying-socket 'connect'
          // event, which is inconsistent across Node versions and Electron.
          this.connectPhase = 'tls';
          const sock = tls.connect(tlsOpts);
          this.socket = sock;
          sock.on('secureConnect', onReady);
          sock.on('data', onData);
          sock.on('error', onError);
          sock.on('close', onClose);
        } catch (e: any) {
          cleanupTimers();
          this.captureError(e);
          reject(e);
          return;
        }
      } else {
        // === Plain TCP path (legacy / dev) ===
        this.socket = net.createConnection({
          host: this.opts.host,
          port: this.opts.port,
        });
        this.socket.on('connect', onReady);
        this.socket.on('data', onData);
        this.socket.on('error', onError);
        this.socket.on('close', onClose);
      }
    });
  }

  private buildTlsConnectOptions(): tls.ConnectionOptions {
    const t = this.opts.tls!;
    // SNI must not be an IP literal (RFC 6066). Some hosts reject the
    // handshake or answer with a cert whose SAN doesn't cover the IP, which
    // then trips ERR_TLS_CERT_ALTNAME_INVALID. Skip servername when the host
    // is IPv4 or IPv6 unless the caller supplied an explicit SNI override.
    const explicitSni = t.sni && t.sni.length > 0 ? t.sni : undefined;
    const hostIsIp = net.isIP(this.opts.host) !== 0;
    const servername = explicitSni ?? (hostIsIp ? undefined : this.opts.host);

    // Always let the handshake proceed with rejectUnauthorized=false so we
    // reach secureConnect and can capture the peer cert (needed to offer the
    // user a fingerprint to pin). Actual verification is enforced afterwards
    // in onReady: if pin is set → check fingerprint; if rejectUnauthorized
    // was requested and cert isn't trusted → fail with a specific code.
    const opts: tls.ConnectionOptions = {
      host: this.opts.host,
      port: this.opts.port,
      minVersion: t.minVersion ?? 'TLSv1.2',
      rejectUnauthorized: false,
    };
    if (servername) opts.servername = servername;
    if (hostIsIp && !explicitSni) {
      // When connecting by IP, don't fail on altname mismatch — most z/OS
      // certs are issued for the hostname and lack the IP as a SAN entry.
      opts.checkServerIdentity = () => undefined;
    }
    if (t.maxVersion) opts.maxVersion = t.maxVersion;
    if (t.ciphers) opts.ciphers = t.ciphers;

    const readPem = (path: string, label: string): Buffer => {
      try { return fs.readFileSync(path); }
      catch (e: any) {
        const err = new Error(`Cannot read ${label} file at ${path}: ${e.message}`);
        (err as any).code = 'TLS_PEM_READ_ERROR';
        throw err;
      }
    };

    if (t.caBundle) opts.ca = readPem(t.caBundle, 'CA bundle');
    if (t.clientCert) opts.cert = readPem(t.clientCert, 'client certificate');
    if (t.clientKey) opts.key = readPem(t.clientKey, 'client key');
    if (t.passphrase) opts.passphrase = t.passphrase;
    return opts;
  }

  private captureTlsInfo(sock: tls.TLSSocket): void {
    try {
      const cipherInfo = sock.getCipher();
      const cert = sock.getPeerCertificate();
      const tlsInfo: TlsInfo = {
        enabled: true,
        version: sock.getProtocol() || undefined,
        cipher: cipherInfo?.name,
        authorized: sock.authorized,
        authorizationError: sock.authorizationError ? String(sock.authorizationError) : undefined,
      };
      if (cert && cert.subject) {
        tlsInfo.peerCertificate = {
          subject: typeof cert.subject === 'object' ? Object.entries(cert.subject).map(([k, v]) => `${k}=${v}`).join(',') : String(cert.subject),
          issuer: typeof cert.issuer === 'object' ? Object.entries(cert.issuer).map(([k, v]) => `${k}=${v}`).join(',') : String(cert.issuer),
          validFrom: cert.valid_from,
          validTo: cert.valid_to,
          fingerprint: cert.fingerprint256 || cert.fingerprint,
        };
      }
      this.connection.tls = tlsInfo;
    } catch {
      // Ignore — TLS info is best-effort
    }
  }

  private captureError(err: { code?: string; message?: string }): void {
    this.connection.error = err.message;
    const t = translateNetworkError(err);
    this.connection.errorCode = t.code;
    this.connection.errorHint = t.hint;
    this.setStatus('error');
  }

  /**
   * Disconnect
   */
  disconnect(): void {
    const pendingReject = this.pendingReject;
    this.pendingResolve = null;
    this.pendingReject = null;
    if (this.socket) {
      this.socket.destroy();
      this.socket = null;
    }
    this.setStatus('disconnected');
    pendingReject?.(new Error('Disconnected'));
  }

  /**
   * Type text into the buffer at cursor position without sending to host.
   * Marks the field as modified. Use this to fill multiple fields before pressing Enter.
   */
  typeText(text: string): void {
    if (!this.socket || this.connection.status !== 'connected') {
      throw new Error('Not connected');
    }

    const startPos = this.screen.cursor;
    const ebcdicText = stringToEbcdicBuffer(text, this.opts.codePage);
    for (let i = 0; i < ebcdicText.length; i++) {
      this.writeToBuffer(this.screen.cursor, ebcdicText[i]);
      this.screen.cursor = (this.screen.cursor + 1) % (this.opts.rows * this.opts.cols);
      // Skip field attribute bytes
      while (this.screen.attributes[this.screen.cursor] !== 0) {
        this.screen.cursor = (this.screen.cursor + 1) % (this.opts.rows * this.opts.cols);
      }
    }

    this.markFieldModified(startPos);
  }

  /**
   * Send text to current cursor position, then press an AID key
   */
  async sendText(text: string, aidKey: keyof typeof AID = 'ENTER'): Promise<void> {
    this.typeText(text);
    return this.sendAID(aidKey);
  }

  /**
   * Send only an AID key (ENTER, PF1-24, PA1-3, CLEAR)
   */
  async sendAID(aidKey: keyof typeof AID = 'ENTER'): Promise<void> {
    if (!this.socket || this.connection.status !== 'connected') {
      throw new Error('Not connected');
    }

    const aidByte = AID[aidKey];
    if (aidByte === undefined) throw new Error(`Unknown AID key: ${String(aidKey)}`);
    const response = this.buildReadModifiedResponse(aidByte);
    this.lastSentResponse = Buffer.from(response).toString('hex');
    this.sendDataStream(response);

    this.lastAlarm = false; // clear stale alarm state for this AID cycle
    this.screen.keyboardLocked = true;
    this.emit('keyboardLock', true);

    // Wait for host response
    return new Promise((resolve, reject) => {
      const complete = () => {
        clearTimeout(timeout);
        this.pendingResolve = null;
        this.pendingReject = null;
        resolve();
      };
      const timeout = setTimeout(() => {
        if (this.pendingResolve === complete) {
          this.pendingResolve = null;
          this.pendingReject = null;
        }
        // Unlock the keyboard so the user isn't stuck with `LOCKED` after a
        // slow / lost host response. The 3270 keyboard-lock semantic is
        // "input inhibited until host replies" — if the reply never comes,
        // physical 3270 terminals let the user press RESET to clear the
        // indicator locally, and we mirror that behavior automatically at
        // the timeout. If the host reply eventually arrives later, the
        // subsequent Write's WCC.KEYBOARD_RESTORE will re-run this idempotently.
        this.screen.keyboardLocked = false;
        this.emit('keyboardLock', false);
        reject(new Error(`Host response timeout after ${this.opts.timeout}ms`));
      }, this.opts.timeout);

      this.pendingResolve = complete;
      this.pendingReject = reject;
    });
  }

  /**
   * Clear the local keyboard-locked flag without sending anything to the
   * host — equivalent to the RESET key on a physical 3278/3279. Useful when
   * a Write's WCC did not include KEYBOARD_RESTORE (e.g. server bug or
   * mid-sequence Write) and the user is stuck.
   */
  resetKeyboard(): void {
    if (this.screen.keyboardLocked) {
      this.screen.keyboardLocked = false;
      this.emit('keyboardLock', false);
    }
  }

  /**
   * Move cursor to specific row/col (1-based)
   */
  setCursor(row: number, col: number): void {
    const addr = ((row - 1) * this.opts.cols) + (col - 1);
    if (addr >= 0 && addr < this.opts.rows * this.opts.cols) {
      this.screen.cursor = addr;
    }
  }

  /**
   * Move cursor to a specific field (by index)
   */
  setCursorToField(fieldIndex: number): void {
    if (fieldIndex >= 0 && fieldIndex < this.screen.fields.length) {
      const field = this.screen.fields[fieldIndex];
      // Position after the attribute byte
      this.screen.cursor = (field.position + 1) % (this.opts.rows * this.opts.cols);
    }
  }

  /**
   * Get the screen as text (24x80 ASCII)
   */
  getScreenText(): string[] {
    // Pre-build a hidden-field mask for O(1) lookup per position
    const size = this.opts.rows * this.opts.cols;
    const hiddenMask = new Uint8Array(size);
    for (const field of this.screen.fields) {
      if (field.hidden) {
        const start = (field.position + 1) % size;
        for (let i = 0; i < field.length; i++) {
          hiddenMask[(start + i) % size] = 1;
        }
      }
    }

    const lines: string[] = [];
    for (let row = 0; row < this.opts.rows; row++) {
      let line = '';
      for (let col = 0; col < this.opts.cols; col++) {
        const pos = row * this.opts.cols + col;
        if (this.screen.attributes[pos] !== 0) {
          // Field attribute byte — display as space
          line += ' ';
        } else if (hiddenMask[pos]) {
          // Hidden field — never display content (security: passwords etc.)
          line += ' ';
        } else {
          const byte = this.screen.buffer[pos];
          if (byte === 0x00) {
            line += ' ';  // Null = space
          } else if (this.screen.graphic[pos]) {
            // Graphic escape character — use line-drawing mapping
            line += graphicToUnicode(byte);
          } else {
            line += String.fromCharCode(ebcdicToAscii(byte, this.opts.codePage));
          }
        }
      }
      lines.push(line);
    }
    return lines;
  }

  /**
   * Get screen as a single string (for AI parsing)
   */
  getScreenString(): string {
    return this.getScreenText().join('\n');
  }

  /**
   * Get input fields with their content
   */
  getInputFields(): Array<{ index: number; row: number; col: number; length: number; content: string; protected: boolean; hidden: boolean }> {
    return this.screen.fields.map((field, index) => {
      const startPos = (field.position + 1) % (this.opts.rows * this.opts.cols);
      let content = '';
      if (!field.hidden) {
        for (let i = 0; i < field.length; i++) {
          const pos = (startPos + i) % (this.opts.rows * this.opts.cols);
          const byte = this.screen.buffer[pos];
          if (byte === 0x00) {
            content += '';
          } else {
            content += String.fromCharCode(ebcdicToAscii(byte, this.opts.codePage));
          }
        }
      }
      return {
        index,
        row: Math.floor(startPos / this.opts.cols) + 1,
        col: (startPos % this.opts.cols) + 1,
        length: field.length,
        content: field.hidden ? '' : content.trimEnd(),
        protected: field.protected,
        hidden: field.hidden,
      };
    });
  }

  /**
   * Get the text at specific position
   */
  getTextAt(row: number, col: number, length: number): string {
    const start = (row - 1) * this.opts.cols + (col - 1);
    let result = '';
    for (let i = 0; i < length; i++) {
      const pos = (start + i) % (this.opts.rows * this.opts.cols);
      if (this.isHiddenPosition(pos)) {
        result += ' ';
        continue;
      }
      const byte = this.screen.buffer[pos];
      if (byte === 0x00) {
        result += ' ';
      } else {
        result += String.fromCharCode(ebcdicToAscii(byte, this.opts.codePage));
      }
    }
    return result;
  }

  private isHiddenPosition(pos: number): boolean {
    const size = this.opts.rows * this.opts.cols;
    return this.screen.fields.some(field => {
      if (!field.hidden) return false;
      const start = (field.position + 1) % size;
      const end = (start + field.length) % size;
      return start <= end
        ? pos >= start && pos < end
        : pos >= start || pos < end;
    });
  }

  /**
   * Wait until a pattern appears on screen.
   *
   * `pattern` may be:
   *   - A plain string — matched with `includes()` (existing behaviour)
   *   - A regex literal string like `"/READY|TSO /i"` — parsed and tested as RegExp
   *   - A RegExp object (when called from TypeScript)
   *
   * Returns true when matched, false on timeout.
   */
  async waitForText(pattern: string | RegExp, timeoutMs?: number): Promise<boolean> {
    const deadline = Date.now() + (timeoutMs || this.opts.timeout);
    // Resolve pattern to a test function
    let test: (s: string) => boolean;
    if (pattern instanceof RegExp) {
      test = (s) => pattern.test(s);
    } else if (typeof pattern === 'string' && pattern.startsWith('/')) {
      // Parse /pattern/flags notation
      const m = pattern.match(/^\/(.+)\/([gimsuy]*)$/);
      if (m) {
        const re = new RegExp(m[1], m[2]);
        test = (s) => re.test(s);
      } else {
        test = (s) => s.includes(pattern);
      }
    } else {
      test = (s) => s.includes(pattern as string);
    }
    return new Promise((resolve) => {
      let resolved = false;
      const done = (v: boolean) => {
        if (resolved) return;
        resolved = true;
        this.off('screenUpdate', onUpdate);
        clearInterval(pollTimer);
        clearTimeout(deadlineTimer);
        resolve(v);
      };
      const onUpdate = () => { if (test(this.getScreenString())) done(true); };
      // Hard deadline — fires when timeout elapses regardless of screen activity
      const deadlineTimer = setTimeout(() => done(false), Math.max(0, deadline - Date.now()));
      // Polling fallback every 250ms for static screens that emit no screenUpdate events
      const pollTimer = setInterval(() => {
        if (Date.now() > deadline) { done(false); return; }
        if (test(this.getScreenString())) done(true);
      }, 250);
      this.on('screenUpdate', onUpdate);
      // Check immediately before registering listeners
      if (test(this.getScreenString())) done(true);
    });
  }

  /**
   * Wait until the host clears the keyboard lock (i.e. the screen we have is the
   * post-AID response), or until the deadline. Returns true on unlock, false on
   * timeout. Use after sendAID() to eliminate fragile sleep() calls.
   */
  async waitForKeyboardUnlock(timeoutMs: number = 5000): Promise<boolean> {
    if (!this.screen.keyboardLocked) return true;
    return new Promise((resolve) => {
      const deadline = Date.now() + timeoutMs;
      const onUpdate = () => {
        if (!this.screen.keyboardLocked) {
          this.off('screenUpdate', onUpdate);
          clearTimeout(timer);
          resolve(true);
        }
      };
      const timer = setTimeout(() => {
        this.off('screenUpdate', onUpdate);
        resolve(false);
      }, Math.max(0, deadline - Date.now()));
      this.on('screenUpdate', onUpdate);
    });
  }

  /**
   * Detect the ISPF panel ID from the screen. ISPF writes `*PANELID` (or just
   * `PANELID`) on row 24 when PANELID ON is set. Returns null if not found.
   */
  detectPanelId(): string | null {
    const lines = this.getScreenText();
    // ISPF panel id appears on row 24 (index 23), usually starting at col 3-5
    // pattern: optional '*' + 1-8 chars of [A-Z@#$0-9]
    for (let r = this.opts.rows - 1; r >= Math.max(0, this.opts.rows - 3); r--) {
      const line = lines[r] || '';
      const m = line.match(/\*?([A-Z@#$][A-Z@#$0-9]{1,7})\s*$/);
      if (m) return m[1];
      const m2 = line.match(/^\s*\*([A-Z@#$][A-Z@#$0-9]{1,7})\b/);
      if (m2) return m2[1];
    }
    return null;
  }

  /**
   * Take a snapshot of the screen as a string array. Use snapshotDiff(prev) to
   * compute the changed lines between two snapshots.
   */
  snapshotScreen(): string[] {
    return this.getScreenText();
  }

  /**
   * Compute the line-level diff between two screen snapshots.
   * Returns the rows (1-based) and their new content that differ.
   */
  static snapshotDiff(prev: string[], next: string[]): Array<{ row: number; content: string }> {
    const diff: Array<{ row: number; content: string }> = [];
    const max = Math.max(prev.length, next.length);
    for (let i = 0; i < max; i++) {
      const a = (prev[i] || '').replace(/\s+$/, '');
      const b = (next[i] || '').replace(/\s+$/, '');
      if (a !== b) {
        diff.push({ row: i + 1, content: next[i] || '' });
      }
    }
    return diff;
  }

  /**
   * Find an input field positioned to the right of (or below) a label.
   *
   * Strategy:
   *   1. Read the screen as text and search every row for the label substring.
   *   2. For each match, find the closest UNPROTECTED input field that
   *      starts on the same row at a column greater than the label end.
   *   3. If none on the same row, look at the next row.
   *
   * Returns the field (with row/col 1-based, length) or null.
   */
  findFieldByLabel(label: string, mode: 'left' | 'above' = 'left'):
    | { row: number; col: number; length: number; index: number }
    | null {
    if (!label) return null;
    const lines = this.getScreenText();
    const inputs = this.getInputFields().filter(f => !f.protected);
    const normalize = (s: string) => s.replace(/\s+/g, ' ').trim();
    const wantedNorm = normalize(label).toUpperCase();
    if (!wantedNorm) return null;

    for (let r = 0; r < lines.length; r++) {
      const line = lines[r];
      const upperLine = line.toUpperCase();
      const idx = upperLine.indexOf(wantedNorm);
      if (idx === -1) continue;
      const labelEndCol = idx + wantedNorm.length + 1; // 1-based, just after label

      if (mode === 'left') {
        // Look on the same row, then row+1 — pick closest input
        const candidates = inputs
          .filter(f => (f.row === r + 1 && f.col >= labelEndCol) || f.row === r + 2)
          .sort((a, b) => {
            if (a.row !== b.row) return a.row - b.row;
            return a.col - b.col;
          });
        if (candidates.length > 0) {
          return { row: candidates[0].row, col: candidates[0].col, length: candidates[0].length, index: candidates[0].index };
        }
      } else if (mode === 'above') {
        // input is directly below the label
        const candidates = inputs
          .filter(f => f.row > r + 1 && f.row <= r + 3)
          .sort((a, b) => a.row - b.row);
        if (candidates.length > 0) {
          return { row: candidates[0].row, col: candidates[0].col, length: candidates[0].length, index: candidates[0].index };
        }
      }
    }
    return null;
  }

  /**
   * Resolve a semantic alias to a concrete field position.
   * Currently supports:
   *   - "OPTION"  → first unprotected field on the row containing "===>"
   *   - "COMMAND" → same as OPTION
   *   - "CURSOR"  → wherever the cursor currently sits
   */
  resolveFieldName(name: string): { row: number; col: number; length: number; index: number } | null {
    const upper = (name || '').toUpperCase();
    const inputs = this.getInputFields().filter(f => !f.protected);
    if (upper === 'CURSOR') {
      const cursorRow = Math.floor(this.screen.cursor / this.opts.cols) + 1;
      const cursorCol = (this.screen.cursor % this.opts.cols) + 1;
      // Find the field containing this position (or the next one)
      const match = inputs.find(f => f.row === cursorRow && cursorCol >= f.col && cursorCol < f.col + f.length);
      if (match) return { row: match.row, col: match.col, length: match.length, index: match.index };
      return { row: cursorRow, col: cursorCol, length: 0, index: -1 };
    }
    if (upper === 'OPTION' || upper === 'COMMAND') {
      // Find first row containing "===>"
      const lines = this.getScreenText();
      for (let r = 0; r < lines.length; r++) {
        const idx = lines[r].indexOf('===>');
        if (idx === -1) continue;
        const fieldStartCol = idx + 5; // 1-based: after "===>"
        const candidates = inputs
          .filter(f => f.row === r + 1 && f.col >= fieldStartCol)
          .sort((a, b) => a.col - b.col);
        if (candidates.length > 0) {
          return { row: candidates[0].row, col: candidates[0].col, length: candidates[0].length, index: candidates[0].index };
        }
      }
    }
    // Generic fallback: treat the name as a labelLeft search.
    // This handles SDSF, TSO Ready, and other screens that don't use "===>"
    // but do have a text label followed by an input field.
    const labelMatch = this.findFieldByLabel(name, 'left');
    if (labelMatch) return labelMatch;
    return null;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Public helpers added in 1.7.0
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * Send a Telnet Interrupt Process (IAC IP + IAC DM) to break a hung session.
   * Unlike sendAID('ATTN'), this does NOT require the keyboard to be unlocked.
   * Clears the local keyboard lock optimistically so the agent can retry.
   */
  sendATTN(): void {
    if (!this.socket) return;
    // RFC 854: IAC IP followed by IAC DM as the data-stream sync point
    this.sendTelnet([TELNET.IAC, TELNET.IP, TELNET.IAC, TELNET.DM]);
    if (this.screen.keyboardLocked) {
      this.screen.keyboardLocked = false;
      this.emit('keyboardLock', false);
    }
  }

  /**
   * Clear the field that contains the given 1-based position (row, col).
   * Fills every data cell with EBCDIC null (0x00) and marks the field as
   * modified so the host receives the cleared content on the next AID.
   * Call before typeText() to prevent partial overwrites of existing content.
   */
  clearFieldAt(row: number, col: number): void {
    const pos = (row - 1) * this.opts.cols + (col - 1);
    const field = this.getFieldAt(pos);
    if (!field || field.protected) return;
    const size = this.opts.rows * this.opts.cols;
    const startPos = (field.position + 1) % size;
    for (let i = 0; i < field.length; i++) {
      const p = (startPos + i) % size;
      this.screen.buffer[p] = 0x00;
      this.screen.graphic[p] = 0;
    }
    field.modified = true;
    this.screen.attributes[field.position] = field.attribute | FA.MDT;
  }

  /**
   * Search all screen lines for the first occurrence of `text` (case-insensitive).
   * Returns the 1-based { row, col } of the match, or null if not found.
   */
  findText(text: string): { row: number; col: number } | null {
    if (!text) return null;
    const lines = this.getScreenText();
    const upper = text.toUpperCase();
    for (let r = 0; r < lines.length; r++) {
      const idx = lines[r].toUpperCase().indexOf(upper);
      if (idx !== -1) return { row: r + 1, col: idx + 1 };
    }
    return null;
  }

  /**
   * Extract the ISPF short and long messages from the current screen.
   *
   * ISPF layout (standard 24×80 session with PANELID ON):
   *   Row 1  — Action bar (Menu / Utilities / …) or blank
   *   Row 2  — Blank (or scroll-arrow artifact)
   *   Row 3  — Panel title + SHORT MESSAGE in the right margin (~col 55+)
   *   Row 4  — "Option ===> " or "Command ===> "
   *   Row 24 — PF key line OR a LONG MESSAGE when one is active
   *
   * When there is no ISPF message both fields are null.
   */
  extractIspfMessage(): { short: string | null; long: string | null } {
    const lines = this.getScreenText();
    if (lines.length < 3) return { short: null, long: null };

    // ── Short message ────────────────────────────────────────────────────────
    // ISPF places the short message on the title row (usually row 3) in the
    // right portion, starting around column 55.  We scan rows 1-5 for the
    // first one that has blank content up to col 54 but non-blank from col 55.
    let short: string | null = null;
    const msgStartCol = 54; // 0-based index
    for (let r = 0; r < Math.min(5, lines.length); r++) {
      const line = lines[r];
      if (line.length <= msgStartCol) continue;
      const leftPart  = line.slice(0, msgStartCol).trimEnd();
      const rightPart = line.slice(msgStartCol).trim();
      // Must have content, not be the action bar, not be a separator line, and
      // the left part must contain actual title text (not all dashes/spaces).
      if (rightPart &&
          rightPart.length >= 3 &&
          !rightPart.includes('===>') &&
          !/^[-─=\s]+$/.test(rightPart) &&
          leftPart.trim().length > 0 &&
          !/^[-─=\s]+$/.test(leftPart.trim())) {
        short = rightPart;
        break;
      }
    }

    // ── Long message ─────────────────────────────────────────────────────────
    // Long message occupies row 24 when the host writes it; otherwise row 24
    // shows the PF key bindings.  A long message row does NOT start with "PF".
    let long: string | null = null;
    if (lines.length >= 24) {
      const row24 = lines[23].trim();
      // Long message does NOT look like a PF line, a panelId marker, or is empty
      if (row24 &&
          !/^PF\s*\d/i.test(row24) &&
          !row24.startsWith('F1=') &&
          !/^\*[A-Z@#$0-9]{2,8}$/.test(row24)) {
        long = row24;
      }
    }

    return { short, long };
  }

  /**
   * Parse the current screen as a columnar table.
   *
   * @param headerRow  1-based row containing column headers.
   *                   When 0 or omitted, the row is auto-detected by looking
   *                   for the first mostly-uppercase word row that doesn't
   *                   contain "===>".
   *
   * Column boundaries are derived from the contiguous non-space words in the
   * header line; each column extends to the start of the next.
   * Rows that are all-blank or consist of only separators (─, =, –) are skipped.
   */
  extractTableRows(headerRow?: number): { headers: string[]; rows: Record<string, string>[] } {
    const lines = this.getScreenText();
    const hIdx = (headerRow != null && headerRow > 0)
      ? headerRow - 1
      : this.autoDetectHeaderRow(lines);
    if (hIdx < 0 || hIdx >= lines.length) return { headers: [], rows: [] };

    const colDefs = this.detectColumnBoundaries(lines[hIdx]);
    if (colDefs.length === 0) return { headers: [], rows: [] };

    const headers = colDefs.map(c => c.name);
    const rows: Record<string, string>[] = [];

    for (let r = hIdx + 1; r < lines.length; r++) {
      const line = lines[r];
      if (!line.trim()) continue;
      if (/^[-=─\s]+$/.test(line.trim())) continue; // separator / underline rows
      // Skip PF key lines and COMMAND/OPTION prompt rows
      if (/^\s*(PF|F)\s*\d/i.test(line.trim())) continue;
      if (/COMMAND\s*==>/i.test(line) || /OPTION\s*==>/i.test(line)) continue;
      // Skip panelId markers (e.g. "*ISR@PRI", "*SDSF")
      if (/^\s*\*[A-Z@#$][A-Z@#$0-9]{1,7}\s*$/.test(line.trim())) continue;
      const record: Record<string, string> = {};
      for (const col of colDefs) {
        record[col.name] = (line.slice(col.start, col.end) || '').trim();
      }
      if (Object.values(record).every(v => !v)) continue;
      rows.push(record);
    }

    return { headers, rows };
  }

  private autoDetectHeaderRow(lines: string[]): number {
    for (let r = 0; r < Math.min(8, lines.length); r++) {
      const line = lines[r].trim();
      if (!line || line.includes('===>')) continue;
      const words = line.match(/\S+/g) || [];
      if (words.length < 2) continue;
      // Header rows are predominantly uppercase alphabetic words
      const upperCount = words.filter(w => w === w.toUpperCase() && /^[A-Z]/.test(w)).length;
      if (upperCount / words.length >= 0.6) return r;
    }
    return -1;
  }

  private detectColumnBoundaries(headerLine: string): Array<{ name: string; start: number; end: number }> {
    const cols: Array<{ name: string; start: number; end: number }> = [];
    const re = /\S+/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(headerLine)) !== null) {
      cols.push({ name: m[0], start: m.index, end: m.index + m[0].length });
    }
    // Extend each column's end to the start of the next
    for (let i = 0; i < cols.length - 1; i++) {
      cols[i].end = cols[i + 1].start;
    }
    if (cols.length > 0) {
      cols[cols.length - 1].end = Math.max(headerLine.length, cols[cols.length - 1].end);
    }
    return cols;
  }

  /**
   * Scroll through all pages by pressing `scrollKey` repeatedly until one of
   * the following stop conditions is met:
   *   - `stopText` appears on the current screen          → stopped = 'stopText'
   *   - The screen fingerprint is identical to the previous page → stopped = 'noChange'
   *   - `maxPages` pages have been collected               → stopped = 'maxPages'
   *   - `timeoutMs` milliseconds have elapsed              → stopped = 'timeout'
   *
   * Returns all accumulated screen lines (raw, unsanitised) plus metadata.
   * The first page (current screen before any scrolling) is always included.
   */
  async scrollAllPages(
    scrollKey: keyof typeof AID,
    stopText: string,
    maxPages = 200,
    timeoutMs = 30000,
    skipHeaderRows = 0,
  ): Promise<{ lines: string[]; pages: number; stopped: string }> {
    const allLines: string[] = [];
    const deadline = Date.now() + timeoutMs;
    let prevFingerprint = '';
    let headerFingerprint = ''; // fingerprint of the header rows to skip on subsequent pages
    let pages = 0;
    let stopped = 'maxPages';

    for (let i = 0; i < maxPages && Date.now() < deadline; i++) {
      const screenLines = this.getScreenText();
      const fingerprint = screenLines.map(l => l.trimEnd()).join('\n');

      // Same screen twice = we have hit the bottom
      if (i > 0 && fingerprint === prevFingerprint) { stopped = 'noChange'; break; }

      // On the first page, capture the header fingerprint to skip on later pages
      if (i === 0 && skipHeaderRows > 0) {
        headerFingerprint = screenLines.slice(0, skipHeaderRows).map(l => l.trimEnd()).join('\n');
      }

      for (let li = 0; li < screenLines.length; li++) {
        // Skip header rows on pages after the first
        if (i > 0 && skipHeaderRows > 0 && li < skipHeaderRows) continue;
        allLines.push(screenLines[li]);
      }
      pages++;

      // Stop text on this page?
      if (stopText && screenLines.some(l => l.toUpperCase().includes(stopText.toUpperCase()))) { stopped = 'stopText'; break; }

      prevFingerprint = fingerprint;

      // Press scroll key and wait for the host to respond
      await this.sendAID(scrollKey);
      const ok = await this.waitForKeyboardUnlock(Math.min(5000, deadline - Date.now()));
      if (!ok) { stopped = 'timeout'; break; }
    }

    if (Date.now() >= deadline) stopped = 'timeout';
    return { lines: allLines, pages, stopped };
  }

  /**
   * Return the last `n` screen snapshots (oldest first, max buffered).
   * Each snapshot is a string[] as returned by getScreenText().
   */
  getHistory(n = 10): string[][] {
    const count = Math.min(Math.max(1, n), this.screenHistory.length);
    return this.screenHistory.slice(-count);
  }

  /**
   * OMVS / NVT / SSCP-LU mode detection (Fix D, v2.6.0). Returns true when
   * the current session behaves as a line-oriented terminal instead of a
   * formatted 3270 panel. Editor UI uses this to switch to a scrollable
   * terminal renderer where the whole screen-history flow is visible at
   * once, not just the last 24 lines.
   */
  isTerminalMode(): boolean {
    const panelId = this.detectPanelId();
    if (panelId === 'TSO' || panelId === 'OMVS') return true;
    // No formatted fields AND no TN3270E mode → treat as line-mode.
    if (!this.screen.formatted && !this.tn3270eMode) return true;
    return false;
  }

  /**
   * Flatten screenHistory + current screen into a single stream of trimmed
   * lines, dropping consecutive-identical lines so a repeated banner isn't
   * emitted twice. Returns up to `maxLines` (default 400) from newest end.
   */
  getTerminalScrollback(maxLines: number = 400): string[] {
    const frames: string[][] = [...this.screenHistory, this.getScreenText()];
    const out: string[] = [];
    let prev = '';
    for (const frame of frames) {
      for (const line of frame) {
        const trimmed = line.replace(/\s+$/, '');
        if (trimmed === prev) continue;
        out.push(trimmed);
        prev = trimmed;
      }
    }
    if (out.length > maxLines) return out.slice(out.length - maxLines);
    return out;
  }

  // === PRIVATE: Telnet/TN3270 Protocol ===

  private setStatus(status: ConnectionStatus): void {
    const wasConnected = this.connection.status === 'connected';
    this.connection.status = status;
    this.emit('statusChange', this.connection);
    // Resolve the connect() promise on the FIRST transition into 'connected'.
    // This covers TN3270E FUNCTIONS IS acceptance and NVT/SSCP-LU data paths
    // where the host doesn't send an initial 3270 Write immediately. Without
    // this, the promise would only resolve on a Write, leaving the caller
    // hanging even though the session is technically ready.
    if (status === 'connected' && !wasConnected && this.pendingResolve) {
      const resolve = this.pendingResolve;
      this.pendingResolve = null;
      this.pendingReject = null;
      resolve();
    }
  }

  private processIncoming(data: Buffer): void {
    // During TLS/negotiation, emit each inbound chunk as hex so the bridge
    // server can log it to the Output channel. Cheap to compute (under 200
    // bytes typical), invaluable when diagnosing why a server-side flow
    // stalls after handshake.
    if (this.connection.status === 'negotiating' || this.connection.status === 'connecting') {
      try {
        this.emit('rawData', data.subarray(0, Math.min(data.length, 96)).toString('hex'));
      } catch { /* best-effort */ }
    }
    for (let i = 0; i < data.length; i++) {
      const byte = data[i];

      if (this.inSB) {
        if (byte === TELNET.IAC) {
          if (i + 1 < data.length && data[i + 1] === TELNET.SE) {
            i++; // skip SE
            this.handleSubnegotiation(this.sbBuffer);
            this.sbBuffer = [];
            this.inSB = false;
          } else if (i + 1 < data.length && data[i + 1] === TELNET.IAC) {
            i++; // escaped IAC in subneg
            this.sbBuffer.push(0xFF);
          }
        } else {
          this.sbBuffer.push(byte);
        }
        continue;
      }

      if (this.inIAC) {
        this.inIAC = false;
        switch (byte) {
          case TELNET.IAC:
            this.telnetBuffer.push(0xFF);
            break;
          case TELNET.DO:
          case TELNET.DONT:
          case TELNET.WILL:
          case TELNET.WONT:
            if (i + 1 < data.length) {
              i++;
              this.handleTelnetOption(byte, data[i]);
            }
            break;
          case TELNET.SB:
            this.inSB = true;
            this.sbBuffer = [];
            break;
          case TELNET.EOR:
            // End of Record — process the 3270 data stream
            this.process3270Stream(Buffer.from(this.telnetBuffer));
            this.telnetBuffer = [];
            break;
          default:
            break;
        }
        continue;
      }

      if (byte === TELNET.IAC) {
        this.inIAC = true;
        continue;
      }

      this.telnetBuffer.push(byte);
    }
  }

  private handleTelnetOption(verb: number, option: number): void {
    switch (option) {
      case TELOPT.BINARY:
        if (verb === TELNET.DO) {
          this.sendTelnet([TELNET.IAC, TELNET.WILL, TELOPT.BINARY]);
        } else if (verb === TELNET.WILL) {
          this.sendTelnet([TELNET.IAC, TELNET.DO, TELOPT.BINARY]);
        }
        break;

      case TELOPT.EOR:
        if (verb === TELNET.DO) {
          this.sendTelnet([TELNET.IAC, TELNET.WILL, TELOPT.EOR]);
        } else if (verb === TELNET.WILL) {
          this.sendTelnet([TELNET.IAC, TELNET.DO, TELOPT.EOR]);
        }
        break;

      case TELOPT.TERMINAL_TYPE:
        if (verb === TELNET.DO) {
          this.sendTelnet([TELNET.IAC, TELNET.WILL, TELOPT.TERMINAL_TYPE]);
        }
        break;

      case TELOPT.TN3270E:
        if (verb === TELNET.DO) {
          this.sendTelnet([TELNET.IAC, TELNET.WILL, TELOPT.TN3270E]);
          // Don't send DEVICE_TYPE REQUEST yet — wait for server's DEVICE_TYPE SEND
        } else if (verb === TELNET.WILL) {
          this.sendTelnet([TELNET.IAC, TELNET.DO, TELOPT.TN3270E]);
        }
        break;

      default:
        // Refuse unsupported options
        if (verb === TELNET.DO) {
          this.sendTelnet([TELNET.IAC, TELNET.WONT, option]);
        } else if (verb === TELNET.WILL) {
          this.sendTelnet([TELNET.IAC, TELNET.DONT, option]);
        }
        break;
    }
  }

  private handleSubnegotiation(data: number[]): void {
    if (data.length === 0) return;

    const option = data[0];
    switch (option) {
      case TELOPT.TERMINAL_TYPE:
        if (data.length >= 2 && data[1] === 0x01) { // SEND
          // Respond with terminal type
          const type = this.opts.deviceType;
          const response = [TELNET.IAC, TELNET.SB, TELOPT.TERMINAL_TYPE, 0x00]; // IS
          for (let i = 0; i < type.length; i++) {
            response.push(type.charCodeAt(i));
          }
          response.push(TELNET.IAC, TELNET.SE);
          this.sendTelnet(response);
        }
        break;

      case TELOPT.TN3270E:
        this.handleTN3270ESubneg(data.slice(1));
        break;
    }
  }

  private sendTN3270EDeviceType(): void {
    const type = this.opts.deviceType;
    const data: number[] = [TELNET.IAC, TELNET.SB, TELOPT.TN3270E,
      TN3270E.DEVICE_TYPE, TN3270E.REQUEST];
    for (let i = 0; i < type.length; i++) {
      data.push(type.charCodeAt(i));
    }
    // Send CONNECT <luName> if specified
    if (this.opts.luName) {
      data.push(TN3270E.CONNECT);
      for (let i = 0; i < this.opts.luName.length; i++) {
        data.push(this.opts.luName.charCodeAt(i));
      }
    }
    data.push(TELNET.IAC, TELNET.SE);
    this.sendTelnet(data);
  }

  private handleTN3270ESubneg(data: number[]): void {
    if (data.length === 0) return;

    // TN3270E subnegotiation payload is `<command> <what> [params...]`
    // (RFC 2355 §6.2 and §3.2 example). data[0] is the COMMAND verb.
    //
    // From server:
    //   SEND DEVICE-TYPE                → we send DEVICE-TYPE REQUEST <term> [CONNECT <lu>]
    //   DEVICE-TYPE IS <term> [CONNECT <lu>] → we send FUNCTIONS REQUEST <funcs>
    //   DEVICE-TYPE REJECT REASON <n>   → fall back to plain TN3270
    //   FUNCTIONS IS <funcs>            → session ready
    //   FUNCTIONS REQUEST <funcs>       → we send FUNCTIONS IS <same-funcs> to accept
    switch (data[0]) {
      case TN3270E.SEND:
        // Server: "please send me your DEVICE-TYPE"
        if (data.length >= 2 && data[1] === TN3270E.DEVICE_TYPE) {
          this.sendTN3270EDeviceType();
        }
        break;

      case TN3270E.DEVICE_TYPE:
        if (data.length >= 2 && data[1] === TN3270E.IS) {
          // Server accepted our device type (and optionally bound an LU).
          // Continue with basic-mode FUNCTIONS REQUEST (no optional functions).
          this.tn3270eMode = true;
          this.connection.tn3270e = true;
          // Best-effort LU-name extraction: after IS <term> comes CONNECT <lu>
          // as ASCII bytes. Kept optional — no failure if not present.
          const connectIdx = data.indexOf(TN3270E.CONNECT, 2);
          if (connectIdx > 0 && connectIdx < data.length - 1) {
            const luBytes = data.slice(connectIdx + 1);
            const lu = String.fromCharCode(...luBytes.filter(b => b >= 0x20 && b < 0x7f));
            if (lu) this.connection.luName = lu;
          }
          this.sendTelnet([
            TELNET.IAC, TELNET.SB, TELOPT.TN3270E,
            TN3270E.FUNCTIONS, TN3270E.REQUEST,
            TELNET.IAC, TELNET.SE,
          ]);
        } else if (data.length >= 2 && data[1] === TN3270E.REJECT) {
          // Server refused TN3270E — will proceed as plain TN3270. Note: at
          // this stage BINARY and EOR must already be independently WILL/DO
          // (they were during the reactive Telnet negotiation).
          this.tn3270eMode = false;
          this.connection.tn3270e = false;
        }
        break;

      case TN3270E.FUNCTIONS:
        if (data.length >= 2 && data[1] === TN3270E.IS) {
          // Both sides agreed on the functions set → session is ready.
          this.setStatus('connected');
          this.screen.keyboardLocked = false;
          this.emit('ready');
        } else if (data.length >= 2 && data[1] === TN3270E.REQUEST) {
          // Server proposed a function set. Basic clients (this one) accept
          // the empty set by echoing FUNCTIONS IS with the same payload
          // stripped of the REQUEST byte.
          const funcs = data.slice(2);
          this.sendTelnet([
            TELNET.IAC, TELNET.SB, TELOPT.TN3270E,
            TN3270E.FUNCTIONS, TN3270E.IS,
            ...funcs,
            TELNET.IAC, TELNET.SE,
          ]);
        }
        break;
    }
  }

  private process3270Stream(data: Buffer): void {
    if (data.length === 0) return;

    // Debug: emit raw data for troubleshooting
    this.emit('rawData', data.slice(0, Math.min(40, data.length)).toString('hex'));

    let offset = 0;

    // TN3270E header (5 bytes: type, request, response, seqnum[2])
    if (this.tn3270eMode) {
      if (data.length < 5) return;
      const dataType = data[0];
      offset = 5;
      if (dataType !== TN3270E.DATA_3270 && dataType !== TN3270E.DATA_SSCP_LU) {
        return; // Not a 3270 data stream
      }
    }

    if (offset >= data.length) return;

    const command = data[offset];
    offset++;

    // Normalize command: support both SNA and CCW (local channel) formats
    const isWrite = command === CMD.W || command === CMD_CCW.W;
    const isEraseWrite = command === CMD.EW || command === CMD_CCW.EW;
    const isEraseWriteAlt = command === CMD.EWA || command === CMD_CCW.EWA;
    const isReadBuffer = command === CMD.RB || command === CMD_CCW.RB;
    const isReadModified = command === CMD.RM || command === CMD_CCW.RM;
    const isReadModifiedAll = command === CMD.RMA || command === CMD_CCW.RMA;
    const isEAU = command === CMD.EAU || command === CMD_CCW.EAU;
    const isWSF = command === CMD.WSF || command === CMD_CCW.WSF;

    if (isWrite || isEraseWrite || isEraseWriteAlt) {
      if (isEraseWrite || isEraseWriteAlt) {
        this.eraseScreen();
      }
      if (offset < data.length) {
        const wcc = data[offset];
        offset++;
        this.processWCC(wcc);
        this.processWriteData(data, offset);
      }
    } else if (isReadBuffer || isReadModified || isReadModifiedAll) {
      // Read commands — send response
      this.sendReadResponse(command);
      return; // Don't update screen
    } else if (isEAU) {
      this.eraseAllUnprotected();
    } else if (isWSF) {
      // Write Structured Field — handle query reply etc.
      this.handleWSF(data, offset);
    } else {
      // May be data without command (SSCP-LU mode)
      if (!this.tn3270eMode) {
        // Try as NVT data
        offset--;
        this.processNVTData(data, offset);
      }
    }

    // Parse fields from buffer
    this.parseFields();

    // Ensure status is connected before emitting screenUpdate. setStatus
    // will also resolve the pending connect() promise on the first
    // negotiating→connected transition (see setStatus above), so any path
    // that reaches here — Write, EraseWrite, WSF, NVT — completes connect().
    if (this.connection.status !== 'connected') {
      this.screen.keyboardLocked = false;
      this.setStatus('connected');
    } else if (this.pendingResolve) {
      // Session was already 'connected' (e.g. via FUNCTIONS IS) but a later
      // Write is our confirmation that data flows. Resolve now if still open.
      const resolve = this.pendingResolve;
      this.pendingResolve = null;
      this.pendingReject = null;
      resolve();
    }

    // Then emit screen update (sidebar will see correct connected state)
    const snapshot = this.getScreenText();
    this.emit('screenUpdate', snapshot);
    // Maintain screen history (last 10 states) — only when content actually changes
    const fingerprint = snapshot.map(l => l.trimEnd()).join('\n');
    const last = this.screenHistory[this.screenHistory.length - 1];
    const lastFp = last ? last.map(l => l.trimEnd()).join('\n') : '';
    if (fingerprint !== lastFp) {
      this.screenHistory.push(snapshot);
      // Deeper scrollback when we're in OMVS/line-oriented mode so the
      // editor's terminal-mode renderer (Fix D, v2.6.0) has enough history
      // to show a useful shell session.
      const cap = this.isTerminalMode() ? 40 : 10;
      while (this.screenHistory.length > cap) this.screenHistory.shift();
    }
  }

  private processWCC(wcc: number): void {
    if (wcc & WCC.KEYBOARD_RESTORE) {
      this.screen.keyboardLocked = false;
      this.emit('keyboardLock', false);
    }
    if (wcc & WCC.ALARM) {
      this.lastAlarm = true;
      this.emit('alarm');
    }
    if (wcc & WCC.RESET_MDT) {
      // Reset modified data tags
      for (const field of this.screen.fields) {
        field.modified = false;
      }
    }
  }

  private processWriteData(data: Buffer, offset: number): void {
    let pos = this.screen.cursor;
    const size = this.opts.rows * this.opts.cols;

    while (offset < data.length) {
      const byte = data[offset];
      offset++;

      switch (byte) {
        case ORDER.SBA: {
          if (offset + 1 >= data.length) return;
          pos = decodeBufferAddress(data[offset], data[offset + 1]);
          offset += 2;
          this.screen.cursor = pos;
          break;
        }

        case ORDER.SF: {
          if (offset >= data.length) return;
          const attr = data[offset];
          offset++;
          this.screen.attributes[pos] = attr;
          this.screen.buffer[pos] = 0x00;
          pos = (pos + 1) % size;
          break;
        }

        case ORDER.SFE: {
          if (offset >= data.length) return;
          const pairs = data[offset];
          offset++;
          let fieldAttr = 0;
          for (let p = 0; p < pairs; p++) {
            if (offset + 1 >= data.length) return;
            const attrType = data[offset];
            const attrValue = data[offset + 1];
            offset += 2;
            if (attrType === 0xC0) { // Basic field attribute
              fieldAttr = attrValue;
            }
          }
          this.screen.attributes[pos] = fieldAttr || 0x60; // default protected
          this.screen.buffer[pos] = 0x00;
          pos = (pos + 1) % size;
          break;
        }

        case ORDER.IC: {
          this.screen.cursor = pos;
          break;
        }

        case ORDER.RA: {
          if (offset + 2 >= data.length) return;
          const endAddr = decodeBufferAddress(data[offset], data[offset + 1]);
          const fillByte = data[offset + 2];
          offset += 3;
          while (pos !== endAddr) {
            this.screen.buffer[pos] = fillByte;
            this.screen.attributes[pos] = 0;
            this.screen.graphic[pos] = 0;
            pos = (pos + 1) % size;
          }
          break;
        }

        case ORDER.EUA: {
          if (offset + 1 >= data.length) return;
          const endAddr = decodeBufferAddress(data[offset], data[offset + 1]);
          offset += 2;
          while (pos !== endAddr) {
            if (this.screen.attributes[pos] === 0) {
              this.screen.buffer[pos] = 0x00;
              this.screen.graphic[pos] = 0;
            }
            pos = (pos + 1) % size;
          }
          break;
        }

        case ORDER.PT: {
          // Skip to next unprotected field
          const startPos = pos;
          do {
            pos = (pos + 1) % size;
            if (this.screen.attributes[pos] !== 0) {
              const attr = this.screen.attributes[pos];
              if (!(attr & FA.PROTECTED)) {
                pos = (pos + 1) % size;
                break;
              }
            }
          } while (pos !== startPos);
          break;
        }

        case ORDER.SA:
        case ORDER.MF: {
          // Set Attribute / Modify Field — skip the pair
          if (offset + 1 < data.length) {
            offset += 2;
          }
          break;
        }

        case ORDER.GE: {
          // Graphic Escape — next byte is from APL/graphic character set
          if (offset < data.length) {
            this.screen.buffer[pos] = data[offset];
            this.screen.attributes[pos] = 0;
            this.screen.graphic[pos] = 1;
            offset++;
            pos = (pos + 1) % size;
          }
          break;
        }

        default: {
          // Regular data character
          this.screen.buffer[pos] = byte;
          this.screen.attributes[pos] = 0;
          this.screen.graphic[pos] = 0;
          pos = (pos + 1) % size;
          break;
        }
      }
    }
    this.screen.cursor = pos;
  }

  private processNVTData(data: Buffer, offset: number): void {
    // Simple NVT/SSCP-LU mode — write characters at cursor
    let pos = this.screen.cursor;
    const size = this.opts.rows * this.opts.cols;
    for (let i = offset; i < data.length; i++) {
      this.screen.buffer[pos] = data[i];
      this.screen.attributes[pos] = 0;
      pos = (pos + 1) % size;
    }
    this.screen.cursor = pos;
    // In SSCP-LU mode, any data received means we're effectively connected
    if (this.connection.status === 'negotiating' || this.connection.status === 'connecting') {
      this.setStatus('connected');
      this.screen.keyboardLocked = false;
      this.emit('ready');
    }
  }

  /**
   * Process a raw 3270 command embedded inside a WSF Outbound 3270DS.
   * The data starts with the SNA command byte (e.g. 0xF1=Write, 0xF5=EW).
   */
  private process3270Command(data: Buffer): void {
    if (data.length === 0) return;
    const command = data[0];
    let offset = 1;

    const isWrite = command === CMD.W || command === CMD_CCW.W;
    const isEraseWrite = command === CMD.EW || command === CMD_CCW.EW;
    const isEraseWriteAlt = command === CMD.EWA || command === CMD_CCW.EWA;

    if (isWrite || isEraseWrite || isEraseWriteAlt) {
      if (isEraseWrite || isEraseWriteAlt) {
        this.eraseScreen();
      }
      if (offset < data.length) {
        const wcc = data[offset];
        offset++;
        this.processWCC(wcc);
        this.processWriteData(data, offset);
      }
      this.parseFields();
      this.emit('screenUpdate', this.getScreenText());
    }
  }

  private handleWSF(data: Buffer, offset: number): void {
    // Write Structured Field — parse each SF by length
    while (offset < data.length) {
      if (offset + 2 > data.length) break;
      const len = (data[offset] << 8) | data[offset + 1];
      if (len === 0 || len < 3) break;
      const sfId = data[offset + 2];

      if (sfId === 0x40) { // Outbound 3270DS
        // Contains: partition ID (1 byte) + embedded 3270 command
        const payload = data.slice(offset + 3, offset + len);
        if (payload.length >= 2) {
          // Skip partition ID byte, process the embedded 3270 write command
          this.process3270Command(payload.slice(1));
        }
      } else if (sfId === 0x01) { // Read Partition
        const opOffset = offset + 3;
        if (opOffset + 1 < offset + len) {
          const partitionId = data[opOffset];
          const opCode = data[opOffset + 1];
          if (opCode === 0x02) {
            // Query: send full QR with Summary
            this.sendQueryReply(null);
          } else if (opCode === 0x03) {
            // Query List: filter by requested codes
            const listType = data[opOffset + 2];
            if (listType === 0x00) {
              // QCODE_LIST: send only requested codes (no Summary)
              const requestedCodes: number[] = [];
              for (let i = opOffset + 3; i < offset + len; i++) {
                requestedCodes.push(data[i]);
              }
              this.sendQueryReply(requestedCodes);
            } else {
              // ALL (0xFF): send everything
              this.sendQueryReply(null);
            }
          } else {
            this.sendQueryReply(null);
          }
        } else {
          this.sendQueryReply(null);
        }
      }
      offset += len;
    }
  }

  private sendQueryReply(filterCodes: number[] | null): void {
    // Build Query Reply matching the working test-login.js implementation
    const rows = this.opts.rows;
    const cols = this.opts.cols;
    const SFID_QUERY_REPLY = 0x81;

    // QCode constants
    const QC = {
      SUMMARY: 0x80,
      USABLE_AREA: 0x81,
      ALPHANUMERIC_PARTITIONS: 0x84,
      CHARACTER_SETS: 0x85,
      COLOR: 0x86,
      HIGHLIGHTING: 0x87,
      REPLY_MODES: 0x88,
      IMPLICIT_PARTITION: 0xA6,
    };

    const reply: number[] = [];

    // Helper: build a single Query Reply structured field (skip if not in filter)
    const addQR = (qcode: number, payload: number[]) => {
      if (filterCodes && !filterCodes.includes(qcode)) return;
      const totalLen = payload.length + 4;
      reply.push((totalLen >> 8) & 0xFF, totalLen & 0xFF, SFID_QUERY_REPLY, qcode, ...payload);
    };

    // Summary: only include when not filtering (first Query response)
    if (!filterCodes) {
      addQR(QC.SUMMARY, [
        QC.SUMMARY,
        QC.USABLE_AREA,
        QC.ALPHANUMERIC_PARTITIONS,
        QC.CHARACTER_SETS,
        QC.COLOR,
        QC.HIGHLIGHTING,
        QC.REPLY_MODES,
        QC.IMPLICIT_PARTITION,
      ]);
    }

    // Usable Area — correct buffer size for Model 2 (1920 = 0x0780)
    addQR(QC.USABLE_AREA, [
      0x01, 0x00,       // 12/14 bit addressing, variable cells
      0x00, cols,       // width in cells
      0x00, rows,       // height in cells
      0x01,             // units = mm
      0x00, 0x0A, 0x02, 0xE5, // Xr numerator, denominator
      0x00, 0x02, 0x00, 0x6F, // Yr numerator, denominator
      0x09, 0x0C,       // default cell X, Y in units
      ((rows * cols) >> 8) & 0xFF, (rows * cols) & 0xFF,
    ]);

    // Alphanumeric Partitions
    addQR(QC.ALPHANUMERIC_PARTITIONS, [
      0x00,             // max partitions
      ((rows * cols) >> 8) & 0xFF, (rows * cols) & 0xFF,
      0x00,             // flags
    ]);

    // Character Sets
    addQR(QC.CHARACTER_SETS, [
      0x82, 0x00, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x07, 0x00, 0x10, 0x00, 0x02, 0xB9, 0x00, 0x25,
      0x01, 0x00, 0xF1, 0x03, 0xC3, 0x01, 0x36,
    ]);

    // Color (8 pairs for basic 7-color)
    addQR(QC.COLOR, [
      0x00, 0x08, 0x00,
      0xF4, 0xF1, 0xF1, 0xF2, 0xF2, 0xF3, 0xF3, 0xF4,
      0xF4, 0xF5, 0xF5, 0xF6, 0xF6, 0xF7, 0xF7,
    ]);

    // Highlighting (4 pairs)
    addQR(QC.HIGHLIGHTING, [
      0x04,
      0x00, 0xF0, 0xF1, 0xF1, 0xF2, 0xF2, 0xF4, 0xF4,
    ]);

    // Reply Modes
    addQR(QC.REPLY_MODES, [
      0x00, // field mode
    ]);

    // Implicit Partition: 24x80 default and alternate
    addQR(QC.IMPLICIT_PARTITION, [
      0x00, 0x00,       // reserved
      0x0B,             // data length
      0x01,             // type = display
      0x00,             // reserved
      0x00, cols,       // default width
      0x00, rows,       // default height
      0x00, cols,       // alternate width
      0x00, rows,       // alternate height
    ]);

    // Build the full response
    const stream: number[] = [];
    if (this.tn3270eMode) {
      stream.push(TN3270E.DATA_3270, 0x00, 0x00, 0x00, 0x00);
    }
    stream.push(0x88); // AID = Structured Field (0x88)
    stream.push(...reply);

    this.sendDataStream(Buffer.from(stream));
  }

  private eraseScreen(): void {
    const size = this.opts.rows * this.opts.cols;
    this.screen.buffer.fill(0x00);
    this.screen.attributes.fill(0x00);
    this.screen.graphic.fill(0x00);
    this.screen.cursor = 0;
    this.screen.fields = [];
    this.screen.formatted = false;
  }

  private eraseAllUnprotected(): void {
    const size = this.opts.rows * this.opts.cols;
    for (let i = 0; i < size; i++) {
      if (this.screen.attributes[i] === 0) {
        // Check if this position is in an unprotected field
        const field = this.getFieldAt(i);
        if (field && !field.protected) {
          this.screen.buffer[i] = 0x00;
          this.screen.graphic[i] = 0;
        }
      }
    }
    // Move cursor to first unprotected field
    for (const field of this.screen.fields) {
      if (!field.protected) {
        this.screen.cursor = (field.position + 1) % (this.opts.rows * this.opts.cols);
        break;
      }
    }
  }

  private parseFields(): void {
    const size = this.opts.rows * this.opts.cols;
    this.screen.fields = [];
    let firstFieldPos = -1;

    for (let i = 0; i < size; i++) {
      if (this.screen.attributes[i] !== 0) {
        if (firstFieldPos === -1) firstFieldPos = i;
        const attr = this.screen.attributes[i];
        // Find length (until next field attribute or wrap)
        let length = 0;
        let pos = (i + 1) % size;
        while (this.screen.attributes[pos] === 0 && pos !== i) {
          length++;
          pos = (pos + 1) % size;
        }

        this.screen.fields.push({
          position: i,
          attribute: attr,
          length,
          protected: !!(attr & FA.PROTECTED),
          numeric: !!(attr & FA.NUMERIC),
          hidden: (attr & FA.DISPLAY_MASK) === FA.DISPLAY_HIDDEN,
          intense: (attr & FA.DISPLAY_MASK) === FA.DISPLAY_INTENSE,
          modified: !!(attr & FA.MDT),
        });
      }
    }

    this.screen.formatted = this.screen.fields.length > 0;
  }

  private getFieldAt(pos: number): Field | null {
    const size = this.opts.rows * this.opts.cols;
    // Walk backwards to find the field attribute for this position
    let check = pos;
    for (let i = 0; i < size; i++) {
      if (this.screen.attributes[check] !== 0) {
        return this.screen.fields.find(f => f.position === check) || null;
      }
      check = (check - 1 + size) % size;
    }
    return null;
  }

  private writeToBuffer(pos: number, byte: number): void {
    if (this.screen.attributes[pos] === 0) {
      this.screen.buffer[pos] = byte;
      this.screen.graphic[pos] = 0;
    }
  }

  private markFieldModified(pos: number): void {
    const field = this.getFieldAt(pos);
    if (field) {
      field.modified = true;
      this.screen.attributes[field.position] = field.attribute | FA.MDT;
    }
  }

  private buildReadModifiedResponse(aidByte: number): Buffer {
    const size = this.opts.rows * this.opts.cols;
    const response: number[] = [];

    if (this.tn3270eMode) {
      response.push(TN3270E.DATA_3270, 0x00, 0x00, 0x00, 0x00);
    }

    // AID byte
    response.push(aidByte);

    // Cursor address
    const [c1, c2] = encodeBufferAddress(this.screen.cursor, size);
    response.push(c1, c2);

    // PA, CLEAR, and ATTN keys carry no field data — only AID byte + cursor address
    if (aidByte === AID.PA1 || aidByte === AID.PA2 || aidByte === AID.PA3 ||
        aidByte === AID.CLEAR || aidByte === AID.ATTN) {
      return Buffer.from(response);
    }

    // Send modified fields
    // Send ALL modified fields (including protected with MDT set)
    for (const field of this.screen.fields) {
      if (field.modified) {
        const startPos = (field.position + 1) % size;
        // SBA order
        response.push(ORDER.SBA);
        const [a1, a2] = encodeBufferAddress(startPos, size);
        response.push(a1, a2);
        // Field data — skip null bytes (0x00), send everything else
        for (let i = 0; i < field.length; i++) {
          const pos = (startPos + i) % size;
          const b = this.screen.buffer[pos];
          if (b !== 0x00) {
            response.push(b);
          }
        }
      }
    }

    return Buffer.from(response);
  }

  private sendReadResponse(command: number): void {
    // Build read buffer response
    const size = this.opts.rows * this.opts.cols;
    const response: number[] = [];

    if (this.tn3270eMode) {
      response.push(TN3270E.DATA_3270, 0x00, 0x00, 0x00, 0x00);
    }

    response.push(AID.NONE);
    const [c1, c2] = encodeBufferAddress(this.screen.cursor, size);
    response.push(c1, c2);

    // Full buffer content
    for (let i = 0; i < size; i++) {
      if (this.screen.attributes[i] !== 0) {
        response.push(ORDER.SF, this.screen.attributes[i]);
      } else {
        response.push(this.screen.buffer[i] || 0x40);
      }
    }

    this.sendDataStream(Buffer.from(response));
  }

  private sendDataStream(data: Buffer): void {
    if (!this.socket) return;
    // Escape IAC bytes and append IAC EOR
    const escaped: number[] = [];
    for (let i = 0; i < data.length; i++) {
      escaped.push(data[i]);
      if (data[i] === 0xFF) {
        escaped.push(0xFF); // Double IAC
      }
    }
    escaped.push(TELNET.IAC, TELNET.EOR);
    this.socket.write(Buffer.from(escaped));
  }

  private sendTelnet(data: number[]): void {
    if (!this.socket) return;
    if (this.connection.status === 'negotiating' || this.connection.status === 'connecting') {
      try {
        this.emit(
          'rawSend',
          Buffer.from(data.slice(0, Math.min(data.length, 96))).toString('hex')
        );
      } catch { /* best-effort */ }
    }
    this.socket.write(Buffer.from(data));
  }
}

/**
 * Normalize a certificate fingerprint to uppercase, colon-separated
 * hex pairs (e.g. `66:AF:4D:1A:…`). Accepts input with or without colons
 * and in any case. Returns undefined for empty/nullish input.
 */
function normalizeFingerprint(input: string | undefined): string | undefined {
  if (!input) return undefined;
  const hex = input.replace(/[^0-9a-fA-F]/g, '').toUpperCase();
  if (hex.length < 40) return undefined;
  return hex.match(/.{2}/g)!.join(':');
}
