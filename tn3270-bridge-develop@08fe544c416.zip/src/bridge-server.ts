/**
 * HTTP Bridge Server — Exposes TN3270 session control via localhost REST API
 *
 * Endpoints (1.4.0):
 *   GET  /status                          — Connection and session status (+ panelId)
 *   POST /connect                         — Connect to mainframe { host, port, luName? }
 *   POST /disconnect                      — Disconnect
 *   GET  /screen                          — Read current screen (compact by default in 1.4.0)
 *   GET  /screen?compact=false            — Full 24×80 lines (legacy 1.3.x shape)
 *   GET  /screen?nonblank=true            — Only non-blank rows, prefixed "NN: text"
 *   GET  /screen/fields                   — Input fields
 *   GET  /screen/text?row=&col=&length=   — Slice of screen text
 *   GET  /screen/region?row=&col=&rows=&cols=  — Rectangular region
 *   POST /send                            — Send text + AID with semantic resolution
 *   GET  /send?text=&aid=&row=&col=       — Same as POST but via query string (shell-safe)
 *   POST /key/<AID>                       — Press a single AID key (PF1..PF24, ENTER, PA1..PA3, CLEAR)
 *   POST /attn                             — Send Telnet IAC IP interrupt (works even when keyboard locked)
 *   POST /wait                            — Wait for text / unlock / panel / cursor
 *   POST /cursor                          — Move cursor to row/col without pressing a key
 *   GET  /screen/find?text=               — Find text on screen; returns {row,col}
 *   GET  /screen/table?headerRow=         — Parse columnar table; returns {headers,rows}
 *   GET  /screen/history?last=            — Last N screen snapshots (max 10)
 *   POST /screen/readall                  — Scroll all pages; returns accumulated lines
 *   POST /exec                            — Run a sequence of send/wait steps
 *   POST /login                           — Run a configured login profile
 *   GET  /debug                           — Diagnostics
 *
 * Notes:
 *   - Accepts application/json AND application/x-www-form-urlencoded bodies.
 *   - /send waits for keyboard unlock by default (tn3270Bridge.defaultWaitForUnlock).
 *   - /screen is compact by default (tn3270Bridge.defaultCompactScreen).
 *   - Login profiles store passwords in VS Code SecretStorage under key `tn3270.<profile>.password`.
 */
import * as http from 'http';
import { randomBytes } from 'node:crypto';
import * as vscode from 'vscode';
import { Tn3270Client } from './tn3270-client';
import { TlsOptions } from './tn3270-protocol';
import { apiTokenMatches, redactSecrets, validateDatasetReference } from './security';
import { LocalCredentialBroker } from './local-credential-broker';
import { extractFromScreen, ExtractRequest } from './screen-extract';
import { SessionRecorder } from './session-recorder';

export interface BridgeServerState {
  running: boolean;
  port: number;
  connected: boolean;
  host?: string;
  mainframePort?: number;
}

const AID_KEYS = new Set([
  'ENTER', 'CLEAR', 'PA1', 'PA2', 'PA3',
  'PF1','PF2','PF3','PF4','PF5','PF6','PF7','PF8','PF9','PF10','PF11','PF12',
  'PF13','PF14','PF15','PF16','PF17','PF18','PF19','PF20','PF21','PF22','PF23','PF24',
  'SYSREQ','ATTN',
]);

const MAX_REQUEST_BODY_BYTES = 10 * 1024 * 1024;

/** Screen model → device type + dimensions mapping */
const SCREEN_MODELS: Record<string, { rows: number; cols: number; deviceType: string }> = {
  model2: { rows: 24, cols: 80,  deviceType: 'IBM-3278-2-E' },
  model3: { rows: 32, cols: 80,  deviceType: 'IBM-3278-3-E' },
  model4: { rows: 43, cols: 80,  deviceType: 'IBM-3278-4-E' },
  model5: { rows: 27, cols: 132, deviceType: 'IBM-3278-5-E' },
};

/** Named session (non-default) — created via POST /session */
interface ExtraSession {
  id: string;
  client: Tn3270Client;
  sendQueue: Promise<unknown>;
  host: string;
  port: number;
  model: string;
  connectedAt: number;
}

export class BridgeServer {
  private server: http.Server | null = null;
  private client: Tn3270Client | null = null;
  private _state: BridgeServerState;
  private _onStateChange = new vscode.EventEmitter<BridgeServerState>();
  readonly onStateChange = this._onStateChange.event;
  private outputChannel: vscode.OutputChannel;
  private lastRawData: string[] = [];
  private stateChangeTimer: ReturnType<typeof setTimeout> | null = null;
  /** Serializes /send /key /exec /login so concurrent agent calls don't race */
  private sendQueue: Promise<unknown> = Promise.resolve();
  /** Named sessions (non-default) created via POST /session */
  private extraSessions = new Map<string, ExtraSession>();
  private apiTokenPromise: Promise<string>;
  private credentialBroker: LocalCredentialBroker | null = null;
  /**
   * Auto-reconnect state (v2.6.0). `userInitiatedDisconnect` prevents the
   * reconnect logic from firing on intentional teardowns (user click,
   * `POST /disconnect`, new `/connect` replacing the session). `lastConnectParams`
   * holds the exact args passed to the last successful `connectTo` so the
   * retry uses identical settings.
   */
  private userInitiatedDisconnect: boolean = false;
  private lastConnectParams: {
    host: string; port: number; luName?: string;
    tlsOverride?: TlsOptions; modelOverride?: string;
  } | null = null;
  private reconnectInProgress: boolean = false;
  /** Session recorder (v2.6.0). Active only while tn3270Bridge.recording.enabled is true. */
  private recorder: SessionRecorder | null = null;
  /** Getter used by the command palette handler `Save Session Recording`. */
  getRecorder(): SessionRecorder | null { return this.recorder; }
  /** ISO timestamp when this bridge instance was created — surfaced in /health for autodiscovery. */
  private readonly startedAt: string = new Date().toISOString();
  /** Absolute path of the running extension, so clients can pick the newest instance. */
  private readonly extensionPath: string;

  constructor(private context: vscode.ExtensionContext) {
    this._state = { running: false, port: 7327, connected: false };
    this.outputChannel = vscode.window.createOutputChannel('TN3270 Bridge');
    this.apiTokenPromise = this.ensureApiToken();
    this.extensionPath = context.extensionPath;
    context.subscriptions.push(this.outputChannel, this._onStateChange);
  }

  get state(): BridgeServerState { return { ...this._state }; }

  async copyApiToken(): Promise<void> {
    const token = await this.apiTokenPromise;
    await vscode.env.clipboard.writeText(token);
  }

  private async ensureApiToken(): Promise<string> {
    const secretKey = 'tn3270.apiToken';
    const existing = await this.context.secrets.get(secretKey);
    if (existing) return existing;
    const generated = randomBytes(32).toString('base64url');
    await this.context.secrets.store(secretKey, generated);
    return generated;
  }

  private fireStateChange(): void {
    if (this.stateChangeTimer) clearTimeout(this.stateChangeTimer);
    this.stateChangeTimer = setTimeout(() => {
      this.stateChangeTimer = null;
      this._onStateChange.fire(this._state);
    }, 100);
  }

  private fireStateChangeImmediate(): void {
    if (this.stateChangeTimer) { clearTimeout(this.stateChangeTimer); this.stateChangeTimer = null; }
    this._onStateChange.fire(this._state);
  }

  start(): void {
    if (this.server) return;
    const cfg = vscode.workspace.getConfiguration('tn3270Bridge');
    const port = cfg.get<number>('port', 7327);
    this.tryListen(port, port, 5);
  }

  stop(): void {
    if (this.server) { this.server.close(); this.server = null; }
    void this.credentialBroker?.stop();
    this.credentialBroker = null;
    this.disconnectClient();
    for (const session of this.extraSessions.values()) session.client.disconnect();
    this.extraSessions.clear();
    this._state = { ...this._state, running: false };
    this.fireStateChangeImmediate();
    this.outputChannel.appendLine('[Server] Stopped');
  }

  toggle(): void { if (this._state.running) this.stop(); else this.start(); }
  getClient(): Tn3270Client | null { return this.client; }

  /**
   * Public accessor for the multi-session UI (v2.6.0). Returns the client
   * that owns a given session id, or the default client for '' / 'default'.
   */
  getClientFor(sessionId: string): Tn3270Client | null {
    return this.clientFor(sessionId || 'default');
  }

  /**
   * Snapshot of all sessions (default + named) — used by the editor panel
   * to draw its tab strip. Same shape as `GET /sessions`.
   */
  listSessions(): Record<string, {
    connected: boolean;
    host?: string;
    port?: number;
    panelId?: string | null;
    model?: string | null;
    connectedAt?: string;
  }> {
    const sessions: Record<string, any> = {
      default: {
        connected: !!this.client && this.client.state.status === 'connected',
        host: this.client?.state.host,
        port: this.client?.state.port,
        panelId: this.client?.detectPanelId() ?? null,
        model: this.client ? `${this.client.screenState.rows}x${this.client.screenState.cols}` : null,
      },
    };
    this.extraSessions.forEach((s, id) => {
      const c = s.client;
      const cs = c.state.status === 'connected';
      sessions[id] = {
        connected: cs,
        host: s.host,
        port: s.port,
        model: s.model,
        panelId: cs ? c.detectPanelId() : null,
        connectedAt: s.connectedAt,
      };
    });
    return sessions;
  }

  /** Close a named session (default cannot be closed via this API). */
  async closeSession(sessionId: string): Promise<boolean> {
    if (!sessionId || sessionId === 'default') return false;
    const s = this.extraSessions.get(sessionId);
    if (!s) return false;
    s.client.disconnect();
    this.extraSessions.delete(sessionId);
    this.fireStateChangeImmediate();
    return true;
  }

  // ─── Multi-session helpers ───────────────────────────────────────────────

  /** Extract session id from URL query string (?session=<id>). Default: 'default'. */
  private sessionIdFrom(url: URL): string {
    return url.searchParams.get('session') || 'default';
  }

  /** Return the Tn3270Client for a given session id, or null if not found/connected. */
  private clientFor(sid: string): Tn3270Client | null {
    if (!sid || sid === 'default') return this.client;
    return this.extraSessions.get(sid)?.client ?? null;
  }

  /**
   * Validate that a session is connected and return its client.
   * Writes a 400 error response and returns null if not connected.
   */
  private requireClient(sid: string, res: http.ServerResponse): Tn3270Client | null {
    const c = this.clientFor(sid);
    if (!c || c.state.status !== 'connected') {
      res.writeHead(400); res.end(JSON.stringify({ error: 'Not connected' })); return null;
    }
    return c;
  }

  /** Enqueue a send operation on the correct session queue. */
  private enqueueOnSession(sid: string, op: () => Promise<void>): boolean {
    if (!sid || sid === 'default') {
      this.sendQueue = this.sendQueue.then(op).catch(() => undefined);
      return true;
    } else {
      const s = this.extraSessions.get(sid);
      if (!s) return false;
      s.sendQueue = s.sendQueue.then(op).catch(() => undefined);
      return true;
    }
  }

  private enqueueOrReject(sid: string, res: http.ServerResponse, op: () => Promise<void>): void {
    if (!this.enqueueOnSession(sid, op)) {
      res.writeHead(404); res.end(JSON.stringify({ error: `Session not found: ${sid}` }));
    }
  }

  async connectTo(host: string, port: number, luName?: string, tlsOverride?: TlsOptions, modelOverride?: string): Promise<{ success: boolean; error?: string; errorCode?: string; errorHint?: string; screen?: string[] }> {
    const cfg = vscode.workspace.getConfiguration('tn3270Bridge');
    const hadClient = !!this.client;
    this.disconnectClient();
    // Small cooldown after tearing down a prior session before dialing a
    // fresh one. Many z/OS Communications Server TN3270 setups debounce
    // rapid FIN+SYN cycles from the same source IP by silently dropping
    // the new SYN for up to a few seconds, which used to surface as
    // TLS_HANDSHAKE_TIMEOUT. 500 ms is enough to let the previous socket
    // fully close on both ends without user-visible latency.
    if (hadClient) await new Promise(r => setTimeout(r, 500));

    const tlsOpts = await this.resolveTlsOptions(tlsOverride, host, port);

    // Resolve screen model: per-call override → settings → default (model2)
    const modelKey = modelOverride || cfg.get<string>('screenModel', 'model2');
    const screenModel = SCREEN_MODELS[modelKey] || SCREEN_MODELS.model2;

    this.client = new Tn3270Client({
      host, port,
      luName: luName || cfg.get<string>('luName', ''),
      rows: screenModel.rows,
      cols: screenModel.cols,
      deviceType: screenModel.deviceType,
      timeout: cfg.get<number>('keyboardTimeout', 30000),
      codePage: cfg.get<string>('codePage', 'cp037') === 'cp500' ? 500 : 37,
      tls: tlsOpts,
    });

    // Session recording (v2.6.0). Create/re-create the recorder on each
    // successful connect so its metadata reflects the current host.
    const recCfg = vscode.workspace.getConfiguration('tn3270Bridge.recording');
    if (recCfg.get<boolean>('enabled', false)) {
      this.recorder = new SessionRecorder(
        recCfg.get<number>('maxFrames', 2000),
        recCfg.get<boolean>('maskSecrets', true),
        host, port,
      );
    } else {
      this.recorder = null;
    }

    this.client.on('screenUpdate', () => {
      this._state = { ...this._state, connected: true, host, mainframePort: port };
      this.fireStateChange();
      if (this.recorder && this.client) {
        const cols = this.client.screenState.cols;
        const cursor = this.client.screenState.cursor;
        this.recorder.push({
          panelId: this.client.detectPanelId() ?? null,
          lines: this.client.getScreenText().map(l => l.replace(/\s+$/, '')),
          keyboardLocked: this.client.screenState.keyboardLocked,
          cursor: {
            row: Math.floor(cursor / cols) + 1,
            col: (cursor % cols) + 1,
          },
        });
      }
    });
    this.client.on('rawData', (hex: string) => {
      // Always log negotiation-phase bytes to the Output channel — they are
      // short, contain no user data, and are essential for diagnosing "TLS
      // ok but TN3270 timed out" incidents. Full-session raw capture still
      // requires enableDiagnostics.
      const status = this.client?.state.status;
      if (status === 'negotiating' || status === 'connecting') {
        this.outputChannel.appendLine(`[TN3270 nego ← host] ${hex}`);
      }
      if (!cfg.get<boolean>('enableDiagnostics', false)) return;
      this.lastRawData.push(hex);
      if (this.lastRawData.length > 10) this.lastRawData.shift();
      this.outputChannel.appendLine(`[RAW] ${hex}`);
    });
    this.client.on('rawSend', (hex: string) => {
      this.outputChannel.appendLine(`[TN3270 nego → host] ${hex}`);
    });
    // Remember the connect parameters so auto-reconnect can retry with
    // the exact same host/port/luName/tls after a passive drop.
    this.lastConnectParams = { host, port, luName, tlsOverride, modelOverride };

    this.client.on('disconnected', () => {
      this._state = { ...this._state, connected: false };
      this.fireStateChangeImmediate();
      // Auto-reconnect (v2.6.0). Only fires when:
      //   (a) config `tn3270Bridge.autoReconnect.enabled` is true,
      //   (b) the disconnect was NOT initiated by the user or a new /connect,
      //   (c) we have the last connect params to retry with.
      if (this.userInitiatedDisconnect) {
        this.userInitiatedDisconnect = false;
        return;
      }
      const arCfg = vscode.workspace.getConfiguration('tn3270Bridge.autoReconnect');
      if (!arCfg.get<boolean>('enabled', false)) return;
      void this.tryAutoReconnect(arCfg.get<number>('maxAttempts', 5));
    });

    try {
      await this.client.connect();
      this._state = { ...this._state, connected: true, host, mainframePort: port };
      this.fireStateChangeImmediate();
      const tlsTag = this.client.state.tls?.enabled ? ` [TLS ${this.client.state.tls.version || ''} ${this.client.state.tls.cipher || ''}]`.trim() + ']' : '';
      this.outputChannel.appendLine(`[Client] Connected to ${host}:${port}${tlsTag}`);
      return { success: true, screen: this.client.getScreenText() };
    } catch (err: any) {
      this.outputChannel.appendLine(`[Client] Connection failed: ${err.message} (code=${this.client?.state.errorCode})`);
      return {
        success: false,
        error: err.message,
        errorCode: this.client?.state.errorCode,
        errorHint: this.client?.state.errorHint,
      };
    }
  }

  /**
   * Build TlsOptions from settings + per-call override, resolving the
   * SecretStorage passphrase if a passphraseKey is configured.
   *
   * When `host` and `port` are supplied and no `pinnedFingerprint` is set
   * either in the override or the settings, this method automatically
   * inherits the pin the sidebar stored under
   * `tn3270.certpin.<host>:<port>` in SecretStorage. That way an HTTP API
   * caller (Copilot agent, `curl`, CLI) automatically benefits from the
   * user's prior "Trust this cert" decision made in the sidebar, without
   * needing to know the SHA-256 or duplicate the trust flow. This is the
   * enterprise-emulator equivalent of "the user's trust store is the
   * app's trust store" — once, in the sidebar, is enough.
   */
  private async resolveTlsOptions(
    override?: TlsOptions | boolean,
    host?: string,
    port?: number,
  ): Promise<TlsOptions | undefined> {
    const cfg = vscode.workspace.getConfiguration('tn3270Bridge');
    const globalEnabled = cfg.get<boolean>('tls.enabled', false);

    let merged: TlsOptions = {
      enabled: globalEnabled,
      minVersion: cfg.get<TlsOptions['minVersion']>('tls.minVersion', 'TLSv1.2'),
      maxVersion: cfg.get<TlsOptions['maxVersion']>('tls.maxVersion', 'TLSv1.3'),
      rejectUnauthorized: cfg.get<boolean>('tls.rejectUnauthorized', true),
      caBundle: cfg.get<string>('tls.caBundle', '') || undefined,
      sni: cfg.get<string>('tls.sni', '') || undefined,
      ciphers: cfg.get<string>('tls.ciphers', '') || undefined,
      clientCert: cfg.get<string>('tls.clientCert', '') || undefined,
      clientKey: cfg.get<string>('tls.clientKey', '') || undefined,
    };

    const passphraseKey = cfg.get<string>('tls.passphraseKey', '');
    if (passphraseKey) {
      const stored = await this.context.secrets.get(`tn3270.tls.${passphraseKey}`);
      if (stored) merged.passphrase = stored;
    }

    if (override === true) {
      merged.enabled = true;
    } else if (override === false) {
      merged.enabled = false;
    } else if (override && typeof override === 'object') {
      merged = { ...merged, ...override };
      // If override provides its own passphraseKey alias, resolve it too
      const overrideKey = (override as any).passphraseKey;
      if (overrideKey && typeof overrideKey === 'string') {
        const stored = await this.context.secrets.get(`tn3270.tls.${overrideKey}`);
        if (stored) merged.passphrase = stored;
      }
    }

    // Inherit the sidebar's per-host pin when TLS is on and no pin was
    // supplied by the caller. Keys match SidebarProvider's certPinSecretKey.
    if (merged.enabled && !merged.pinnedFingerprint && host && port) {
      const pin = await this.context.secrets.get(`tn3270.certpin.${host.toLowerCase()}:${port}`);
      if (pin) merged.pinnedFingerprint = pin;
    }

    return merged.enabled ? merged : undefined;
  }

  private tryListen(port: number, basePort: number, attempts: number): void {
    const server = http.createServer((req, res) => void this.handleRequest(req, res));
    server.on('error', (err: NodeJS.ErrnoException) => {
      server.close();
      if (err.code === 'EADDRINUSE' && attempts > 1) {
        this.outputChannel.appendLine(`[Server] Port ${port} in use, trying ${port + 1}`);
        this.tryListen(port + 1, basePort, attempts - 1);
      } else {
        vscode.window.showErrorMessage(`TN3270 Bridge: Cannot start on port ${port}: ${err.message}`);
      }
    });
    server.listen(port, '127.0.0.1', () => {
      this.server = server;
      const broker = new LocalCredentialBroker(port, () => this.apiTokenPromise);
      this.credentialBroker = broker;
      void broker.start().then(() => {
        this._state = { ...this._state, running: true, port };
        this.fireStateChangeImmediate();
        this.outputChannel.appendLine(`[Server] Listening on http://127.0.0.1:${port} with same-user credential broker`);
      }).catch(err => {
        server.close();
        this.server = null;
        this.credentialBroker = null;
        vscode.window.showErrorMessage(`TN3270 Bridge: Cannot start credential broker: ${err.message}`);
      });
    });
  }

  private async handleRequest(req: http.IncomingMessage, res: http.ServerResponse): Promise<void> {
    // Security: only localhost
    const remote = req.socket.remoteAddress;
    if (remote !== '127.0.0.1' && remote !== '::1' && remote !== '::ffff:127.0.0.1') {
      res.writeHead(403); res.end(JSON.stringify({ error: 'Forbidden: localhost only' })); return;
    }

    const url = new URL(req.url || '/', 'http://127.0.0.1');
    const path = url.pathname;

    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');

    if (req.method === 'GET' && path === '/health') {
      // Extended /health so MCP/CLI/Copilot clients can auto-discover which
      // bridge port is the right one to talk to. Auth-less on purpose —
      // no user data, only wiring metadata. When multiple VS Code windows
      // are open (multiple extension hosts), each answers on its own port
      // and clients pick the one where `connected: true` and the host
      // matches what they want.
      res.writeHead(200); res.end(JSON.stringify({
        bridge: 'running',
        version: '2.6.0',
        port: this._state.port,
        connected: !!this._state.connected,
        host: this._state.host,
        mainframePort: this._state.mainframePort,
        pid: process.pid,
        startedAt: this.startedAt,
        // Include the extension's install path so clients can prefer
        // bridges served by the newest version when several are alive.
        extensionPath: this.extensionPath,
      })); return;
    }

    if (req.method === 'OPTIONS') {
      res.writeHead(403); res.end(JSON.stringify({ error: 'Browser cross-origin access is not allowed' })); return;
    }
    if (req.headers.origin) {
      res.writeHead(403); res.end(JSON.stringify({ error: 'Browser-originated requests are not allowed' })); return;
    }

    const cfg = vscode.workspace.getConfiguration('tn3270Bridge');
    if (cfg.get<boolean>('requireApiToken', true)) {
      const authorization = req.headers.authorization || '';
      const bearer = authorization.startsWith('Bearer ') ? authorization.slice(7) : undefined;
      const headerToken = typeof req.headers['x-tn3270-token'] === 'string'
        ? req.headers['x-tn3270-token']
        : undefined;
      const expected = await this.apiTokenPromise;
      if (!apiTokenMatches(bearer || headerToken, expected)) {
        res.setHeader('WWW-Authenticate', 'Bearer realm="TN3270 Bridge"');
        res.writeHead(401); res.end(JSON.stringify({ error: 'Unauthorized' })); return;
      }
    }

    // === Routes ===
    const sid = this.sessionIdFrom(url);
    if (req.method === 'GET' && path === '/status') return this.handleStatus(res);
    if (req.method === 'GET' && path === '/sessions') return this.handleSessions(res);
    if (req.method === 'POST' && path === '/session') return this.withBody(req, res, b => this.handleCreateSession(b, res));
    // DELETE /session/<id>
    const sessionDelMatch = path.match(/^\/session\/([\w-]+)$/);
    if (req.method === 'DELETE' && sessionDelMatch) return this.handleDeleteSession(sessionDelMatch[1], res);
    if (req.method === 'POST' && path === '/connect') return this.withBody(req, res, b => this.handleConnect(b, res));
    if (req.method === 'POST' && path === '/disconnect') return this.handleDisconnect(sid, res);
    if (req.method === 'GET' && path === '/screen') return this.handleScreen(url, sid, res);
    if (req.method === 'GET' && path === '/screen/fields') return this.handleFields(sid, res);
    if (req.method === 'GET' && path === '/screen/text') return this.handleGetText(url, sid, res);
    if (req.method === 'GET' && path === '/screen/region') return this.handleGetRegion(url, sid, res);
    if (req.method === 'GET' && path === '/screen/find') return this.handleFind(url, sid, res);
    if (req.method === 'GET' && path === '/screen/table') return this.handleTable(url, sid, res);
    if (req.method === 'GET' && path === '/screen/history') return this.handleHistory(url, sid, res);
    if (req.method === 'POST' && path === '/screen/extract') {
      return this.withBody(req, res, b => this.handleExtract(b, sid, res));
    }
    if (req.method === 'POST' && path === '/screen/readall') {
      return this.withBody(req, res, b => this.enqueueReadAll(b, req.headers['content-type'] as string, res, sid));
    }
    if (req.method === 'GET' && path === '/file/get') {
      return this.enqueueOrReject(sid, res, () => this.handleFileGet(url, sid, res));
    }
    if (req.method === 'POST' && path === '/file/put') {
      return this.withBody(req, res, b => this.enqueueOrReject(sid, res, () => this.handleFilePut(b, sid, res)));
    }

    // /send — both POST (body) and GET (query string for shell-safe usage)
    if (req.method === 'POST' && path === '/send') {
      return this.withBody(req, res, b => this.enqueueSend(b, req.headers['content-type'] as string, res, sid));
    }
    if (req.method === 'GET' && path === '/send') {
      const params: Record<string, string> = {};
      url.searchParams.forEach((v, k) => { params[k] = v; });
      return void this.enqueueSend(JSON.stringify(params), 'application/json', res, sid);
    }

    // /key/<AID> — dedicated AID-only endpoint (POST, no body required)
    const keyMatch = path.match(/^\/key\/([A-Za-z0-9]+)$/);
    if ((req.method === 'POST' || req.method === 'GET') && keyMatch) {
      const aidKey = keyMatch[1].toUpperCase();
      if (!AID_KEYS.has(aidKey)) {
        res.writeHead(400); res.end(JSON.stringify({ error: `Unknown AID key: ${aidKey}`, valid: Array.from(AID_KEYS) })); return;
      }
      return void this.enqueueSend(JSON.stringify({ aid: aidKey }), 'application/json', res, sid);
    }

    if (req.method === 'POST' && path === '/cursor') return this.withBody(req, res, b => this.handleCursor(b, req.headers['content-type'] as string, sid, res));
    if (req.method === 'POST' && path === '/attn') return this.handleAttn(sid, res);
    if (req.method === 'POST' && path === '/wait') return this.withBody(req, res, b => this.handleWait(b, req.headers['content-type'] as string, sid, res));
    if (req.method === 'POST' && path === '/exec') return this.withBody(req, res, b => this.enqueueExec(b, req.headers['content-type'] as string, res, sid));
    if (req.method === 'POST' && path === '/login') return this.withBody(req, res, b => this.enqueueLogin(b, req.headers['content-type'] as string, res));
    if (req.method === 'GET' && path === '/debug') return this.handleDebug(sid, res);

    res.writeHead(404);
    res.end(JSON.stringify({ error: 'Not found', endpoints: [
      'GET /status',
      'POST /connect', 'POST /disconnect',
      'GET /screen [?compact=&nonblank=]',
      'GET /screen/fields',
      'GET /screen/text?row=&col=&length=',
      'GET /screen/region?row=&col=&rows=&cols=',
      'GET /screen/find?text=',
      'GET /screen/table?headerRow=',
      'GET /screen/history?last=',
      'POST /screen/readall',
      'POST /send | GET /send?text=&aid=',
      'POST /key/<AID>',
      'POST /attn',
      'POST /cursor',
      'POST /wait',
      'POST /exec',
      'POST /login',
      'GET /debug',
    ]}));
  }

  // === Handlers ===

  private handleStatus(res: http.ServerResponse): void {
    const status: any = {
      bridge: 'running',
      version: '2.6.0',
      connected: !!this.client && this.client.state.status === 'connected',
      connection: this.client?.state || { status: 'disconnected' },
    };
    if (this.client && this.client.state.status === 'connected') {
      const cols = this.client.screenState.cols;
      status.screen = {
        rows: this.client.screenState.rows,
        cols,
        cursorRow: Math.floor(this.client.screenState.cursor / cols) + 1,
        cursorCol: (this.client.screenState.cursor % cols) + 1,
        fieldCount: this.client.screenState.fields.length,
        keyboardLocked: this.client.screenState.keyboardLocked,
        panelId: this.client.detectPanelId(),
      };
    }
    // Include extra sessions in status
    if (this.extraSessions.size > 0) {
      status.sessions = {};
      this.extraSessions.forEach((s, id) => {
        const c = s.client;
        const cs = c.state.status === 'connected';
        status.sessions[id] = {
          connected: cs,
          host: s.host,
          port: s.port,
          model: s.model,
          panelId: cs ? c.detectPanelId() : null,
          connectedAt: s.connectedAt,
        };
      });
    }
    res.writeHead(200); res.end(JSON.stringify(status, null, 2));
  }

  private async handleConnect(body: string, res: http.ServerResponse): Promise<void> {
    try {
      const params = this.parseBody(body, 'application/json');
      const cfg = vscode.workspace.getConfiguration('tn3270Bridge');
      const host = params.host || cfg.get<string>('defaultHost', '');
      const port = Number(params.port) || cfg.get<number>('defaultPort', 23);
      const luName = params.luName || cfg.get<string>('luName', '');
      if (!host) {
        res.writeHead(400); res.end(JSON.stringify({ error: 'Host required. Provide {host, port} or set tn3270Bridge.defaultHost' })); return;
      }

      // Idempotent connect: if we're already connected to the requested
      // host+port, reuse the existing session instead of tearing it down.
      // This matches enterprise-emulator semantics (Mocha, PComm, x3270 —
      // "Connect" is a no-op when already connected to the target) and
      // avoids the common z/OS gotcha where the mainframe silently drops
      // the SYN of a fresh reconnect from the same client IP within a few
      // seconds of the previous FIN, which surfaced here as
      // TLS_HANDSHAKE_TIMEOUT for AI agents that call /connect without
      // first checking /status. `force=true` opts out of this fast-path.
      if (
        !params.force &&
        this.client &&
        this.client.state.status === 'connected' &&
        this.client.state.host === host &&
        this.client.state.port === port
      ) {
        res.writeHead(200); res.end(JSON.stringify({
          success: true,
          message: `Already connected to ${host}:${port} — reusing session`,
          reused: true,
          tls: this.client.state.tls,
          screen: this.client.getScreenText(),
          panelId: this.client.detectPanelId(),
        }));
        return;
      }

      // tls may be: undefined (use settings), boolean (on/off shortcut), or object (override)
      let tlsParam: TlsOptions | boolean | undefined = undefined;
      if (typeof params.tls === 'boolean') tlsParam = params.tls;
      else if (params.tls && typeof params.tls === 'object') tlsParam = params.tls;

      const result = await this.connectTo(host, port, luName, tlsParam as any, params.model || undefined);
      if (result.success) {
        res.writeHead(200); res.end(JSON.stringify({
          success: true,
          message: `Connected to ${host}:${port}`,
          tls: this.client?.state.tls,
          screen: result.screen,
          panelId: this.client?.detectPanelId(),
        }));
      } else {
        res.writeHead(500); res.end(JSON.stringify({
          error: result.error,
          errorCode: result.errorCode,
          errorHint: result.errorHint,
        }));
      }
    } catch (err: any) {
      res.writeHead(500); res.end(JSON.stringify({ error: err.message }));
    }
  }

  private handleDisconnect(sid: string, res: http.ServerResponse): void {
    if (sid && sid !== 'default') {
      const s = this.extraSessions.get(sid);
      if (s) { s.client.disconnect(); this.extraSessions.delete(sid); }
      res.writeHead(200); res.end(JSON.stringify({ success: true, message: `Session ${sid} disconnected` })); return;
    }
    this.disconnectClient();
    res.writeHead(200); res.end(JSON.stringify({ success: true, message: 'Disconnected' }));
  }

  private handleScreen(url: URL, sid: string, res: http.ServerResponse): void {
    const client = this.requireClient(sid, res);
    if (!client) return;
    const cfg = vscode.workspace.getConfiguration('tn3270Bridge');
    const compactDefault = cfg.get<boolean>('defaultCompactScreen', true);
    const compact = parseBool(url.searchParams.get('compact'), compactDefault);
    const nonblank = parseBool(url.searchParams.get('nonblank'), false);

    const linesRaw = client.getScreenText();
    const cursor = client.screenState.cursor;
    const cols = client.screenState.cols;

    let lines = linesRaw;
    if (compact) lines = linesRaw.map(l => l.replace(/\s+$/, ''));

    const response: any = {
      lines,
      cursor: { row: Math.floor(cursor / cols) + 1, col: (cursor % cols) + 1 },
      keyboardLocked: client.screenState.keyboardLocked,
      panelId: client.detectPanelId(),
    };
    if (nonblank) {
      response.nonblank = linesRaw
        .map((l, i) => ({ row: i + 1, content: l.replace(/\s+$/, '') }))
        .filter(x => x.content.length > 0);
    }
    if (!compact && !nonblank) {
      response.text = linesRaw.join('\n');
    }
    res.writeHead(200); res.end(JSON.stringify(response));
  }

  private handleFields(sid: string, res: http.ServerResponse): void {
    const client = this.requireClient(sid, res);
    if (!client) return;
    const fields = client.getInputFields();
    res.writeHead(200); res.end(JSON.stringify({
      fields,
      inputFields: fields.filter(f => !f.protected),
      protectedFields: fields.filter(f => f.protected),
    }));
  }

  private handleGetText(url: URL, sid: string, res: http.ServerResponse): void {
    const client = this.requireClient(sid, res);
    if (!client) return;
    const row = parseInt(url.searchParams.get('row') || '1');
    const col = parseInt(url.searchParams.get('col') || '1');
    const length = parseInt(url.searchParams.get('length') || '80');
    const text = client.getTextAt(row, col, length);
    res.writeHead(200); res.end(JSON.stringify({ text, row, col, length }));
  }

  private handleGetRegion(url: URL, sid: string, res: http.ServerResponse): void {
    const client = this.requireClient(sid, res);
    if (!client) return;
    const row = parseInt(url.searchParams.get('row') || '1');
    const col = parseInt(url.searchParams.get('col') || '1');
    const rows = parseInt(url.searchParams.get('rows') || '1');
    const cols = parseInt(url.searchParams.get('cols') || String(client.screenState.cols));
    const out: string[] = [];
    for (let r = 0; r < rows; r++) {
      out.push(client.getTextAt(row + r, col, cols));
    }
    res.writeHead(200); res.end(JSON.stringify({ row, col, rows, cols, lines: out }));
  }

  /**
   * Serialize /send and /key calls — prevents two concurrent agent calls
   * from racing on cursor placement / keyboard lock.
   */
  private enqueueSend(body: string, contentType: string | undefined, res: http.ServerResponse, sid = 'default'): void {
    this.enqueueOrReject(sid, res, () => this.handleSend(body, contentType, res, sid));
  }

  private async handleSend(body: string, contentType: string | undefined, res: http.ServerResponse, sid = 'default'): Promise<void> {
    const client = this.clientFor(sid);
    if (!client || client.state.status !== 'connected') {
      res.writeHead(400); res.end(JSON.stringify({ error: 'Not connected' })); return;
    }

    try {
      const params = this.parseBody(body, contentType);
      const result = await this.executeSendStep(params, client);
      res.writeHead(200); res.end(JSON.stringify(result));
    } catch (err: any) {
      this.outputChannel.appendLine(`[Send Error] ${err.message}`);
      res.writeHead(500); res.end(JSON.stringify({ error: err.message }));
    }
  }

  /**
   * Execute a single send step. Used by /send, /key, /exec, /login.
   * Returns the post-send screen + cursor + diff vs the pre-screen.
   */
  private async executeSendStep(params: any, client?: Tn3270Client): Promise<any> {
    const c = client ?? this.client;
    if (!c) throw new Error('Not connected');
    const cfg = vscode.workspace.getConfiguration('tn3270Bridge');
    const waitForUnlockDefault = cfg.get<boolean>('defaultWaitForUnlock', true);
    const waitForUnlock = params.waitForUnlock !== undefined ? !!params.waitForUnlock : waitForUnlockDefault;
    const waitTimeout = Number(params.waitTimeout) || 5000;

    const preSnapshot = c.snapshotScreen();
    const prePanelId = c.detectPanelId();
    const { text, aid, row, col, field, labelLeft, labelAbove, fieldName, fields: fieldEntries } = params;

    // === Multi-field mode ===
    if (Array.isArray(fieldEntries) && fieldEntries.length > 0) {
      for (const entry of fieldEntries) {
        let r = entry.row, cv = entry.col;
        if (entry.labelLeft) {
          const found = c.findFieldByLabel(entry.labelLeft, 'left');
          if (!found) throw new Error(`Label not found: "${entry.labelLeft}"`);
          r = found.row; cv = found.col;
        } else if (entry.labelAbove) {
          const found = c.findFieldByLabel(entry.labelAbove, 'above');
          if (!found) throw new Error(`Label not found: "${entry.labelAbove}"`);
          r = found.row; cv = found.col;
        } else if (entry.fieldName) {
          const found = c.resolveFieldName(entry.fieldName);
          if (!found) throw new Error(`Field not found: "${entry.fieldName}"`);
          r = found.row; cv = found.col;
        }
        if (typeof r === 'number' && typeof cv === 'number') {
          c.setCursor(r, cv);
        } else if (typeof entry.field === 'number') {
          c.setCursorToField(entry.field);
        }
        // Clear field before typing if requested (prevents partial overwrites)
        if (entry.clearField || params.clearField) {
          const cur = c.screenState.cursor;
          const curCols = c.screenState.cols;
          c.clearFieldAt(Math.floor(cur / curCols) + 1, (cur % curCols) + 1);
        }
        if (entry.text) c.typeText(String(entry.text));
      }
      const aidKey = ((aid || 'ENTER') as string).toUpperCase();
      await c.sendAID(aidKey as any);
      this.outputChannel.appendLine(`[Send] multi-field (${fieldEntries.length} fields) aid=${aidKey}`);
    } else {
      // === Single mode ===
      // Resolve semantic positions
      let resolvedRow = typeof row === 'number' ? row : undefined;
      let resolvedCol = typeof col === 'number' ? col : undefined;
      if (labelLeft) {
        const f = c.findFieldByLabel(String(labelLeft), 'left');
        if (!f) throw new Error(`Label not found: "${labelLeft}"`);
        resolvedRow = f.row; resolvedCol = f.col;
      } else if (labelAbove) {
        const f = c.findFieldByLabel(String(labelAbove), 'above');
        if (!f) throw new Error(`Label not found: "${labelAbove}"`);
        resolvedRow = f.row; resolvedCol = f.col;
      } else if (fieldName) {
        const f = c.resolveFieldName(String(fieldName));
        if (!f) throw new Error(`Field not found: "${fieldName}"`);
        resolvedRow = f.row; resolvedCol = f.col;
      }
      if (typeof resolvedRow === 'number' && typeof resolvedCol === 'number') {
        c.setCursor(resolvedRow, resolvedCol);
      } else if (typeof field === 'number') {
        c.setCursorToField(field);
      }
      // Clear the field before typing if requested (prevents partial overwrites)
      if (params.clearField) {
        const cur = c.screenState.cursor;
        const curCols = c.screenState.cols;
        c.clearFieldAt(Math.floor(cur / curCols) + 1, (cur % curCols) + 1);
      }
      const aidKey = ((aid || 'ENTER') as string).toUpperCase();
      if (text) {
        await c.sendText(String(text), aidKey as any);
      } else {
        await c.sendAID(aidKey as any);
      }
      this.outputChannel.appendLine(`[Send] text="${text || ''}" aid=${aidKey} ${labelLeft ? `label="${labelLeft}"` : ''} ${fieldName ? `fieldName=${fieldName}` : ''}`);
    }

    // Wait for keyboard to unlock so the screen we return is the post-AID one
    let unlocked = !c.screenState.keyboardLocked;
    if (waitForUnlock && c.screenState.keyboardLocked) {
      unlocked = await c.waitForKeyboardUnlock(waitTimeout);
    }

    const postSnapshot = c.snapshotScreen();
    const changedLines = Tn3270Client.snapshotDiff(preSnapshot, postSnapshot);
    const cursor = c.screenState.cursor;
    const cols = c.screenState.cols;
    const postPanelId = c.detectPanelId();

    return {
      success: true,
      lines: postSnapshot.map(l => l.replace(/\s+$/, '')),
      cursor: { row: Math.floor(cursor / cols) + 1, col: (cursor % cols) + 1 },
      keyboardLocked: c.screenState.keyboardLocked,
      waitedForUnlock: waitForUnlock,
      unlocked,
      alarm: c.lastAlarm,
      ispfMessage: c.extractIspfMessage(),
      panelId: postPanelId,
      panelChanged: prePanelId !== postPanelId,
      changedLines,
    };
  }

  // ─── New screen-intelligence handlers (1.7.0) ───────────────────────────

  /**
   * POST /attn
   * Send a Telnet IAC IP (Interrupt Process) + IAC DM to interrupt a hung session.
   * Unlike /key/ATTN this works even when the keyboard is locked (TSO stuck in a
   * long-running command, infinite loop, etc.).  The local keyboard lock is
   * cleared optimistically so the agent can immediately re-issue commands.
   */
  private handleAttn(sid: string, res: http.ServerResponse): void {
    const client = this.requireClient(sid, res);
    if (!client) return;
    client.sendATTN();
    const cursor = client.screenState.cursor;
    const cols = client.screenState.cols;
    res.writeHead(200); res.end(JSON.stringify({
      success: true,
      keyboardLocked: client.screenState.keyboardLocked,
      cursor: { row: Math.floor(cursor / cols) + 1, col: (cursor % cols) + 1 },
    }));
  }

  /**
   * GET /screen/find?text=<search>
   * Find the first occurrence of the given text (case-insensitive) on screen.
   * Returns { found, row, col } — row/col are 1-based.
   */
  private handleFind(url: URL, sid: string, res: http.ServerResponse): void {
    const client = this.requireClient(sid, res);
    if (!client) return;
    const text = url.searchParams.get('text') || '';
    if (!text) {
      res.writeHead(400); res.end(JSON.stringify({ error: 'text parameter required' })); return;
    }
    const found = client.findText(text);
    res.writeHead(200); res.end(JSON.stringify(
      found ? { found: true, row: found.row, col: found.col } : { found: false },
    ));
  }

  /**
   * GET /screen/table?headerRow=<n>
   * Parse the current screen as a columnar table.
   * headerRow is 1-based; omit to auto-detect.
   * Returns { headers: string[], rows: Record<string,string>[] }.
   */
  private handleTable(url: URL, sid: string, res: http.ServerResponse): void {
    const client = this.requireClient(sid, res);
    if (!client) return;
    const headerRow = url.searchParams.get('headerRow');
    const result = client.extractTableRows(headerRow ? parseInt(headerRow) : undefined);
    res.writeHead(200); res.end(JSON.stringify(result));
  }

  /**
   * GET /screen/history?last=<n>
   * Return the last n screen snapshots (oldest first, max 10).
   * Each snapshot is an array of screen lines.
   */
  private handleHistory(url: URL, sid: string, res: http.ServerResponse): void {
    const client = this.requireClient(sid, res);
    if (!client) return;
    const last = Math.min(parseInt(url.searchParams.get('last') || '5'), 10);
    const snapshots = client.getHistory(last);
    res.writeHead(200); res.end(JSON.stringify({
      count: snapshots.length,
      snapshots: snapshots.map((s, i) => ({
        index: i,
        lines: s.map(l => l.replace(/\s+$/, '')),
      })),
    }));
  }

  /**
   * POST /screen/extract — Structured extraction from the current screen.
   * Body: { mode, pattern, endPattern?, flags?, maxMatches?, valueMaxLen?, valueStopChars? }
   *
   * Mode "regex": returns array of matches { row, col, text, groups }.
   * Mode "labels": returns array of { labelRow, labelCol, valueRow, valueCol, value }.
   * Mode "anchor": needs endPattern; returns lines between the two anchors.
   *
   * Introduced in v2.6.0 to reduce token cost for AI agents — instead of
   * re-parsing the full screen text on every call, the agent asks for the
   * exact field/section it needs.
   */
  private handleExtract(body: string, sid: string, res: http.ServerResponse): void {
    const client = this.requireClient(sid, res);
    if (!client) return;
    let request: ExtractRequest;
    try {
      request = this.parseBody(body, 'application/json') as ExtractRequest;
    } catch (err: any) {
      res.writeHead(400); res.end(JSON.stringify({ error: err.message })); return;
    }
    let result;
    try {
      const lines = client.getScreenText().map(l => l.replace(/\s+$/, ''));
      result = extractFromScreen(lines, request);
    } catch (err: any) {
      res.writeHead(400); res.end(JSON.stringify({ error: err.message })); return;
    }
    res.writeHead(200); res.end(JSON.stringify(result));
  }

  /**
   * POST /screen/readall — Scroll all pages and return accumulated lines.
   * Body: { scrollKey?, stopText?, maxPages?, timeout? }
   *   scrollKey  AID key to press for each scroll (default: PF8)
   *   stopText   Text that signals the last page (default: BOTTOM OF DATA)
   *   maxPages   Hard cap on pages collected (default: 200, max: 500)
   *   timeout    Wall-clock timeout in ms (default: 30000, max: 120000)
   *
   * Returns: { success, lines, pages, stopped }
   *   stopped: 'stopText' | 'noChange' | 'maxPages' | 'timeout'
   */
  private enqueueReadAll(body: string, contentType: string | undefined, res: http.ServerResponse, sid = 'default'): void {
    this.enqueueOrReject(sid, res, () => this.doReadAll(body, contentType, res, sid));
  }

  private async doReadAll(body: string, contentType: string | undefined, res: http.ServerResponse, sid = 'default'): Promise<void> {
    const client = this.requireClient(sid, res);
    if (!client) return;
    try {
      const params = this.parseBody(body, contentType);
      const scrollKey = String(params.scrollKey || 'PF8').toUpperCase();
      const stopText  = String(params.stopText  !== undefined ? params.stopText : 'BOTTOM OF DATA');
      const maxPages  = Math.min(Number(params.maxPages)  || 200, 500);
      const timeout   = Math.min(Number(params.timeout)   || 30000, 120000);
      const skipHeaderRows = Math.max(0, Math.min(Number(params.skipHeaderRows) || 0, 10));

      if (!AID_KEYS.has(scrollKey)) {
        res.writeHead(400); res.end(JSON.stringify({ error: `Invalid scrollKey: ${scrollKey}. Valid: ${[...AID_KEYS].join(', ')}` })); return;
      }

      const result = await client.scrollAllPages(scrollKey as any, stopText, maxPages, timeout, skipHeaderRows);
      res.writeHead(200); res.end(JSON.stringify({
        success: true,
        lines: result.lines.map(l => l.replace(/\s+$/, '')),
        pages: result.pages,
        stopped: result.stopped,
      }));
    } catch (err: any) {
      res.writeHead(500); res.end(JSON.stringify({ error: err.message }));
    }
  }

  /**
   * POST /cursor — Move cursor to a position locally without sending any AID key.
   * Accepts: { row, col } | { field } | { fieldName } | { labelLeft } | { labelAbove }
   */
  private handleCursor(body: string, contentType: string | undefined, sid: string, res: http.ServerResponse): void {
    const client = this.requireClient(sid, res);
    if (!client) return;
    try {
      const params = this.parseBody(body, contentType);
      const { row, col, field, fieldName, labelLeft, labelAbove } = params;
      let resolvedRow: number | undefined;
      let resolvedCol: number | undefined;

      if (labelLeft) {
        const f = client.findFieldByLabel(String(labelLeft), 'left');
        if (f) { resolvedRow = f.row; resolvedCol = f.col; }
        else { res.writeHead(404); res.end(JSON.stringify({ error: `Label not found: "${labelLeft}"` })); return; }
      } else if (labelAbove) {
        const f = client.findFieldByLabel(String(labelAbove), 'above');
        if (f) { resolvedRow = f.row; resolvedCol = f.col; }
        else { res.writeHead(404); res.end(JSON.stringify({ error: `Label not found: "${labelAbove}"` })); return; }
      } else if (fieldName) {
        const f = client.resolveFieldName(String(fieldName));
        if (f) { resolvedRow = f.row; resolvedCol = f.col; }
        else { res.writeHead(404); res.end(JSON.stringify({ error: `Field not found: "${fieldName}"` })); return; }
      } else if (typeof row === 'number' && typeof col === 'number') {
        resolvedRow = row;
        resolvedCol = col;
      } else if (typeof field === 'number') {
        client.setCursorToField(field);
        const cursor = client.screenState.cursor;
        const cols = client.screenState.cols;
        res.writeHead(200); res.end(JSON.stringify({ success: true, cursor: { row: Math.floor(cursor / cols) + 1, col: (cursor % cols) + 1 } })); return;
      } else {
        res.writeHead(400); res.end(JSON.stringify({ error: 'Provide row+col, field, fieldName, labelLeft, or labelAbove' })); return;
      }

      if (typeof resolvedRow === 'number' && typeof resolvedCol === 'number') {
        client.setCursor(resolvedRow, resolvedCol);
      }
      const cursor = client.screenState.cursor;
      const cols = client.screenState.cols;
      res.writeHead(200); res.end(JSON.stringify({ success: true, cursor: { row: Math.floor(cursor / cols) + 1, col: (cursor % cols) + 1 } }));
    } catch (err: any) {
      res.writeHead(500); res.end(JSON.stringify({ error: err.message }));
    }
  }

  private async handleWait(body: string, contentType: string | undefined, sid: string, res: http.ServerResponse): Promise<void> {
    const client = this.requireClient(sid, res);
    if (!client) return;
    try {
      const params = this.parseBody(body, contentType);
      const result = await this.executeWaitStep(params, client);
      res.writeHead(200); res.end(JSON.stringify(result));
    } catch (err: any) {
      res.writeHead(500); res.end(JSON.stringify({ error: err.message }));
    }
  }

  private async executeWaitStep(params: any, client?: Tn3270Client): Promise<any> {
    const c = client ?? this.client;
    if (!c) throw new Error('Not connected');
    const timeout = Number(params.timeout) || 10000;
    const type = (params.type as string | undefined)?.toLowerCase();
    // text may be a plain string or a /regex/flags literal
    const rawText: string | undefined = params.text ? String(params.text) : undefined;

    if (type === 'keyboardunlock' || type === 'unlock') {
      const ok = await c.waitForKeyboardUnlock(timeout);
      return { found: ok, type: 'keyboardUnlock', lines: c.snapshotScreen().map(l => l.replace(/\s+$/, '')) };
    }
    if (type === 'panel') {
      const wantedId = String(params.panelId || '').toUpperCase();
      if (!wantedId) throw new Error('panelId required for type=panel');
      const deadline = Date.now() + timeout;
      while (Date.now() < deadline) {
        const cur = c.detectPanelId();
        if (cur && cur.toUpperCase() === wantedId) {
          return { found: true, type: 'panel', panelId: cur, lines: c.snapshotScreen().map(l => l.replace(/\s+$/, '')) };
        }
        const ok = await c.waitForKeyboardUnlock(Math.min(500, deadline - Date.now()));
        if (!ok) break;
      }
      return { found: false, type: 'panel', panelId: c.detectPanelId() };
    }
    if (type === 'screenchange') {
      const before = c.snapshotScreen();
      const deadline = Date.now() + timeout;
      while (Date.now() < deadline) {
        const ok = await c.waitForKeyboardUnlock(Math.min(500, deadline - Date.now()));
        const now = c.snapshotScreen();
        const diff = Tn3270Client.snapshotDiff(before, now);
        if (diff.length > 0) return { found: true, type: 'screenChange', changedLines: diff };
        if (!ok) break;
      }
      return { found: false, type: 'screenChange' };
    }

    // Default: text match (plain string or /regex/flags)
    if (!rawText) throw new Error('text parameter required (or specify type=keyboardUnlock|panel|screenChange)');
    const found = await c.waitForText(rawText, timeout);
    return { found, screen: c.snapshotScreen().map(l => l.replace(/\s+$/, '')) };
  }

  private enqueueExec(body: string, contentType: string | undefined, res: http.ServerResponse, sid = 'default'): void {
    this.enqueueOrReject(sid, res, () => this.handleExec(body, contentType, res, sid));
  }

  private async handleExec(body: string, contentType: string | undefined, res: http.ServerResponse, sid = 'default'): Promise<void> {
    const client = this.requireClient(sid, res);
    if (!client) return;
    try {
      const params = this.parseBody(body, contentType);
      const steps: any[] = Array.isArray(params.steps) ? params.steps : [];
      const stopOnError = params.stopOnError !== false;
      const results: any[] = [];

      for (let i = 0; i < steps.length; i++) {
        const step = steps[i];
        try {
          let stepResult: any;
          if (step.wait) {
            stepResult = await this.executeWaitStep(step.wait, client);
          } else if (step.send) {
            stepResult = await this.executeSendStep(step.send, client);
          } else {
            stepResult = await this.executeSendStep(step, client);
          }
          results.push({ step: i, ok: true, result: stepResult });
        } catch (err: any) {
          results.push({ step: i, ok: false, error: err.message });
          if (stopOnError) break;
        }
      }
      res.writeHead(200); res.end(JSON.stringify({
        success: results.every(r => r.ok),
        results,
        finalPanelId: client.detectPanelId(),
      }));
    } catch (err: any) {
      res.writeHead(500); res.end(JSON.stringify({ error: err.message }));
    }
  }

  private enqueueLogin(body: string, contentType: string | undefined, res: http.ServerResponse): void {
    this.sendQueue = this.sendQueue.then(() => this.handleLogin(body, contentType, res)).catch(() => undefined);
  }

  private async handleLogin(body: string, contentType: string | undefined, res: http.ServerResponse): Promise<void> {
    try {
      const params = this.parseBody(body, contentType);
      const profileName = String(params.profile || '');
      if (!profileName) { res.writeHead(400); res.end(JSON.stringify({ error: 'profile required' })); return; }

      const cfg = vscode.workspace.getConfiguration('tn3270Bridge');
      const profiles = cfg.get<Record<string, any>>('loginProfiles', {}) || {};
      const profile = profiles[profileName];
      if (!profile) { res.writeHead(404); res.end(JSON.stringify({ error: `Unknown profile: ${profileName}` })); return; }

      const userid = String(params.userid || profile.userid || '');
      // Password resolution: explicit > SecretStorage > prompt
      let password = typeof params.password === 'string' ? params.password : '';
      if (!password) {
        password = (await this.context.secrets.get(`tn3270.${profileName}.password`)) || '';
      }
      if (!password) {
        const entered = await vscode.window.showInputBox({
          prompt: `Password for profile ${profileName} (${userid || 'no userid'})`,
          password: true,
          ignoreFocusOut: true,
        });
        if (!entered) { res.writeHead(400); res.end(JSON.stringify({ error: 'Password required' })); return; }
        password = entered;
        if (params.savePassword) {
          await this.context.secrets.store(`tn3270.${profileName}.password`, password);
        }
      }

      // Ensure connected — propagate profile.tls override if present
      if (!this.client || this.client.state.status !== 'connected') {
        const host = profile.host;
        const port = Number(profile.port) || 23;
        if (!host) { res.writeHead(400); res.end(JSON.stringify({ error: `Profile ${profileName} has no host` })); return; }
        const conn = await this.connectTo(host, port, profile.luName, profile.tls);
        if (!conn.success) {
          res.writeHead(500);
          res.end(JSON.stringify({ error: `Connect failed: ${conn.error}`, errorCode: conn.errorCode, errorHint: conn.errorHint }));
          return;
        }
      }

      const steps: any[] = Array.isArray(profile.steps) ? profile.steps : [];
      const results: any[] = [];
      const interpolate = (s: any) => typeof s === 'string'
        ? s.replace(/\$\{userid\}/g, userid).replace(/\$\{password\}/g, password)
        : s;

      for (let i = 0; i < steps.length; i++) {
        const raw = steps[i];
        const step: any = JSON.parse(JSON.stringify(raw)); // deep clone
        // interpolate text fields
        if (step.text) step.text = interpolate(step.text);
        if (Array.isArray(step.fields)) {
          step.fields = step.fields.map((f: any) => ({ ...f, text: interpolate(f.text) }));
        }
        try {
          if (step.waitFor) {
            const w = await this.executeWaitStep({ text: step.waitFor, timeout: step.waitTimeout || 10000 }, this.client ?? undefined);
            if (!w.found) {
              results.push({ step: i, ok: false, error: `waitFor "${step.waitFor}" timed out` });
              break;
            }
          }
          // Build send spec (only if there's something to send)
          if (step.text || step.aid || step.fields || step.labelLeft || step.fieldName) {
            // SAFETY: don't echo passwords in the log
            const safeStep = redactSecrets(step, [password]);
            this.outputChannel.appendLine(`[Login] step ${i}: ${JSON.stringify(safeStep)}`);
            const sendRes = await this.executeSendStep(step, this.client ?? undefined);
            // Strip password from result before logging (lines may contain it)
            results.push({ step: i, ok: true, panelId: sendRes.panelId });
          } else if (step.waitFor) {
            results.push({ step: i, ok: true, type: 'wait' });
          }
        } catch (err: any) {
          results.push({ step: i, ok: false, error: err.message });
          break;
        }
      }

      const success = results.length > 0 && results.every(r => r.ok);
      res.writeHead(success ? 200 : 500);
      res.end(JSON.stringify({
        success,
        profile: profileName,
        results,
        finalPanelId: this.client?.detectPanelId() || null,
      }));
    } catch (err: any) {
      res.writeHead(500); res.end(JSON.stringify({ error: err.message }));
    }
  }

  private handleDebug(sid: string, res: http.ServerResponse): void {
    const cfg = vscode.workspace.getConfiguration('tn3270Bridge');
    if (!cfg.get<boolean>('enableDiagnostics', false)) {
      res.writeHead(404); res.end(JSON.stringify({ error: 'Diagnostics are disabled' })); return;
    }
    const client = this.requireClient(sid, res);
    if (!client) return;
    const screen = client.screenState;
    const bufHex: string[] = [], attrHex: string[] = [];
    for (let i = 0; i < Math.min(160, screen.buffer.length); i++) {
      bufHex.push(screen.buffer[i].toString(16).padStart(2, '0'));
      attrHex.push(screen.attributes[i].toString(16).padStart(2, '0'));
    }
    res.writeHead(200); res.end(JSON.stringify({
      version: '2.6.0',
      tls: client.state.tls,
      cursor: screen.cursor,
      fieldCount: screen.fields.length,
      formatted: screen.formatted,
      keyboardLocked: screen.keyboardLocked,
      panelId: client.detectPanelId(),
      screenModel: `${screen.rows}x${screen.cols}`,
      bufferRow1: bufHex.slice(0, Math.min(80, screen.cols)).join(' '),
      bufferRow2: bufHex.slice(Math.min(80, screen.cols), Math.min(160, screen.cols * 2)).join(' '),
      attrsRow1: attrHex.slice(0, Math.min(80, screen.cols)).join(' '),
      attrsRow2: attrHex.slice(Math.min(80, screen.cols), Math.min(160, screen.cols * 2)).join(' '),
      tn3270eMode: client.state.tn3270e,
      lastRawData: this.lastRawData,
    }, null, 2));
  }

  // ─── Session management handlers (1.8.0) ─────────────────────────────────

  /** GET /sessions — list all active sessions */
  private handleSessions(res: http.ServerResponse): void {
    const sessions: Record<string, any> = {
      default: {
        connected: !!this.client && this.client.state.status === 'connected',
        host: this.client?.state.host,
        port: this.client?.state.port,
        panelId: this.client?.detectPanelId() ?? null,
        model: this.client ? `${this.client.screenState.rows}x${this.client.screenState.cols}` : null,
      },
    };
    this.extraSessions.forEach((s, id) => {
      const c = s.client;
      const cs = c.state.status === 'connected';
      sessions[id] = {
        connected: cs,
        host: s.host,
        port: s.port,
        model: s.model,
        panelId: cs ? c.detectPanelId() : null,
        connectedAt: s.connectedAt,
      };
    });
    res.writeHead(200); res.end(JSON.stringify({ sessions }));
  }

  /**
   * POST /session — create and connect a new named session.
   * Body: { host, port, sessionId?, luName?, model?, tls? }
   * Returns: { sessionId, success, panelId? }
   */
  private async handleCreateSession(body: string, res: http.ServerResponse): Promise<void> {
    try {
      const params = this.parseBody(body, 'application/json');
      const cfg = vscode.workspace.getConfiguration('tn3270Bridge');
      const host = params.host || cfg.get<string>('defaultHost', '');
      const port = Number(params.port) || cfg.get<number>('defaultPort', 23);
      const sid: string = params.sessionId || `s${Date.now()}`;
      if (!host) {
        res.writeHead(400); res.end(JSON.stringify({ error: 'host required' })); return;
      }
      if (sid === 'default') {
        res.writeHead(400); res.end(JSON.stringify({ error: '"default" is reserved; omit sessionId for the default session' })); return;
      }
      // Disconnect existing session with same id if any
      const existing = this.extraSessions.get(sid);
      if (existing) { existing.client.disconnect(); this.extraSessions.delete(sid); }

      const tlsOpts = await this.resolveTlsOptions(
        typeof params.tls === 'boolean' ? params.tls : (params.tls || undefined),
        host,
        port,
      );
      const modelKey = params.model || cfg.get<string>('screenModel', 'model2');
      const screenModel = SCREEN_MODELS[modelKey] || SCREEN_MODELS.model2;

      const client = new Tn3270Client({
        host, port,
        luName: params.luName || cfg.get<string>('luName', ''),
        rows: screenModel.rows,
        cols: screenModel.cols,
        deviceType: screenModel.deviceType,
        timeout: cfg.get<number>('keyboardTimeout', 30000),
        codePage: cfg.get<string>('codePage', 'cp037') === 'cp500' ? 500 : 37,
        tls: tlsOpts,
      });

      const session: ExtraSession = { id: sid, client, sendQueue: Promise.resolve(), host, port, model: modelKey, connectedAt: Date.now() };
      await client.connect();
      this.extraSessions.set(sid, session);
      this.outputChannel.appendLine(`[Session ${sid}] Connected to ${host}:${port} (${modelKey})`);

      res.writeHead(200); res.end(JSON.stringify({
        success: true,
        sessionId: sid,
        model: modelKey,
        screen: { rows: screenModel.rows, cols: screenModel.cols },
        panelId: client.detectPanelId(),
      }));
    } catch (err: any) {
      const params = this.parseBody(body, 'application/json');
      if (params.sessionId) this.extraSessions.delete(String(params.sessionId));
      res.writeHead(500); res.end(JSON.stringify({ error: err.message }));
    }
  }

  /** DELETE /session/<id> — disconnect and remove a named session. */
  private handleDeleteSession(sid: string, res: http.ServerResponse): void {
    if (sid === 'default') {
      this.disconnectClient();
      res.writeHead(200); res.end(JSON.stringify({ success: true, message: 'Default session disconnected' })); return;
    }
    const s = this.extraSessions.get(sid);
    if (!s) {
      res.writeHead(404); res.end(JSON.stringify({ error: `Session not found: ${sid}` })); return;
    }
    s.client.disconnect();
    this.extraSessions.delete(sid);
    res.writeHead(200); res.end(JSON.stringify({ success: true, message: `Session ${sid} disconnected and removed` }));
  }

  // ─── /file/get — ISPF View automation (1.8.0) ────────────────────────────

  /**
   * GET /file/get?dsn=<dsn>&member=<member>&session=<id>
   *
   * Reads a z/OS sequential dataset or PDS member by automating ISPF View:
   *   1. Jump to ISPF View Entry Panel using =1 in the OPTION/COMMAND field
   *   2. Fill the dataset name (auto-quoted if not already)
   *   3. Optionally fill the member name
   *   4. Press ENTER — check for errors
   *   5. Scroll all pages with PF8 until BOTTOM OF DATA
   *   6. Return to previous panel with PF3
   *   7. Return the content lines (ISPF line numbers stripped)
   *
   * Requires: being connected and in an ISPF session (panelId must be non-null).
   * Returns: { dsn, member, lines, lineCount, pages }
   */
  private async handleFileGet(url: URL, sid: string, res: http.ServerResponse): Promise<void> {
    const client = this.requireClient(sid, res);
    if (!client) return;

    const rawDsn = url.searchParams.get('dsn') || '';
    const rawMember = url.searchParams.get('member') || '';
    if (!rawDsn.trim()) {
      res.writeHead(400); res.end(JSON.stringify({ error: 'dsn parameter required' })); return;
    }
    let dsn: string;
    let member: string;
    try {
      ({ dsn, member } = validateDatasetReference(rawDsn, rawMember));
    } catch (err: any) {
      res.writeHead(400); res.end(JSON.stringify({ error: err.message })); return;
    }

    const panelId = client.detectPanelId();
    if (!panelId) {
      res.writeHead(400); res.end(JSON.stringify({
        error: 'Must be in an ISPF session. Navigate to ISPF first.',
        hint: 'From TSO, type ISPF. From ISPF, panelId will be non-null.',
      })); return;
    }

    try {
      // Step 1: Jump to ISPF View Entry Panel using jump command =1
      const optField = client.resolveFieldName('OPTION') ?? client.resolveFieldName('COMMAND');
      if (!optField) {
        res.writeHead(400); res.end(JSON.stringify({ error: 'No OPTION or COMMAND field found on screen' })); return;
      }
      client.clearFieldAt(optField.row, optField.col);
      client.setCursor(optField.row, optField.col);
      client.typeText('=1');
      await client.sendAID('ENTER');
      const onView = await client.waitForText('/View Entry|BROWSE|ISPF EDIT|ISRBROBA|Data Set Name|Name \\. \\. \\./i', 5000);
      if (!onView) {
        await client.sendAID('PF3'); await client.waitForKeyboardUnlock(3000);
        res.writeHead(500); res.end(JSON.stringify({ error: 'Could not reach ISPF View Entry Panel' })); return;
      }

      // Step 2: Fill dataset name
      const qualDsn = dsn.startsWith("'") ? dsn : `'${dsn}'`;
      const dsnField = client.findFieldByLabel('Data Set Name', 'left')
                    ?? client.findFieldByLabel('Dsname', 'left')
                    ?? client.findFieldByLabel('Name', 'left');
      if (!dsnField) {
        await client.sendAID('PF3'); await client.waitForKeyboardUnlock(3000);
        res.writeHead(500); res.end(JSON.stringify({ error: 'Data Set Name field not found on View Entry Panel' })); return;
      }
      // Include member in the DSN string (e.g. 'SYS1.PARMLIB(IEASYS00)')
      // because the "Other" section uses a single Name field, not a separate Member field
      const fullDsn = member ? `'${dsn}(${member})'` : qualDsn;
      client.clearFieldAt(dsnField.row, dsnField.col);
      client.setCursor(dsnField.row, dsnField.col);
      client.typeText(fullDsn);

      // Step 4: Open the dataset
      await client.sendAID('ENTER');
      await client.waitForKeyboardUnlock(5000);

      // Check for errors (dataset not found, protected, etc.)
      const screenAfterOpen = client.getScreenText().join('\n');
      const errorPatterns = [
        /not found/i, /not cataloged/i, /does not exist/i,
        /DSNB000/i, /DSNE003/i, /not authorized/i, /IEC\d{3}/i,
      ];
      if (errorPatterns.some(p => p.test(screenAfterOpen))) {
        const ispfMsg = client.extractIspfMessage();
        await client.sendAID('PF3'); await client.waitForKeyboardUnlock(3000);
        res.writeHead(404); res.end(JSON.stringify({
          error: `Dataset not found or not accessible: ${qualDsn}${member ? `(${member})` : ''}`,
          ispfMessage: ispfMsg.short || ispfMsg.long,
        })); return;
      }

      // Step 5: Collect all pages
      const scrollResult = await client.scrollAllPages('PF8', 'BOTTOM OF DATA', 2000, 120000, 1);

      // Step 6: Exit View — need 2x PF3 (first exits View, then exits View Entry Panel)
      await client.sendAID('PF3');
      await client.waitForKeyboardUnlock(3000);
      // If we're back on View Entry Panel, press PF3 again to return to original context
      const afterExit = client.getScreenText().join(' ');
      if (/View Entry|Name \. \. \./i.test(afterExit)) {
        await client.sendAID('PF3');
        await client.waitForKeyboardUnlock(3000);
      }

      // Step 7: Filter and strip ISPF line numbers
      // ISPF View/Browse lines have: NNNNNN content (6-digit line number + space)
      const dataLines: string[] = [];
      let inData = false;
      for (const line of scrollResult.lines) {
        const trimmed = line.trim();
        if (!trimmed) { if (inData) dataLines.push(''); continue; }
        // ISPF header pattern: starts with "BROWSE " or "VIEW " or "VIEWING "
        if (/^(BROWSE|VIEW(ING)?)\s+/i.test(trimmed)) { inData = true; continue; }
        if (!inData) continue;
        // Skip ISPF chrome lines
        if (/^\*[A-Z@#$][A-Z@#$0-9]{1,7}\s*$/.test(trimmed)) continue; // panelId markers
        if (/^(PF|F)\d|^BOTTOM OF DATA|^TOP OF DATA/.test(trimmed)) continue; // PF keys, boundaries
        if (/^[-=─\s]+$/.test(trimmed)) continue; // separator lines
        if (/={3,}>/.test(trimmed) && !/^\s*\d{6}\s/.test(trimmed)) continue; // "Command ===>" chrome (not data lines with line numbers)
        if (/^\*{4,}.*\*{4,}$/.test(trimmed)) continue; // "****** Top/Bottom of Data ******" ruler lines
        if (/BOTTOM OF DATA|TOP OF DATA/i.test(trimmed)) continue; // boundary markers anywhere
        if (/^==MSG>/.test(trimmed)) continue; // ISPF informational messages
        // Strip 6-digit or 7-char ISPF line number if present: "000001 content"
        const m = line.match(/^(\s*\d{6})\s(.*)$/);
        dataLines.push(m ? m[2] : line);
      }

      // Trim trailing blank lines
      while (dataLines.length > 0 && dataLines[dataLines.length - 1].trim() === '') {
        dataLines.pop();
      }

      res.writeHead(200); res.end(JSON.stringify({
        success: true,
        dsn: qualDsn,
        member: member || null,
        lines: dataLines,
        lineCount: dataLines.length,
        pages: scrollResult.pages,
        stopped: scrollResult.stopped,
      }));
    } catch (err: any) {
      this.outputChannel.appendLine(`[FileGet Error] ${err.message}`);
      // Best-effort: try to exit any opened panel
      try { await client.sendAID('PF3'); await client.waitForKeyboardUnlock(2000); } catch {}
      res.writeHead(500); res.end(JSON.stringify({ error: err.message }));
    }
  }

  // ─── /file/put — Write content to a PDS member via ISPF Edit (1.8.0) ──────

  /**
   * POST /file/put
   * Body: { dsn: string, member?: string, content: string | string[] }
   *
   * Writes content to a z/OS PDS member using ISPF Edit:
   *   1. Navigate to Edit Entry Panel (=2)
   *   2. Fill dataset name (with member) in the "Other" Name field
   *   3. CAPS OFF to preserve case
   *   4. Delete existing content via D99999 line command on first data line
   *   5. Insert lines via I<n> line command on "Top of Data"
   *   6. Fill data fields (col 9, len 72) in batches of up to 15 lines
   *   7. SAVE and PF3 to exit
   *
   * ISPF Edit field layout (IBM 3278 Model 2, 24x80):
   *   Row 4, col 15: Command/Option field (len 48)
   *   Row 5+, col 2, len 6: Line command area (where I, D, etc. go)
   *   Row 5+, col 9, len 72: Data area (editable when prot=false)
   *   "Top of Data" row: col 2 shows "******", col 9 is protected
   *   Insert-mode rows: col 2 shows "''''''", col 9 is unprotected (prot=false)
   */
  private async handleFilePut(body: string, sid: string, res: http.ServerResponse): Promise<void> {
    const client = this.clientFor(sid);
    if (!client) { res.writeHead(400); res.end(JSON.stringify({ error: 'Not connected' })); return; }

    let parsed: any;
    try { parsed = JSON.parse(body); } catch { res.writeHead(400); res.end(JSON.stringify({ error: 'Invalid JSON' })); return; }

    const rawDsn = String(parsed.dsn || '');
    const rawMember = String(parsed.member || '');
    let lines: string[] = [];
    if (Array.isArray(parsed.content)) {
      lines = parsed.content;
    } else if (typeof parsed.content === 'string') {
      lines = parsed.content.split(/\r?\n/);
    }

    if (!rawDsn.trim()) { res.writeHead(400); res.end(JSON.stringify({ error: 'dsn required' })); return; }
    if (lines.length === 0) { res.writeHead(400); res.end(JSON.stringify({ error: 'content required' })); return; }
    let dsn: string;
    let member: string;
    try {
      ({ dsn, member } = validateDatasetReference(rawDsn, rawMember));
    } catch (err: any) {
      res.writeHead(400); res.end(JSON.stringify({ error: err.message })); return;
    }
    if (!lines.every(line => typeof line === 'string')) {
      res.writeHead(400); res.end(JSON.stringify({ error: 'content array must contain only strings' })); return;
    }
    if (lines.some(line => line.length > 144)) {
      res.writeHead(400); res.end(JSON.stringify({ error: 'Lines longer than 144 characters are not supported safely' })); return;
    }

    const panelId = client.detectPanelId();
    if (!panelId) {
      res.writeHead(400); res.end(JSON.stringify({ error: 'Must be in ISPF session' })); return;
    }

    try {
      // Step 1: Navigate to Edit Entry Panel (=2)
      const optField = client.resolveFieldName('OPTION') ?? client.resolveFieldName('COMMAND');
      if (!optField) { res.writeHead(400); res.end(JSON.stringify({ error: 'No OPTION/COMMAND field' })); return; }
      client.clearFieldAt(optField.row, optField.col);
      client.setCursor(optField.row, optField.col);
      client.typeText('=2');
      await client.sendAID('ENTER');
      await client.waitForText('/Edit Entry|Name \\. \\. \\./i', 5000);

      // Step 2: Fill dataset name with member in "Other" section Name field
      const fullDsn = member ? `'${dsn}(${member})'` : `'${dsn}'`;
      const dsnField = client.findFieldByLabel('Name', 'left');
      if (!dsnField) {
        await client.sendAID('PF3'); await client.waitForKeyboardUnlock(3000);
        res.writeHead(500); res.end(JSON.stringify({ error: 'Name field not found on Edit Entry Panel' })); return;
      }
      client.clearFieldAt(dsnField.row, dsnField.col);
      client.setCursor(dsnField.row, dsnField.col);
      client.typeText(fullDsn);
      await client.sendAID('ENTER');
      await client.waitForKeyboardUnlock(5000);

      // Check if we got an error
      const screenCheck = client.getScreenText().join('\n');
      if (/not found|not cataloged|does not exist|not authorized/i.test(screenCheck)) {
        const msg = client.extractIspfMessage();
        await client.sendAID('PF3'); await client.waitForKeyboardUnlock(3000);
        res.writeHead(404); res.end(JSON.stringify({ error: msg.short || msg.long || 'Dataset error' })); return;
      }

      // Wait for Edit mode
      await client.waitForText('/Top of Data|EDIT.*Columns/i', 5000);

      // Step 3: CAPS OFF to preserve original case
      const cmdCaps = client.resolveFieldName('COMMAND') ?? client.resolveFieldName('OPTION');
      if (cmdCaps) {
        client.clearFieldAt(cmdCaps.row, cmdCaps.col);
        client.setCursor(cmdCaps.row, cmdCaps.col);
        client.typeText('CAPS OFF');
        await client.sendAID('ENTER');
        await client.waitForKeyboardUnlock(3000);
      }

      // Step 4: Delete existing content if any
      // Find the first data line field: col=2 with content matching a line number (digits)
      const allFields = client.getInputFields();
      const firstDataLineCmd = allFields.find(f =>
        !f.protected && f.col === 2 && f.length === 6 && /^\d{6}$/.test(f.content.padStart(6, '0'))
      );
      if (firstDataLineCmd) {
        // There's existing content — delete it with D99999 line command
        client.setCursor(firstDataLineCmd.row, firstDataLineCmd.col);
        client.clearFieldAt(firstDataLineCmd.row, firstDataLineCmd.col);
        client.typeText('D99999');
        await client.sendAID('ENTER');
        await client.waitForKeyboardUnlock(3000);
      }

      // Step 5: Insert and fill lines in batches
      // ISPF Edit on Model 2 (24x80) shows data lines in rows 5-21 (up to 17 lines)
      // But with Top of Data + Bottom of Data taking rows, effective max is ~15 insert lines
      // IMPORTANT: I<n> on "Top of Data" inserts BEFORE existing content, so we
      // process batches in REVERSE order (last batch first) to get correct final order.
      const BATCH_SIZE = 15;
      const batches: string[][] = [];
      for (let i = 0; i < lines.length; i += BATCH_SIZE) {
        batches.push(lines.slice(i, i + BATCH_SIZE));
      }
      batches.reverse(); // last batch first — each insert at Top pushes previous down
      let written = 0;

      for (const batch of batches) {
        // Scroll to TOP to ensure "Top of Data" is visible
        const cmdTop = client.resolveFieldName('COMMAND') ?? client.resolveFieldName('OPTION');
        if (cmdTop) {
          client.clearFieldAt(cmdTop.row, cmdTop.col);
          client.setCursor(cmdTop.row, cmdTop.col);
          client.typeText('TOP');
          await client.sendAID('ENTER');
          await client.waitForKeyboardUnlock(3000);
        }

        // Find the "Top of Data" row — it has "******" in col 2 area and "Top of Data" in col 9
        const fields = client.getInputFields();
        const topOfDataLineCmd = fields.find(f =>
          !f.protected && f.col === 2 && f.length === 6 &&
          f.content.trim() === '******'
        );

        if (!topOfDataLineCmd) {
          // If we can't find Top of Data even after TOP command, try scroll up
          await client.sendAID('PF7');
          await client.waitForKeyboardUnlock(3000);
          const fields2 = client.getInputFields();
          const anyLineCmd = fields2.find(f => !f.protected && f.col === 2 && f.length === 6);
          if (!anyLineCmd) {
            this.outputChannel.appendLine(`[FilePut] No line command field found at batch offset ${written}`);
            break;
          }
          client.setCursor(anyLineCmd.row, anyLineCmd.col);
          client.clearFieldAt(anyLineCmd.row, anyLineCmd.col);
          client.typeText(`I${batch.length}`);
        } else {
          // Issue I<n> on Top of Data row's line command area
          client.setCursor(topOfDataLineCmd.row, topOfDataLineCmd.col);
          client.clearFieldAt(topOfDataLineCmd.row, topOfDataLineCmd.col);
          client.typeText(`I${batch.length}`);
        }

        await client.sendAID('ENTER');
        await client.waitForKeyboardUnlock(3000);

        // Now find the editable data fields (col=9, prot=false, len=72)
        const insertFields = client.getInputFields().filter(f =>
          !f.protected && f.col === 9 && f.length === 72
        );

        if (insertFields.length === 0) {
          this.outputChannel.appendLine(`[FilePut] No editable data fields after INSERT at batch offset ${written}`);
          break;
        }

        // Fill each insert line — use setCursor + clearField + typeText for each
        let lineIdx = 0;
        for (const field of insertFields) {
          if (lineIdx >= batch.length) break;
          const lineText = batch[lineIdx].substring(0, 72);
          client.setCursor(field.row, field.col);
          client.clearFieldAt(field.row, field.col);
          if (lineText) {
            client.typeText(lineText);
          }
          lineIdx++;
        }

        // Press ENTER to commit the inserted lines (empty ones will be discarded)
        await client.sendAID('ENTER');
        await client.waitForKeyboardUnlock(3000);
        written += lineIdx;

        if (lineIdx === 0) {
          this.outputChannel.appendLine(`[FilePut] No lines written in batch at offset ${written}`);
          break;
        }

        this.outputChannel.appendLine(`[FilePut] Batch written: ${lineIdx} lines (total ${written}/${lines.length})`);
      }

      if (written !== lines.length) {
        const cancelField = client.resolveFieldName('COMMAND') ?? client.resolveFieldName('OPTION');
        if (cancelField) {
          client.clearFieldAt(cancelField.row, cancelField.col);
          client.setCursor(cancelField.row, cancelField.col);
          client.typeText('CANCEL');
          await client.sendAID('ENTER');
          await client.waitForKeyboardUnlock(3000);
        }
        throw new Error(`Write incomplete: ${written} of ${lines.length} lines inserted; changes cancelled`);
      }

      // Step 5b: Second pass — fill columns 73+ for lines that exceed 72 chars
      const longLines = lines
        .map((line, idx) => ({ idx, tail: line.substring(72) }))
        .filter(x => x.tail.length > 0);

      if (longLines.length > 0) {
        this.outputChannel.appendLine(`[FilePut] ${longLines.length} lines exceed 72 chars, doing RIGHT pass`);

        // NUM OFF to avoid sequence numbers occupying cols 73-80
        const cmdNum = client.resolveFieldName('COMMAND') ?? client.resolveFieldName('OPTION');
        if (cmdNum) {
          client.clearFieldAt(cmdNum.row, cmdNum.col);
          client.setCursor(cmdNum.row, cmdNum.col);
          client.typeText('NUM OFF');
          await client.sendAID('ENTER');
          await client.waitForKeyboardUnlock(3000);
        }

        // TOP + RIGHT 72 to show columns 73+
        const cmdTop2 = client.resolveFieldName('COMMAND') ?? client.resolveFieldName('OPTION');
        if (cmdTop2) {
          client.clearFieldAt(cmdTop2.row, cmdTop2.col);
          client.setCursor(cmdTop2.row, cmdTop2.col);
          client.typeText('TOP');
          await client.sendAID('ENTER');
          await client.waitForKeyboardUnlock(3000);
        }

        const cmdRight = client.resolveFieldName('COMMAND') ?? client.resolveFieldName('OPTION');
        if (cmdRight) {
          client.clearFieldAt(cmdRight.row, cmdRight.col);
          client.setCursor(cmdRight.row, cmdRight.col);
          client.typeText('RIGHT 72');
          await client.sendAID('ENTER');
          await client.waitForKeyboardUnlock(3000);
        }

        // Now page through the file filling in tails
        // After TOP, first visible data line = line 1 (index 0)
        let currentLine = 0; // 0-based index of first visible data line
        const longLineSet = new Map(longLines.map(l => [l.idx, l.tail]));
        let rightPassDone = false;

        while (!rightPassDone && currentLine < lines.length) {
          // Find editable data fields (col=9, not protected)
          const dataFields = client.getInputFields().filter(f =>
            !f.protected && f.col === 9 && f.length === 72
          );

          if (dataFields.length === 0) {
            this.outputChannel.appendLine(`[FilePut] RIGHT pass: no data fields visible at line ${currentLine}`);
            break;
          }

          let anyFilled = false;
          for (let fi = 0; fi < dataFields.length && (currentLine + fi) < lines.length; fi++) {
            const lineIdx = currentLine + fi;
            const tail = longLineSet.get(lineIdx);
            if (tail) {
              client.setCursor(dataFields[fi].row, dataFields[fi].col);
              client.clearFieldAt(dataFields[fi].row, dataFields[fi].col);
              client.typeText(tail);
              anyFilled = true;
            }
          }

          if (anyFilled) {
            await client.sendAID('ENTER');
            await client.waitForKeyboardUnlock(3000);
          }

          // Check if we've covered all long lines
          const lastVisibleLine = currentLine + dataFields.length - 1;
          const maxLongIdx = longLines[longLines.length - 1].idx;
          if (lastVisibleLine >= maxLongIdx) {
            rightPassDone = true;
          } else {
            // Scroll down (F8) to see more lines
            currentLine += dataFields.length;
            await client.sendAID('PF8');
            await client.waitForKeyboardUnlock(3000);
          }
        }

        // Return to normal view: LEFT MAX
        const cmdLeft = client.resolveFieldName('COMMAND') ?? client.resolveFieldName('OPTION');
        if (cmdLeft) {
          client.clearFieldAt(cmdLeft.row, cmdLeft.col);
          client.setCursor(cmdLeft.row, cmdLeft.col);
          client.typeText('LEFT MAX');
          await client.sendAID('ENTER');
          await client.waitForKeyboardUnlock(3000);
        }

        this.outputChannel.appendLine(`[FilePut] RIGHT pass complete`);
      }

      // Step 6: SAVE
      const cmdSave = client.resolveFieldName('COMMAND') ?? client.resolveFieldName('OPTION');
      if (cmdSave) {
        client.clearFieldAt(cmdSave.row, cmdSave.col);
        client.setCursor(cmdSave.row, cmdSave.col);
        client.typeText('SAVE');
        await client.sendAID('ENTER');
        await client.waitForKeyboardUnlock(3000);
      }

      // Step 7: EXIT with PF3 — goes from Edit → Edit Entry Panel
      await client.sendAID('PF3');
      await client.waitForKeyboardUnlock(3000);
      // If we're on Edit Entry Panel, PF3 again to go back to caller
      const afterExit = client.getScreenText().join(' ');
      if (/Edit Entry|Name \. \. \./i.test(afterExit)) {
        await client.sendAID('PF3');
        await client.waitForKeyboardUnlock(3000);
      }

      res.writeHead(200); res.end(JSON.stringify({
        success: true,
        dsn: fullDsn,
        linesWritten: written,
      }));
    } catch (err: any) {
      this.outputChannel.appendLine(`[FilePut Error] ${err.message}`);
      try { await client.sendAID('PF3'); await client.waitForKeyboardUnlock(2000); } catch {}
      try { await client.sendAID('PF3'); await client.waitForKeyboardUnlock(2000); } catch {}
      res.writeHead(500); res.end(JSON.stringify({ error: err.message }));
    }
  }

  private disconnectClient(): void {
    // Mark this disconnect as user-initiated (v2.6.0) so the auto-reconnect
    // logic in the 'disconnected' handler does NOT trigger. Any passive
    // socket close (network drop, host FIN, TLS error) leaves this flag
    // false and lets auto-reconnect run.
    if (this.client) { this.userInitiatedDisconnect = true; this.client.disconnect(); this.client = null; }
    this._state = { ...this._state, connected: false, host: undefined, mainframePort: undefined };
    this.fireStateChangeImmediate();
  }

  /**
   * Auto-reconnect state machine (v2.6.0). Runs when the socket closes
   * without user intent and `tn3270Bridge.autoReconnect.enabled` is true.
   *
   * Backoff: 2s, 4s, 8s, 16s, 32s. Emits a status-bar update on each
   * attempt so the user sees progress. Preserves the exact host/port/luName
   * and TLS settings of the last successful connect via `lastConnectParams`.
   *
   * Stops on first success, or after `maxAttempts` failures (leaves the
   * session disconnected with the last error surfaced to the Output channel).
   */
  private async tryAutoReconnect(maxAttempts: number): Promise<void> {
    if (this.reconnectInProgress) return;
    if (!this.lastConnectParams) return;
    this.reconnectInProgress = true;
    const params = this.lastConnectParams;
    try {
      let delay = 2000;
      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        this.outputChannel.appendLine(
          `[AutoReconnect] Attempt ${attempt}/${maxAttempts} to ${params.host}:${params.port} in ${delay / 1000}s...`
        );
        void vscode.window.setStatusBarMessage(
          `$(sync~spin) TN3270: reconnecting (${attempt}/${maxAttempts})…`,
          delay + 5000
        );
        await new Promise(r => setTimeout(r, delay));
        // Bail if the user manually reconnected in the meantime.
        if (this.client && this.client.state.status === 'connected') {
          this.outputChannel.appendLine('[AutoReconnect] Aborting — user already reconnected.');
          return;
        }
        try {
          const r = await this.connectTo(
            params.host, params.port, params.luName,
            params.tlsOverride, params.modelOverride
          );
          if (r.success) {
            this.outputChannel.appendLine('[AutoReconnect] Reconnected successfully.');
            void vscode.window.setStatusBarMessage(
              `$(check) TN3270: reconnected to ${params.host}:${params.port}`,
              4000
            );
            return;
          }
          this.outputChannel.appendLine(
            `[AutoReconnect] Attempt ${attempt} failed — ${r.errorCode || r.error || 'unknown'}`
          );
        } catch (e: any) {
          this.outputChannel.appendLine(`[AutoReconnect] Attempt ${attempt} threw — ${e.message}`);
        }
        delay = Math.min(delay * 2, 32000);
      }
      this.outputChannel.appendLine(
        `[AutoReconnect] Giving up after ${maxAttempts} attempts.`
      );
      void vscode.window.setStatusBarMessage(
        `$(error) TN3270: auto-reconnect failed after ${maxAttempts} attempts`,
        6000
      );
    } finally {
      this.reconnectInProgress = false;
    }
  }

  private readBody(req: http.IncomingMessage): Promise<string> {
    return new Promise((resolve, reject) => {
      let body = '';
      let bytes = 0;
      req.on('data', chunk => {
        bytes += chunk.length;
        if (bytes > MAX_REQUEST_BODY_BYTES) {
          reject(new Error(`Request body exceeds ${MAX_REQUEST_BODY_BYTES} bytes`));
          req.destroy();
          return;
        }
        body += chunk;
      });
      req.on('end', () => resolve(body));
      req.on('error', reject);
      req.on('aborted', () => reject(new Error('Request aborted')));
    });
  }

  private withBody(
    req: http.IncomingMessage,
    res: http.ServerResponse,
    handler: (body: string) => void | Promise<void>,
  ): void {
    void this.readBody(req).then(handler).catch(err => this.handleBodyError(err, res));
  }

  private handleBodyError(err: Error, res: http.ServerResponse): void {
    if (res.headersSent) return;
    const tooLarge = err.message.includes('exceeds');
    res.writeHead(tooLarge ? 413 : 400);
    res.end(JSON.stringify({ error: err.message }));
  }

  /**
   * Parse a body that may be JSON or application/x-www-form-urlencoded.
   * Defaults to JSON when content-type is missing or unrecognized.
   */
  private parseBody(body: string, contentType: string | undefined): any {
    if (!body) return {};
    const ct = (contentType || '').toLowerCase();
    if (ct.includes('application/x-www-form-urlencoded')) {
      const out: Record<string, string> = {};
      for (const pair of body.split('&')) {
        if (!pair) continue;
        const eq = pair.indexOf('=');
        const k = decodeURIComponent((eq < 0 ? pair : pair.slice(0, eq)).replace(/\+/g, ' '));
        const v = eq < 0 ? '' : decodeURIComponent(pair.slice(eq + 1).replace(/\+/g, ' '));
        out[k] = v;
      }
      return out;
    }
    // Trim BOM / whitespace that PowerShell sometimes injects
    const trimmed = body.trim().replace(/^﻿/, '');
    if (!trimmed) return {};
    try { return JSON.parse(trimmed); }
    catch (e: any) {
      throw new Error(`Invalid JSON body: ${e.message}. Use Content-Type: application/x-www-form-urlencoded for form bodies.`);
    }
  }
}

function parseBool(v: string | null, def: boolean): boolean {
  if (v === null || v === undefined) return def;
  const s = v.toLowerCase();
  if (s === 'true' || s === '1' || s === 'yes') return true;
  if (s === 'false' || s === '0' || s === 'no') return false;
  return def;
}
