/**
 * Saved sessions — persistent named connection profiles the user picks from
 * a dropdown, mirroring the enterprise-emulator UX (Mocha TN3270, IBM PComm)
 * where the mainframe endpoint list follows the user across VS Code
 * restarts and — via Settings Sync — across machines.
 *
 * Storage: context.globalState under key `tn3270Bridge.savedSessions` as a
 * SavedSession[] array. We deliberately do NOT use settings.json because
 * `tn3270Bridge.loginProfiles` already lives there with a completely
 * different shape (login-script credentials), and a second cross-cutting
 * concept would pollute the schema.
 *
 * Cert pin (SHA-256) is embedded in the session AND mirrored to
 * SecretStorage per-machine so a `Trust this cert` decision on one machine
 * follows to another via Settings Sync while still supporting purely-local
 * pinning if the user prefers.
 */
import * as vscode from 'vscode';

export type TlsPreset = 'modern-verified' | 'corporate-ca' | 'legacy' | 'encrypted-only' | 'custom';
export type ScreenModel = 'model2' | 'model3' | 'model4' | 'model5';

export interface SavedSession {
  /** Stable slug generated on save; never surfaced to the user. */
  id: string;
  /** User-visible label. */
  name: string;
  host: string;
  port: number;
  luName?: string;
  tls?: {
    enabled: boolean;
    preset: TlsPreset;
    caBundle?: string;
    sni?: string;
    /** SHA-256 pin, uppercase colon-separated. Safe to store — not a secret. */
    pinnedFingerprint?: string;
  };
  screenModel?: ScreenModel;
  createdAt: string;
  lastUsedAt?: string;
}

const STORAGE_KEY = 'tn3270Bridge.savedSessions';

export class SavedSessionsStore {
  constructor(private readonly context: vscode.ExtensionContext) {
    // Opt this key into VS Code Settings Sync so the list of hosts follows
    // the user across machines. Cert pins ride along inside each session.
    try {
      context.globalState.setKeysForSync([STORAGE_KEY]);
    } catch {
      // Older VS Code versions may not support setKeysForSync — non-fatal.
    }
  }

  /**
   * Load all saved sessions, sorted most-recently-used first, then by name.
   */
  loadAll(): SavedSession[] {
    const raw = this.context.globalState.get<SavedSession[]>(STORAGE_KEY, []);
    // Defensive copy + shape guard: silently drop malformed entries rather
    // than throw, so a corrupted globalState never breaks the UI.
    const clean = Array.isArray(raw) ? raw.filter(isValidSession) : [];
    return [...clean].sort(compareSessions);
  }

  get(id: string): SavedSession | undefined {
    return this.loadAll().find(s => s.id === id);
  }

  /**
   * Upsert (create or replace by id). If `session.id` is empty, a new id
   * is generated and returned in the resolved session.
   */
  async save(session: SavedSession): Promise<SavedSession> {
    const list = this.loadAll();
    const idx = session.id ? list.findIndex(s => s.id === session.id) : -1;
    const nowIso = new Date().toISOString();
    const finalized: SavedSession = {
      ...session,
      id: session.id || generateId(),
      createdAt: session.createdAt || nowIso,
    };
    if (idx >= 0) {
      list[idx] = finalized;
    } else {
      list.push(finalized);
    }
    await this.context.globalState.update(STORAGE_KEY, list);
    return finalized;
  }

  async delete(id: string): Promise<void> {
    const list = this.loadAll().filter(s => s.id !== id);
    await this.context.globalState.update(STORAGE_KEY, list);
  }

  /**
   * Update lastUsedAt on the session matching (host, port). Called after a
   * successful connect so the dropdown surfaces the most recent host.
   */
  async touchByHostPort(host: string, port: number): Promise<void> {
    const list = this.loadAll();
    const match = list.find(s => s.host.toLowerCase() === host.toLowerCase() && s.port === port);
    if (!match) return;
    match.lastUsedAt = new Date().toISOString();
    await this.context.globalState.update(STORAGE_KEY, list);
  }

  /**
   * Persist a pinned fingerprint back into any saved session that matches
   * (host, port). Called when the user clicks `Trust this cert` on a
   * session that was previously saved without a pin (or with an outdated
   * pin after cert re-issuance).
   */
  async updatePinByHostPort(host: string, port: number, fingerprint: string): Promise<void> {
    const list = this.loadAll();
    const match = list.find(s => s.host.toLowerCase() === host.toLowerCase() && s.port === port);
    if (!match) return;
    match.tls = match.tls ?? { enabled: true, preset: 'modern-verified' };
    match.tls.pinnedFingerprint = fingerprint;
    await this.context.globalState.update(STORAGE_KEY, list);
  }
}

function generateId(): string {
  // ULID-ish: timestamp base36 + 6 chars of crypto randomness. Not
  // cryptographically strong (session ids aren't secret) but comfortably
  // collision-free for a per-user list of ~dozens of entries.
  const buf = new Uint8Array(4);
  (globalThis.crypto || require('crypto').webcrypto).getRandomValues(buf);
  const rand = Array.from(buf).map(b => b.toString(36).padStart(2, '0')).join('').slice(0, 6);
  return `s_${Date.now().toString(36)}_${rand}`;
}

function isValidSession(x: unknown): x is SavedSession {
  return !!x
    && typeof x === 'object'
    && typeof (x as any).id === 'string'
    && typeof (x as any).name === 'string'
    && typeof (x as any).host === 'string'
    && typeof (x as any).port === 'number';
}

function compareSessions(a: SavedSession, b: SavedSession): number {
  const at = a.lastUsedAt || '';
  const bt = b.lastUsedAt || '';
  if (at !== bt) return bt.localeCompare(at); // most recent first
  return a.name.localeCompare(b.name);
}
