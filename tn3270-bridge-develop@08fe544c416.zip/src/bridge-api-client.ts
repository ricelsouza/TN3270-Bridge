import { requestBridgeToken } from './local-credential-broker';

/**
 * Health payload returned by `GET /health` — used by autodiscovery to pick
 * the right bridge among possibly-multiple concurrent VS Code windows.
 */
export interface BridgeHealth {
  bridge: 'running';
  version: string;
  port: number;
  connected: boolean;
  host?: string;
  mainframePort?: number;
  pid?: number;
  startedAt?: string;
  extensionPath?: string;
}

export class BridgeApiClient {
  constructor(
    private readonly baseUrl: string,
    private readonly token: string,
  ) {
    if (!token) throw new Error('TN3270_BRIDGE_TOKEN is required');
  }

  static async connect(baseUrl: string, token = process.env.TN3270_BRIDGE_TOKEN): Promise<BridgeApiClient> {
    const url = new URL(baseUrl);
    const port = Number(url.port) || (url.protocol === 'https:' ? 443 : 80);
    return new BridgeApiClient(baseUrl, token || await requestBridgeToken(port));
  }

  /**
   * Auto-discover a running TN3270 Bridge on 127.0.0.1 by probing the
   * `/health` endpoint on the default port range. Preferences (in order):
   *   1. Bridge currently connected to a mainframe (`connected: true`)
   *   2. Optional filter: matching host / mainframePort passed by caller
   *   3. Newest `startedAt` if none is connected (freshest wins)
   *   4. Highest port (assumes newer VS Code windows land on later ports)
   *
   * Returns an authenticated BridgeApiClient. Also returns the underlying
   * `BridgeHealth` via `.discoveredHealth` on the client for diagnostics.
   *
   * Ports scanned: 7327 through 7335 inclusive (nine ports, adequate for
   * up to nine concurrent extension hosts). Probes run in parallel with a
   * 1500 ms timeout each, so worst-case discovery latency is ~1.5 s even
   * when no bridge is running.
   */
  static async discover(opts: {
    startPort?: number;
    endPort?: number;
    preferHost?: string;
    preferMainframePort?: number;
  } = {}): Promise<BridgeApiClient & { discoveredHealth?: BridgeHealth }> {
    const startPort = opts.startPort ?? 7327;
    const endPort = opts.endPort ?? 7335;
    const ports: number[] = [];
    for (let p = startPort; p <= endPort; p++) ports.push(p);

    const probes = await Promise.all(ports.map(async p => {
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 1500);
        const r = await fetch(`http://127.0.0.1:${p}/health`, { signal: controller.signal });
        clearTimeout(timer);
        if (!r.ok) return null;
        const data = (await r.json()) as BridgeHealth;
        if (!data || data.bridge !== 'running') return null;
        return { port: p, data };
      } catch {
        return null;
      }
    }));

    const live = probes.filter((x): x is { port: number; data: BridgeHealth } => x !== null);
    if (live.length === 0) {
      throw new Error(
        `No TN3270 Bridge detected on 127.0.0.1:${startPort}-${endPort}. ` +
        `Is the VS Code extension installed and its bridge server running? ` +
        `Set TN3270_BRIDGE_URL to override discovery.`
      );
    }

    // Ranking function: connected > matches-preferred-host > newer startedAt > higher port
    const scored = live.map(({ port, data }) => {
      let score = 0;
      if (data.connected) score += 1000;
      if (opts.preferHost && data.host && data.host.toLowerCase() === opts.preferHost.toLowerCase()) score += 500;
      if (opts.preferMainframePort && data.mainframePort === opts.preferMainframePort) score += 200;
      if (data.startedAt) score += (Date.parse(data.startedAt) || 0) / 1e9; // small tie-breaker
      score += port / 1e6; // deterministic last-resort tie-breaker
      return { port, data, score };
    });
    scored.sort((a, b) => b.score - a.score);
    const best = scored[0];

    const client = await BridgeApiClient.connect(`http://127.0.0.1:${best.port}`);
    (client as any).discoveredHealth = best.data;
    return client as BridgeApiClient & { discoveredHealth?: BridgeHealth };
  }

  async request(path: string, init?: RequestInit): Promise<unknown> {
    const response = await fetch(new URL(path, this.baseUrl), {
      ...init,
      headers: {
        Authorization: `Bearer ${this.token}`,
        'Content-Type': 'application/json',
        ...init?.headers,
      },
      signal: AbortSignal.timeout(130_000),
    });
    const payload = await response.json().catch(() => ({ error: response.statusText }));
    if (!response.ok) {
      const message = typeof payload === 'object' && payload && 'error' in payload
        ? String(payload.error)
        : `Bridge request failed with HTTP ${response.status}`;
      throw new Error(message);
    }
    return payload;
  }

  get(path: string): Promise<unknown> {
    return this.request(path);
  }

  post(path: string, body: unknown = {}): Promise<unknown> {
    return this.request(path, { method: 'POST', body: JSON.stringify(body) });
  }

  delete(path: string): Promise<unknown> {
    return this.request(path, { method: 'DELETE' });
  }
}