/**
 * Structured screen extraction — v2.6.0.
 *
 * The `mainframe_read_screen` tool returns the raw 24×80 (or 32×80 or 43×80)
 * grid, which forces AI agents to parse strings to find data. For any
 * substantive automation this becomes fragile: whitespace shifts, panel
 * versions differ, screen size changes.
 *
 * This module provides three extraction primitives that return structured
 * data directly:
 *
 *  - **regex**: apply a JS regular expression to the full screen (joined
 *    line-by-line) and return each match with capture groups + row/col of
 *    the match start.
 *
 *  - **labels**: find a label on the screen and return the text that
 *    follows it on the same line, up to the next label / protected field
 *    boundary or end-of-line. Handles multiple occurrences.
 *
 *  - **anchor**: return lines strictly between two anchor patterns. Useful
 *    for "everything between BEGIN and END" style extraction — SDSF spool
 *    output between markers, ISPF dialog messages, etc.
 *
 * All modes preserve trailing whitespace stripping. Row/col coordinates are
 * 1-indexed to match the rest of the bridge API.
 */

export type ExtractMode = 'regex' | 'labels' | 'anchor';

export interface RegexMatch {
  row: number;
  col: number;
  text: string;
  groups: string[];
}

export interface LabelMatch {
  labelRow: number;
  labelCol: number;
  valueRow: number;
  valueCol: number;
  value: string;
}

export interface AnchorResult {
  startRow: number | null;
  endRow: number | null;
  lines: string[];
}

export interface ExtractRequest {
  mode: ExtractMode;
  pattern: string;
  /** Only used for `anchor` mode; the second anchor. */
  endPattern?: string;
  /** Regex flags (default `i`). */
  flags?: string;
  /** Regex mode: max matches to return (safety, default 100). */
  maxMatches?: number;
  /** Labels mode: max characters to read after the label (default 60). */
  valueMaxLen?: number;
  /** Labels mode: additional characters that terminate the value read (default: '.' — because ISPF labels are `Name . . . value`). */
  valueStopChars?: string;
}

export interface ExtractResult {
  mode: ExtractMode;
  pattern: string;
  /** Populated for `regex` mode. */
  matches?: RegexMatch[];
  /** Populated for `labels` mode. */
  labels?: LabelMatch[];
  /** Populated for `anchor` mode. */
  anchor?: AnchorResult;
}

/**
 * Run extraction against a 3270 screen. `screenLines` is the pre-decoded
 * array of visible text (from `getScreenText()`), 1-indexed rows.
 */
export function extractFromScreen(
  screenLines: string[],
  req: ExtractRequest,
): ExtractResult {
  const mode = req.mode;
  const pattern = req.pattern ?? '';
  if (!pattern && mode !== 'anchor') {
    throw new Error(`extract: pattern is required for mode=${mode}`);
  }

  if (mode === 'regex') {
    return {
      mode,
      pattern,
      matches: extractRegex(screenLines, pattern, req.flags ?? 'i', req.maxMatches ?? 100),
    };
  }
  if (mode === 'labels') {
    return {
      mode,
      pattern,
      labels: extractLabels(
        screenLines,
        pattern,
        req.valueMaxLen ?? 60,
        req.valueStopChars ?? '.',
      ),
    };
  }
  if (mode === 'anchor') {
    if (!req.endPattern) {
      throw new Error('extract: endPattern is required for mode=anchor');
    }
    return {
      mode,
      pattern,
      anchor: extractAnchor(screenLines, pattern, req.endPattern),
    };
  }
  throw new Error(`extract: unknown mode ${mode}`);
}

function extractRegex(
  lines: string[],
  pattern: string,
  flags: string,
  maxMatches: number,
): RegexMatch[] {
  // Ensure the regex is global so exec() iterates.
  const safeFlags = flags.includes('g') ? flags : flags + 'g';
  let re: RegExp;
  try {
    re = new RegExp(pattern, safeFlags);
  } catch (e: any) {
    throw new Error(`extract: invalid regex — ${e.message}`);
  }
  const out: RegexMatch[] = [];
  for (let i = 0; i < lines.length; i++) {
    if (out.length >= maxMatches) break;
    const line = lines[i];
    re.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = re.exec(line)) !== null) {
      out.push({
        row: i + 1,
        col: m.index + 1,
        text: m[0],
        groups: m.slice(1) as string[],
      });
      if (out.length >= maxMatches) break;
      // Guard against zero-width infinite loop
      if (m.index === re.lastIndex) re.lastIndex++;
    }
  }
  return out;
}

function extractLabels(
  lines: string[],
  label: string,
  valueMaxLen: number,
  stopChars: string,
): LabelMatch[] {
  const out: LabelMatch[] = [];
  const needle = label.toLowerCase();
  const stopSet = new Set(stopChars.split(''));
  for (let r = 0; r < lines.length; r++) {
    const line = lines[r];
    const lower = line.toLowerCase();
    let searchFrom = 0;
    while (searchFrom < lower.length) {
      const idx = lower.indexOf(needle, searchFrom);
      if (idx < 0) break;
      // Skip leading whitespace, ISPF dot separators, and stop characters
      // right after the label — real value starts after those.
      let cursor = idx + label.length;
      while (
        cursor < line.length &&
        (line[cursor] === ' ' || stopSet.has(line[cursor]))
      ) {
        cursor++;
      }
      // Value ends at end-of-line or first double-space (fields separated
      // by multiple spaces in most ISPF panels).
      const valueStart = cursor;
      let valueEnd = valueStart;
      while (valueEnd < line.length && valueEnd - valueStart < valueMaxLen) {
        if (
          line[valueEnd] === ' ' &&
          valueEnd + 1 < line.length &&
          line[valueEnd + 1] === ' '
        ) {
          break;
        }
        valueEnd++;
      }
      const value = line.substring(valueStart, valueEnd).trimEnd();
      out.push({
        labelRow: r + 1,
        labelCol: idx + 1,
        valueRow: r + 1,
        valueCol: valueStart + 1,
        value,
      });
      searchFrom = valueEnd;
    }
  }
  return out;
}

function extractAnchor(
  lines: string[],
  startPattern: string,
  endPattern: string,
): AnchorResult {
  let startRow: number | null = null;
  let endRow: number | null = null;
  const collected: string[] = [];
  const needleStart = startPattern.toLowerCase();
  const needleEnd = endPattern.toLowerCase();
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i].toLowerCase();
    if (startRow === null) {
      if (l.includes(needleStart)) startRow = i + 1;
      continue;
    }
    if (l.includes(needleEnd)) {
      endRow = i + 1;
      break;
    }
    collected.push(lines[i]);
  }
  return { startRow, endRow, lines: collected };
}
