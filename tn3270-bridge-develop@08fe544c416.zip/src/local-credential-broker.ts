import { createHash } from 'node:crypto';
import { chmodSync, existsSync, unlinkSync } from 'node:fs';
import * as net from 'node:net';
import { tmpdir, userInfo } from 'node:os';
import { join } from 'node:path';

const REQUEST = 'TN3270_TOKEN_V1\n';
const MAX_REQUEST_BYTES = 64;

export function credentialBrokerEndpoint(port: number): string {
  const user = userInfo();
  const identity = process.platform === 'win32' ? user.username : String(user.uid);
  const suffix = createHash('sha256').update(identity).digest('hex').slice(0, 12);
  return process.platform === 'win32'
    ? `\\\\.\\pipe\\tn3270-bridge-${suffix}-${port}`
    : join(tmpdir(), `tn3270-bridge-${suffix}-${port}.sock`);
}

export class LocalCredentialBroker {
  private server: net.Server | null = null;
  private readonly endpoint: string;

  constructor(
    port: number,
    private readonly tokenProvider: () => Promise<string>,
  ) {
    this.endpoint = credentialBrokerEndpoint(port);
  }

  async start(): Promise<void> {
    if (this.server) return;
    if (process.platform !== 'win32' && existsSync(this.endpoint)) unlinkSync(this.endpoint);

    const server = net.createServer(socket => {
      socket.setTimeout(2000, () => socket.destroy());
      let request = '';
      socket.on('data', chunk => {
        request += chunk.toString('utf8');
        if (Buffer.byteLength(request) > MAX_REQUEST_BYTES) socket.destroy();
        if (!request.endsWith('\n')) return;
        if (request !== REQUEST) {
          socket.end(JSON.stringify({ error: 'Invalid broker request' }) + '\n');
          return;
        }
        void this.tokenProvider().then(
          token => socket.end(JSON.stringify({ token }) + '\n'),
          () => socket.end(JSON.stringify({ error: 'Token unavailable' }) + '\n'),
        );
      });
    });

    await new Promise<void>((resolve, reject) => {
      server.once('error', reject);
      server.listen(this.endpoint, () => {
        server.off('error', reject);
        resolve();
      });
    });
    if (process.platform !== 'win32') chmodSync(this.endpoint, 0o600);
    this.server = server;
  }

  async stop(): Promise<void> {
    const server = this.server;
    this.server = null;
    if (!server) return;
    await new Promise<void>(resolve => server.close(() => resolve()));
    if (process.platform !== 'win32' && existsSync(this.endpoint)) unlinkSync(this.endpoint);
  }
}

export async function requestBridgeToken(port: number): Promise<string> {
  const endpoint = credentialBrokerEndpoint(port);
  return new Promise((resolve, reject) => {
    const socket = net.createConnection(endpoint);
    let response = '';
    const timer = setTimeout(() => {
      socket.destroy();
      reject(new Error('TN3270 credential broker timed out'));
    }, 2000);
    const finish = (error?: Error, token?: string) => {
      clearTimeout(timer);
      socket.destroy();
      if (error) reject(error);
      else resolve(token!);
    };
    socket.once('connect', () => socket.write(REQUEST));
    socket.once('error', error => finish(new Error(`TN3270 credential broker unavailable: ${error.message}`)));
    socket.on('data', chunk => {
      response += chunk.toString('utf8');
      if (!response.endsWith('\n')) return;
      try {
        const parsed = JSON.parse(response) as { token?: string; error?: string };
        if (!parsed.token) throw new Error(parsed.error || 'Broker returned no token');
        finish(undefined, parsed.token);
      } catch (error) {
        finish(error instanceof Error ? error : new Error(String(error)));
      }
    });
  });
}