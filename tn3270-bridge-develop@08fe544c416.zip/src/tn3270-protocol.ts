/**
 * TN3270 Protocol Types
 */

const Ebcdic: {
  toAscii(buffer: Buffer, codePage: number): string;
  fromAscii(value: string, codePage: number): Buffer;
} = require('tn3270e_library/ebcdic');

// Telnet commands
export const TELNET = {
  IAC: 0xFF,
  DONT: 0xFE,
  DO: 0xFD,
  WONT: 0xFC,
  WILL: 0xFB,
  SB: 0xFA,
  SE: 0xF0,
  EOR: 0xEF,
  NOP: 0xF1,
  IP:  0xF4,   // Interrupt Process — signals ATTN/break in TN3270 sessions
  DM:  0xF2,   // Data Mark — sent after IAC IP to synchronize the data stream
} as const;

// Telnet options
export const TELOPT = {
  BINARY: 0x00,
  TERMINAL_TYPE: 0x18,
  EOR: 0x19,
  TN3270E: 0x28,
  TIMING_MARK: 0x06, // Synchronization — echo requested after IAC IP/DM
} as const;

// TN3270E sub-options — values per RFC 2355 §5, matching x3270's tn3270e.h.
// Earlier releases (<=2.2.0) had IS=0x00, REJECT=0x04 and ASSOCIATE=0x09,
// which prevented negotiation from ever completing against real z/OS hosts:
// server's `DEVICE-TYPE IS <lu>` was parsed as an unknown verb, so the
// client never sent `FUNCTIONS REQUEST` and the session hung. The values
// below match the RFC and the x3270 reference implementation.
export const TN3270E = {
  ASSOCIATE: 0x00,
  CONNECT: 0x01,
  DEVICE_TYPE: 0x02,
  FUNCTIONS: 0x03,
  IS: 0x04,
  REASON: 0x05,
  REJECT: 0x06,
  REQUEST: 0x07,
  SEND: 0x08,
  // Header data types (5-byte TN3270E header, per RFC 2355 §4)
  DATA_3270: 0x00,
  DATA_SCS: 0x01,
  DATA_RESPONSE: 0x02,
  DATA_BIND: 0x03,
  DATA_UNBIND: 0x04,
  DATA_NVT: 0x05,
  DATA_REQUEST: 0x06,
  DATA_SSCP_LU: 0x07,
  DATA_PRINT: 0x08,
} as const;

// 3270 Data Stream commands (SNA format)
export const CMD = {
  W: 0xF1,       // Write
  EW: 0xF5,      // Erase/Write
  EWA: 0x7E,     // Erase/Write Alternate
  RB: 0xF2,      // Read Buffer
  RM: 0xF6,      // Read Modified
  RMA: 0x6E,     // Read Modified All
  EAU: 0x6F,     // Erase All Unprotected
  WSF: 0xF3,     // Write Structured Field
} as const;

// 3270 Data Stream commands (CCW/local channel format)
export const CMD_CCW = {
  W: 0x01,       // Write
  EW: 0x05,      // Erase/Write
  EWA: 0x0D,     // Erase/Write Alternate
  RB: 0x02,      // Read Buffer
  RM: 0x06,      // Read Modified
  RMA: 0x0E,     // Read Modified All
  EAU: 0x0F,     // Erase All Unprotected
  WSF: 0x11,     // Write Structured Field
} as const;

// 3270 WCC (Write Control Character) bits
export const WCC = {
  RESET: 0x40,
  ALARM: 0x04,
  KEYBOARD_RESTORE: 0x02,
  RESET_MDT: 0x01,
} as const;

// 3270 Orders (within data stream)
export const ORDER = {
  SF: 0x1D,      // Start Field
  SFE: 0x29,     // Start Field Extended
  SBA: 0x11,     // Set Buffer Address
  SA: 0x28,      // Set Attribute
  MF: 0x2C,      // Modify Field
  IC: 0x13,      // Insert Cursor
  PT: 0x05,      // Program Tab
  RA: 0x3C,      // Repeat to Address
  EUA: 0x12,     // Erase Unprotected to Address
  GE: 0x08,      // Graphic Escape
} as const;

// AID (Attention Identifier) keys
export const AID = {
  NONE: 0x60,
  ENTER: 0x7D,
  PF1: 0xF1, PF2: 0xF2, PF3: 0xF3, PF4: 0xF4,
  PF5: 0xF5, PF6: 0xF6, PF7: 0xF7, PF8: 0xF8,
  PF9: 0xF9, PF10: 0x7A, PF11: 0x7B, PF12: 0x7C,
  PF13: 0xC1, PF14: 0xC2, PF15: 0xC3, PF16: 0xC4,
  PF17: 0xC5, PF18: 0xC6, PF19: 0xC7, PF20: 0xC8,
  PF21: 0xC9, PF22: 0x4A, PF23: 0x4B, PF24: 0x4C,
  PA1: 0x6C, PA2: 0x6E, PA3: 0x6B,
  CLEAR: 0x6D,
  SYSREQ: 0xF0,
  ATTN: 0x01,
} as const;

// Field attributes
export const FA = {
  PROTECTED: 0x20,
  NUMERIC: 0x10,
  DISPLAY_MASK: 0x0C,
  DISPLAY_NORMAL: 0x00,
  DISPLAY_INTENSE: 0x08,
  DISPLAY_HIDDEN: 0x0C,
  MDT: 0x01,
} as const;

// EBCDIC → ASCII mapping (CP-037 US)
const EBCDIC_TO_ASCII = new Uint8Array(256);
const ASCII_TO_EBCDIC = new Uint8Array(256);

// Initialize translation tables (CP-037)
(function initTranslationTables() {
  // Fill with space/null defaults
  EBCDIC_TO_ASCII.fill(0x20);
  ASCII_TO_EBCDIC.fill(0x40);

  const map: [number, number][] = [
    // Control chars
    [0x00, 0x00], [0x0D, 0x0D], [0x0A, 0x25], [0x15, 0x0A],
    // Space
    [0x40, 0x20],
    // Special chars
    [0x4B, 0x2E], [0x4C, 0x3C], [0x4D, 0x28], [0x4E, 0x2B],
    [0x4F, 0x7C], [0x50, 0x26], [0x5A, 0x21], [0x5B, 0x24],
    [0x5C, 0x2A], [0x5D, 0x29], [0x5E, 0x3B], [0x5F, 0x5E],
    [0x60, 0x2D], [0x61, 0x2F], [0x6A, 0x7C], [0x6B, 0x2C],
    [0x6C, 0x25], [0x6D, 0x5F], [0x6E, 0x3E], [0x6F, 0x3F],
    [0x79, 0x60], [0x7A, 0x3A], [0x7B, 0x23], [0x7C, 0x40],
    [0x7D, 0x27], [0x7E, 0x3D], [0x7F, 0x22],
    // Lowercase a-i
    [0x81, 0x61], [0x82, 0x62], [0x83, 0x63], [0x84, 0x64],
    [0x85, 0x65], [0x86, 0x66], [0x87, 0x67], [0x88, 0x68],
    [0x89, 0x69],
    // Lowercase j-r
    [0x91, 0x6A], [0x92, 0x6B], [0x93, 0x6C], [0x94, 0x6D],
    [0x95, 0x6E], [0x96, 0x6F], [0x97, 0x70], [0x98, 0x71],
    [0x99, 0x72],
    // Lowercase s-z
    [0xA2, 0x73], [0xA3, 0x74], [0xA4, 0x75], [0xA5, 0x76],
    [0xA6, 0x77], [0xA7, 0x78], [0xA8, 0x79], [0xA9, 0x7A],
    // Uppercase A-I
    [0xC1, 0x41], [0xC2, 0x42], [0xC3, 0x43], [0xC4, 0x44],
    [0xC5, 0x45], [0xC6, 0x46], [0xC7, 0x47], [0xC8, 0x48],
    [0xC9, 0x49],
    // Uppercase J-R
    [0xD1, 0x4A], [0xD2, 0x4B], [0xD3, 0x4C], [0xD4, 0x4D],
    [0xD5, 0x4E], [0xD6, 0x4F], [0xD7, 0x50], [0xD8, 0x51],
    [0xD9, 0x52],
    // Uppercase S-Z
    [0xE2, 0x53], [0xE3, 0x54], [0xE4, 0x55], [0xE5, 0x56],
    [0xE6, 0x57], [0xE7, 0x58], [0xE8, 0x59], [0xE9, 0x5A],
    // Digits 0-9
    [0xF0, 0x30], [0xF1, 0x31], [0xF2, 0x32], [0xF3, 0x33],
    [0xF4, 0x34], [0xF5, 0x35], [0xF6, 0x36], [0xF7, 0x37],
    [0xF8, 0x38], [0xF9, 0x39],
    // Additional specials
    [0xAD, 0x5B], [0xBD, 0x5D], [0xC0, 0x7B], [0xD0, 0x7D],
    [0xA1, 0x7E], [0xE0, 0x5C],
  ];

  for (const [ebcdic, ascii] of map) {
    EBCDIC_TO_ASCII[ebcdic] = ascii;
    ASCII_TO_EBCDIC[ascii] = ebcdic;
  }
})();

// APL/Graphic character set → Unicode mapping (used after GE order)
// IBM 3270 line-drawing characters (EBCDIC graphic escape set)
// Determined by observing: s=horiz, E=UL, N=UR, D=LL, M=LR, e=vert
const GRAPHIC_TO_UNICODE: { [key: number]: string } = {
  0xA2: '─',  // Horizontal line (shows as 's' without GE handling)
  0x85: '│',  // Vertical line (shows as 'e' without GE handling)
  0xC5: '┌',  // Upper-left corner (shows as 'E')
  0xD5: '┐',  // Upper-right corner (shows as 'N')
  0xC4: '└',  // Lower-left corner (shows as 'D')
  0xD4: '┘',  // Lower-right corner (shows as 'M')
  0xC6: '├',  // Left tee
  0xD6: '┤',  // Right tee
  0xC7: '┬',  // Top tee
  0xD7: '┴',  // Bottom tee
  0xD8: '┼',  // Cross/plus
  0xC8: '╔',  // Double upper-left
  0xD9: '╗',  // Double upper-right
  0xCC: '╚',  // Double lower-left
  0xBC: '╝',  // Double lower-right
  0xCD: '═',  // Double horizontal
  0xBA: '║',  // Double vertical
};

/**
 * Convert a graphic escape byte to a Unicode character.
 * Falls back to the regular EBCDIC translation if no graphic mapping exists.
 */
export function graphicToUnicode(byte: number): string {
  if (GRAPHIC_TO_UNICODE[byte]) {
    return GRAPHIC_TO_UNICODE[byte];
  }
  // Fallback: use standard EBCDIC→ASCII  
  const ascii = EBCDIC_TO_ASCII[byte & 0xFF];
  return String.fromCharCode(ascii);
}

export function ebcdicToAscii(byte: number, codePage = 37): number {
  return Ebcdic.toAscii(Buffer.from([byte & 0xFF]), codePage).charCodeAt(0);
}

export function asciiToEbcdic(byte: number): number {
  return ASCII_TO_EBCDIC[byte & 0xFF];
}

export function ebcdicBufferToString(buf: Uint8Array, start: number, length: number): string {
  let result = '';
  for (let i = start; i < start + length && i < buf.length; i++) {
    result += String.fromCharCode(EBCDIC_TO_ASCII[buf[i]]);
  }
  return result;
}

export function stringToEbcdicBuffer(str: string, codePage = 37): Buffer {
  if (codePage !== 37 && codePage !== 500) {
    throw new Error(`Unsupported EBCDIC code page: ${codePage}`);
  }
  return Ebcdic.fromAscii(str, codePage);
}

// 3270 buffer address encoding (12-bit or 14-bit)
export function decodeBufferAddress(b1: number, b2: number): number {
  if ((b1 & 0xC0) === 0x00) {
    // 14-bit address
    return ((b1 & 0x3F) << 8) | b2;
  } else {
    // 12-bit address (6-bit encoding)
    return ((b1 & 0x3F) << 6) | (b2 & 0x3F);
  }
}

export function encodeBufferAddress(addr: number, size: number): [number, number] {
  if (size > 4096) {
    // 14-bit
    return [(addr >> 8) & 0x3F, addr & 0xFF];
  } else {
    // 12-bit (6-bit encoding table)
    const SIX_BIT = [
      0x40, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7,
      0xC8, 0xC9, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,
      0x50, 0xD1, 0xD2, 0xD3, 0xD4, 0xD5, 0xD6, 0xD7,
      0xD8, 0xD9, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F,
      0x60, 0x61, 0xE2, 0xE3, 0xE4, 0xE5, 0xE6, 0xE7,
      0xE8, 0xE9, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F,
      0xF0, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7,
      0xF8, 0xF9, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F,
    ];
    return [SIX_BIT[(addr >> 6) & 0x3F], SIX_BIT[addr & 0x3F]];
  }
}

// Field structure
export interface Field {
  position: number;  // buffer position of the field attribute byte
  attribute: number; // raw attribute byte
  length: number;    // data length (not including attr byte)
  protected: boolean;
  numeric: boolean;
  hidden: boolean;
  intense: boolean;
  modified: boolean;
}

// Screen state
export interface ScreenState {
  rows: number;
  cols: number;
  buffer: Uint8Array;       // raw EBCDIC buffer
  attributes: Uint8Array;   // attribute at each position (0 = data, >0 = field attr)
  graphic: Uint8Array;      // 1 = position uses APL/graphic character set (GE order)
  cursor: number;           // cursor position
  fields: Field[];          // parsed field list
  keyboardLocked: boolean;
  formatted: boolean;       // true if screen has fields
}

// Connection state
export type ConnectionStatus = 'disconnected' | 'connecting' | 'negotiating' | 'connected' | 'error';

export interface ConnectionState {
  status: ConnectionStatus;
  host: string;
  port: number;
  error?: string;
  errorCode?: string;       // Translated error code (e.g. CERT_UNTRUSTED, TLS_VERSION_MISMATCH)
  errorHint?: string;       // Actionable hint for the user
  tn3270e: boolean;         // using TN3270E protocol
  deviceType: string;
  luName?: string;
  tls?: TlsInfo;            // Populated when the socket is TLS
}

export interface TlsInfo {
  enabled: boolean;
  version?: string;         // e.g. 'TLSv1.2'
  cipher?: string;          // e.g. 'ECDHE-RSA-AES256-GCM-SHA384'
  authorized?: boolean;     // Did the peer cert validate?
  authorizationError?: string;
  peerCertificate?: {
    subject?: string;
    issuer?: string;
    validFrom?: string;
    validTo?: string;
    fingerprint?: string;
  };
}

export interface TlsOptions {
  enabled?: boolean;
  minVersion?: 'TLSv1' | 'TLSv1.1' | 'TLSv1.2' | 'TLSv1.3';
  maxVersion?: 'TLSv1.2' | 'TLSv1.3';
  rejectUnauthorized?: boolean;
  caBundle?: string;          // path to PEM
  sni?: string;
  ciphers?: string;
  clientCert?: string;        // path to PEM
  clientKey?: string;         // path to PEM
  passphrase?: string;        // resolved from SecretStorage by the caller
  /**
   * Pinned SHA-256 fingerprint of an acceptable peer certificate, formatted
   * as `AA:BB:CC:...` (uppercase, colon-separated) or `aabbcc...` (any case,
   * no separators). When set, chain validation is bypassed and the connection
   * succeeds only if the peer cert's SHA-256 matches. Mimics what desktop
   * TN3270 clients (Mocha, x3270) do after the user clicks "trust this cert".
   */
  pinnedFingerprint?: string;
}

/**
 * Translate a Node.js TLS/network error into a user-actionable code + hint.
 */
export function translateNetworkError(err: { code?: string; message?: string }): { code: string; hint: string } {
  const code = err.code || '';
  const msg = (err.message || '').toLowerCase();

  // Phase-aware timeouts (raised by connect() itself)
  if (code === 'TCP_CONNECT_TIMEOUT') {
    return {
      code,
      hint: "Host didn't answer the TCP SYN. Wrong port, host down, firewall blocking, or VPN not connected. Verify the port (TN3270 plain=23, TLS=992).",
    };
  }
  if (code === 'TLS_HANDSHAKE_TIMEOUT') {
    return {
      code,
      hint: "TCP connected but TLS handshake never completed. The port likely does NOT speak TLS (try port 23 with TLS off) — or the host requires a specific TLS version. Try the 'Legacy host' preset (TLSv1.0+).",
    };
  }
  if (code === 'TN3270_NEGOTIATION_TIMEOUT') {
    return {
      code,
      hint: "TLS is up, but the host never sent the 3270 login screen. Check the LU name / device type, or ask the host admin whether a specific TN3270E LU is required.",
    };
  }
  if (code === 'TLS_PIN_MISMATCH') {
    return {
      code,
      hint: "The mainframe presented a different certificate than the one you previously trusted. Someone may have re-issued the cert, or this could be a MITM. Re-run 'Diagnose TLS' and, if the new cert is legitimate, click 'Trust this cert' again to update the pin.",
    };
  }

  // TLS-specific
  // Node reports SELF_SIGNED_CERT_IN_CHAIN when a self-signed root sits in
  // the presented chain — the standard shape of a corporate PKI (private
  // root CA). DEPTH_ZERO_SELF_SIGNED_CERT is the rarer case of the leaf
  // itself being self-signed. Both mean "not trusted by the OS store".
  if (code === 'DEPTH_ZERO_SELF_SIGNED_CERT' || code === 'SELF_SIGNED_CERT_IN_CHAIN' ||
      msg.includes('self signed certificate')) {
    return {
      code: 'TLS_SELF_SIGNED',
      hint: "Server uses a self-signed / private-CA certificate. Click 'Trust this cert (pin fingerprint)' in the retry dialog to accept this specific cert (Mocha-equivalent, but bound to this cert only), or import the corporate root CA via tn3270Bridge.tls.caBundle.",
    };
  }
  if (code === 'UNABLE_TO_VERIFY_LEAF_SIGNATURE' || code === 'UNABLE_TO_GET_ISSUER_CERT_LOCALLY' ||
      code === 'UNABLE_TO_GET_ISSUER_CERT' ||
      msg.includes('unable to verify') || msg.includes('unable to get local issuer')) {
    return {
      code: 'TLS_CA_NOT_TRUSTED',
      hint: "Server cert is signed by a CA not in the OS trust store. Add your corporate root CA via tn3270Bridge.tls.caBundle (path to PEM file), or click 'Trust this cert' to pin the fingerprint.",
    };
  }
  if (code === 'CERT_HAS_EXPIRED' || msg.includes('certificate has expired')) {
    return {
      code: 'TLS_CERT_EXPIRED',
      hint: "The server certificate has expired. Ask the host admin to renew it. To bypass for testing, set tn3270Bridge.tls.rejectUnauthorized = false.",
    };
  }
  if (code === 'ERR_TLS_CERT_ALTNAME_INVALID' || msg.includes('hostname/ip does not match')) {
    return {
      code: 'TLS_HOSTNAME_MISMATCH',
      hint: "Server cert is issued for a different hostname. Set tn3270Bridge.tls.sni to the name on the cert, or connect by hostname instead of IP.",
    };
  }
  if (code === 'ERR_SSL_WRONG_VERSION_NUMBER' || msg.includes('wrong version number')) {
    return {
      code: 'TLS_VERSION_MISMATCH',
      hint: "Server is not speaking TLS on this port — or the TLS version is wrong. Verify the port (usually 992 for TLS, 23 for plain), or lower tn3270Bridge.tls.minVersion.",
    };
  }
  if (code === 'ERR_SSL_PROTOCOL_VERSION' || msg.includes('unsupported protocol')) {
    return {
      code: 'TLS_PROTOCOL_UNSUPPORTED',
      hint: "Server only supports a TLS version older than your minVersion. Try tn3270Bridge.tls.minVersion: 'TLSv1.1' or 'TLSv1' (legacy mainframes).",
    };
  }
  if (msg.includes('no cipher') || code === 'ERR_SSL_NO_CIPHER_MATCH') {
    return {
      code: 'TLS_NO_CIPHER_MATCH',
      hint: "No common cipher between client and server. Set tn3270Bridge.tls.ciphers to a list the server accepts (ask your host admin), or upgrade the host.",
    };
  }
  // Network-level
  if (code === 'ECONNREFUSED') {
    return {
      code: 'CONN_REFUSED',
      hint: "Host refused the connection. Check that the host and port are correct (TN3270 plain = 23, TN3270 TLS = 992).",
    };
  }
  if (code === 'ECONNRESET') {
    return {
      code: 'CONN_RESET',
      hint: "Host closed the connection. If using TLS, the host may not speak TLS on this port — try port 992 or disable TLS.",
    };
  }
  if (code === 'ETIMEDOUT') {
    return {
      code: 'CONN_TIMEOUT',
      hint: "Connection timed out. Verify the host is reachable from this network and the port is open. VPN required?",
    };
  }
  if (code === 'ENOTFOUND') {
    return {
      code: 'DNS_NOT_FOUND',
      hint: "Hostname not resolvable. Check spelling and DNS settings.",
    };
  }
  return { code: code || 'UNKNOWN', hint: err.message || 'Unknown error' };
}
