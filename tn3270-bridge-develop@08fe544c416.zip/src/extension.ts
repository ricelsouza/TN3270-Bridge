/**
 * TN3270 Bridge — VS Code Extension Entry Point
 */
import * as vscode from 'vscode';
import { BridgeServer } from './bridge-server';
import { SidebarProvider } from './sidebar-provider';
import { EditorPanelProvider } from './editor-panel-provider';
import { ensureClaudeMcpRegistration } from './claude-mcp-registration';
import type { SavedSession } from './saved-sessions';

export function activate(context: vscode.ExtensionContext): void {
  const server = new BridgeServer(context);
  const sidebar = new SidebarProvider(context, server);

  const mcpServerPath = context.asAbsolutePath('out/mcp-server.js');
  context.subscriptions.push(vscode.lm.registerMcpServerDefinitionProvider(
    'tn3270Bridge.mainframe',
    {
      provideMcpServerDefinitions: () => [
        new vscode.McpStdioServerDefinition(
          'TN3270 Mainframe Bridge',
          process.execPath,
          [mcpServerPath],
          { ELECTRON_RUN_AS_NODE: '1' },
          context.extension.packageJSON.version,
        ),
      ],
    },
  ));

  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider('tn3270Bridge.panel', sidebar, {
      webviewOptions: { retainContextWhenHidden: true },
    })
  );

  // Auto-start
  const cfg = vscode.workspace.getConfiguration('tn3270Bridge');
  if (cfg.get<boolean>('autoStart', true)) {
    server.start();
  }

  const registrationOutput = vscode.window.createOutputChannel('TN3270 Bridge Setup');
  context.subscriptions.push(registrationOutput);
  void ensureClaudeMcpRegistration(context, registrationOutput).catch(error => {
    registrationOutput.appendLine(`[Claude MCP] Automatic registration failed: ${error.message}`);
  });

  // Status bar
  const statusBar = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 99);
  statusBar.command = 'tn3270Bridge.toggleServer';
  updateStatusBar(statusBar, server);
  statusBar.show();
  context.subscriptions.push(statusBar);

  server.onStateChange(() => {
    updateStatusBar(statusBar, server);
    sidebar.refresh();
  });

  // Commands
  context.subscriptions.push(
    vscode.commands.registerCommand('tn3270Bridge.toggleServer', () => {
      server.toggle();
    }),

    vscode.commands.registerCommand('tn3270Bridge.connect', async () => {
      const cfg = vscode.workspace.getConfiguration('tn3270Bridge');
      const defaultHost = cfg.get<string>('defaultHost', '');
      const defaultPort = cfg.get<number>('defaultPort', 23);

      const host = await vscode.window.showInputBox({
        prompt: 'Mainframe hostname or IP',
        value: defaultHost,
        placeHolder: 'mainframe.example.com',
      });
      if (!host) return;

      const portStr = await vscode.window.showInputBox({
        prompt: 'TN3270 port',
        value: String(defaultPort),
        placeHolder: '23 (plain) or 992 (TLS)',
      });
      if (!portStr) return;

      if (!server.state.running) server.start();

      const result = await server.connectTo(host, parseInt(portStr));
      if (result.success) {
        vscode.window.showInformationMessage(`TN3270: Connected to ${host}:${portStr}`);
      } else {
        showConnectionError(result);
      }
    }),

    vscode.commands.registerCommand('tn3270Bridge.connectTls', async () => {
      const cfg = vscode.workspace.getConfiguration('tn3270Bridge');
      const defaultHost = cfg.get<string>('defaultHost', '');

      // Step 1: pick a TLS preset
      const preset = await vscode.window.showQuickPick(
        [
          {
            label: '$(shield) Modern strict',
            description: 'TLS 1.2+, verify server certificate (RECOMMENDED)',
            detail: 'For production hosts with valid certificates from public CAs.',
            id: 'modern',
          },
          {
            label: '$(shield) Corporate CA',
            description: 'TLS 1.2+, verify against a corporate root CA',
            detail: 'You will be asked for the path to your corporate CA PEM file.',
            id: 'corporate',
          },
          {
            label: '$(shield) Legacy compatible',
            description: 'TLS 1.0+, broader cipher list',
            detail: 'For older z/OS LPARs that do not yet speak TLS 1.2.',
            id: 'legacy',
          },
          {
            label: '$(warning) Dev / self-signed',
            description: 'Skip cert verification — INSECURE',
            detail: 'For development/test ONLY. Disables the protection that you are talking to the real host.',
            id: 'dev',
          },
          {
            label: '$(gear) Custom (use my settings)',
            description: 'Use tn3270Bridge.tls.* exactly as configured',
            detail: 'No preset override — settings.json wins.',
            id: 'custom',
          },
        ],
        { placeHolder: 'Choose a TLS preset', ignoreFocusOut: true }
      );
      if (!preset) return;

      // Step 2: host + port
      const host = await vscode.window.showInputBox({
        prompt: 'Mainframe hostname or IP',
        value: defaultHost,
        placeHolder: 'mfssl.example.com',
        ignoreFocusOut: true,
      });
      if (!host) return;

      const portStr = await vscode.window.showInputBox({
        prompt: 'TN3270 TLS port (usually 992)',
        value: '992',
        ignoreFocusOut: true,
      });
      if (!portStr) return;

      // Step 3: extra info per preset
      const tlsOverride: any = { enabled: true };
      if ((preset as any).id === 'modern') {
        tlsOverride.minVersion = 'TLSv1.2';
        tlsOverride.rejectUnauthorized = true;
      } else if ((preset as any).id === 'corporate') {
        const caPath = await vscode.window.showInputBox({
          prompt: 'Path to corporate root CA PEM file',
          placeHolder: 'C:\\certs\\corp-root-ca.pem',
          ignoreFocusOut: true,
        });
        if (!caPath) return;
        tlsOverride.minVersion = 'TLSv1.2';
        tlsOverride.rejectUnauthorized = true;
        tlsOverride.caBundle = caPath;
      } else if ((preset as any).id === 'legacy') {
        tlsOverride.minVersion = 'TLSv1';
        tlsOverride.rejectUnauthorized = true;
      } else if ((preset as any).id === 'dev') {
        const confirm = await vscode.window.showWarningMessage(
          'You are about to connect with TLS but WITHOUT certificate verification. The traffic will be encrypted, but you cannot be sure you are talking to the real host. Continue?',
          { modal: true },
          'Yes, I understand'
        );
        if (confirm !== 'Yes, I understand') return;
        tlsOverride.minVersion = 'TLSv1.2';
        tlsOverride.rejectUnauthorized = false;
      } else if ((preset as any).id === 'custom') {
        // Don't override anything — let settings drive
        delete tlsOverride.minVersion;
        delete tlsOverride.rejectUnauthorized;
      }

      if (!server.state.running) server.start();
      vscode.window.setStatusBarMessage(`$(loading~spin) TN3270: connecting (TLS) to ${host}:${portStr}...`, 5000);
      const result = await server.connectTo(host, parseInt(portStr), undefined, tlsOverride);
      if (result.success) {
        const client = server.getClient();
        const tlsInfo = client?.state.tls;
        vscode.window.showInformationMessage(
          `TN3270: Connected with TLS to ${host}:${portStr} — ${tlsInfo?.version || '?'} / ${tlsInfo?.cipher || '?'}`
        );
      } else {
        showConnectionError(result);
      }
    }),

    vscode.commands.registerCommand('tn3270Bridge.storeTlsPassphrase', async () => {
      const key = await vscode.window.showInputBox({
        prompt: 'Identifier for the passphrase (e.g. "prod-key"). Reference this in tn3270Bridge.tls.passphraseKey.',
        ignoreFocusOut: true,
      });
      if (!key) return;
      const pass = await vscode.window.showInputBox({
        prompt: `Passphrase to store under tn3270.tls.${key}`,
        password: true,
        ignoreFocusOut: true,
      });
      if (!pass) return;
      await context.secrets.store(`tn3270.tls.${key}`, pass);
      vscode.window.showInformationMessage(`TN3270: passphrase stored under "${key}". Set tn3270Bridge.tls.passphraseKey to "${key}" to use it.`);
    }),

    vscode.commands.registerCommand('tn3270Bridge.copyApiToken', async () => {
      await server.copyApiToken();
      vscode.window.showInformationMessage('Legacy REST token copied. MCP and the bundled CLI do not require this step. Treat it as a password and clear the clipboard after use.');
    }),

    vscode.commands.registerCommand('tn3270Bridge.disconnect', () => {
      const client = server.getClient();
      if (client) {
        client.disconnect();
        vscode.window.showInformationMessage('TN3270: Disconnected');
      } else {
        vscode.window.showInformationMessage('TN3270: Not connected');
      }
    }),

    vscode.commands.registerCommand('tn3270Bridge.readScreen', () => {
      const client = server.getClient();
      if (!client || client.state.status !== 'connected') {
        vscode.window.showWarningMessage('TN3270: Not connected');
        return;
      }
      const text = client.getScreenString();
      const doc = vscode.workspace.openTextDocument({ content: text, language: 'plaintext' });
      doc.then(d => vscode.window.showTextDocument(d, { preview: true }));
    }),

    vscode.commands.registerCommand('tn3270Bridge.sendKeys', async () => {
      const client = server.getClient();
      if (!client || client.state.status !== 'connected') {
        vscode.window.showWarningMessage('TN3270: Not connected');
        return;
      }
      const text = await vscode.window.showInputBox({
        prompt: 'Text to send (leave empty for just AID key)',
        placeHolder: 'LOGON TSO',
      });
      const aid = await vscode.window.showQuickPick(
        ['ENTER', 'PF1', 'PF2', 'PF3', 'PF4', 'PF5', 'PF6', 'PF7', 'PF8',
         'PF9', 'PF10', 'PF11', 'PF12', 'PA1', 'PA2', 'CLEAR'],
        { placeHolder: 'Select AID key' }
      );
      if (!aid) return;
      try {
        if (text) await client.sendText(text, aid as any);
        else await client.sendAID(aid as any);
        sidebar.refresh();
      } catch (err: any) {
        vscode.window.showErrorMessage(`TN3270: ${err.message}`);
      }
    }),

    vscode.commands.registerCommand('tn3270Bridge.openInEditor', () => {
      EditorPanelProvider.createOrShow(context, server);
    }),

    vscode.commands.registerCommand('tn3270Bridge.saveRecording', async () => {
      const rec = server.getRecorder();
      if (!rec) {
        vscode.window.showWarningMessage(
          'TN3270: recording is not enabled. Turn on `tn3270Bridge.recording.enabled` in settings and reconnect.'
        );
        return;
      }
      if (rec.frameCount === 0) {
        vscode.window.showInformationMessage('TN3270: recording buffer is empty.');
        return;
      }
      const defaultName = `tn3270-recording-${new Date().toISOString().replace(/[:.]/g, '-')}.jsonl`;
      const target = await vscode.window.showSaveDialog({
        defaultUri: vscode.Uri.file(defaultName),
        filters: { 'JSONL recording': ['jsonl'], 'All files': ['*'] },
        saveLabel: 'Save recording',
      });
      if (!target) return;
      try {
        await rec.saveTo(target);
        const md = rec.metadata();
        vscode.window.showInformationMessage(
          `TN3270: recording saved (${md.frameCount} frames${md.masked ? ', PII-masked' : ''}).`
        );
      } catch (err: any) {
        vscode.window.showErrorMessage(`TN3270: save failed — ${err.message}`);
      }
    }),

    vscode.commands.registerCommand('tn3270Bridge.diagnoseTls', async () => {
      const cfg = vscode.workspace.getConfiguration('tn3270Bridge');
      const defaultHost = cfg.get<string>('defaultHost', '');
      const host = await vscode.window.showInputBox({
        prompt: 'Host to diagnose',
        value: defaultHost,
        placeHolder: 'mainframe.example.com',
        ignoreFocusOut: true,
      });
      if (!host) return;
      const portStr = await vscode.window.showInputBox({
        prompt: 'TLS port',
        value: '992',
        ignoreFocusOut: true,
      });
      if (!portStr) return;
      const port = parseInt(portStr);
      if (!port || Number.isNaN(port)) return;

      const report = await runTlsDiagnose(host, port);
      const doc = await vscode.workspace.openTextDocument({
        content: report,
        language: 'markdown',
      });
      vscode.window.showTextDocument(doc, { preview: true });
    }),

    vscode.commands.registerCommand('tn3270Bridge.pickSession', async () => {
      const list = sidebar.getSessions().loadAll();
      if (list.length === 0) {
        vscode.window.showInformationMessage(
          'TN3270: no saved sessions yet. Open the TN3270 Bridge sidebar, fill in host/port and click 💾 Save.'
        );
        return;
      }
      const picked = await vscode.window.showQuickPick(
        list.map(s => ({
          label: s.name,
          description: `${s.host}:${s.port}${s.tls?.enabled ? ' 🔒 TLS' : ''}`,
          detail: s.lastUsedAt ? `Last used ${formatRelative(s.lastUsedAt)}` : 'Never used',
          session: s,
        })),
        { placeHolder: 'Pick a saved session to connect', matchOnDescription: true }
      );
      if (!picked) return;
      if (!server.state.running) server.start();
      const { session } = picked as any;
      const tlsOverride = sessionToTlsOverride(session);
      const result = await server.connectTo(session.host, session.port, session.luName, tlsOverride);
      if (result.success) {
        await sidebar.getSessions().touchByHostPort(session.host, session.port);
        vscode.window.setStatusBarMessage(`$(plug) TN3270: connected to ${session.name}`, 4000);
      } else {
        showConnectionError(result);
      }
    }),

    vscode.commands.registerCommand('tn3270Bridge.saveCurrentSession', async () => {
      const state = server.state;
      if (!state.connected || !state.host || !state.mainframePort) {
        vscode.window.showWarningMessage('TN3270: connect first, then run this command to save the current session.');
        return;
      }
      const client = server.getClient();
      const tlsInfo = client?.state.tls;
      const name = await vscode.window.showInputBox({
        prompt: 'Name for this saved session',
        value: state.host,
        ignoreFocusOut: true,
        validateInput: v => (v && v.trim().length > 0) ? undefined : 'Name is required',
      });
      if (!name) return;
      const store = sidebar.getSessions();
      const pin = tlsInfo?.enabled ? await context.secrets.get(`tn3270.certpin.${state.host.toLowerCase()}:${state.mainframePort}`) : undefined;
      const saved = await store.save({
        id: '',
        name: name.trim(),
        host: state.host,
        port: state.mainframePort,
        luName: client?.state.luName || undefined,
        tls: tlsInfo?.enabled ? {
          enabled: true,
          preset: 'modern-verified',
          pinnedFingerprint: pin || tlsInfo.peerCertificate?.fingerprint,
        } : undefined,
        createdAt: '',
        lastUsedAt: new Date().toISOString(),
      });
      vscode.window.showInformationMessage(`TN3270: session "${saved.name}" saved.`);
      sidebar.refresh();
    }),

    vscode.commands.registerCommand('tn3270Bridge.manageSessions', async () => {
      const store = sidebar.getSessions();
      const list = store.loadAll();
      if (list.length === 0) {
        vscode.window.showInformationMessage('TN3270: no saved sessions to manage.');
        return;
      }
      const picked = await vscode.window.showQuickPick(
        list.map(s => ({
          label: s.name,
          description: `${s.host}:${s.port}${s.tls?.enabled ? ' 🔒' : ''}`,
          session: s,
        })),
        { placeHolder: 'Pick a saved session' }
      );
      if (!picked) return;
      const { session } = picked as any;
      const action = await vscode.window.showQuickPick(
        ['Connect', 'Rename', 'Delete', 'Duplicate'],
        { placeHolder: `Action for "${session.name}"` }
      );
      if (!action) return;
      if (action === 'Connect') {
        void vscode.commands.executeCommand('tn3270Bridge.pickSession');
      } else if (action === 'Rename') {
        const newName = await vscode.window.showInputBox({ prompt: 'New name', value: session.name });
        if (newName && newName.trim()) {
          await store.save({ ...session, name: newName.trim() });
          sidebar.refresh();
        }
      } else if (action === 'Delete') {
        const confirm = await vscode.window.showWarningMessage(
          `Delete saved session "${session.name}"?`, { modal: true }, 'Delete'
        );
        if (confirm === 'Delete') {
          await store.delete(session.id);
          sidebar.refresh();
        }
      } else if (action === 'Duplicate') {
        const newName = await vscode.window.showInputBox({
          prompt: 'Name for the duplicate',
          value: `${session.name} (copy)`,
        });
        if (newName && newName.trim()) {
          await store.save({ ...session, id: '', name: newName.trim(), createdAt: '', lastUsedAt: undefined });
          sidebar.refresh();
        }
      }
    }),
  );
}

/**
 * Build a TLS override object from a saved session, matching the shape
 * SidebarProvider.buildTlsOverrideAsync produces.
 */
function sessionToTlsOverride(s: SavedSession): any | undefined {
  if (!s.tls?.enabled) return undefined;
  const override: any = { enabled: true };
  switch (s.tls.preset) {
    case 'modern-verified': override.minVersion = 'TLSv1.2'; override.rejectUnauthorized = true; break;
    case 'corporate-ca':    override.minVersion = 'TLSv1.2'; override.rejectUnauthorized = true; break;
    case 'legacy':          override.minVersion = 'TLSv1'; override.rejectUnauthorized = true; break;
    case 'encrypted-only':  override.minVersion = 'TLSv1.2'; override.rejectUnauthorized = false; break;
    case 'custom':          break;
    default:                override.minVersion = 'TLSv1.2'; override.rejectUnauthorized = true;
  }
  if (s.tls.caBundle) override.caBundle = s.tls.caBundle;
  if (s.tls.sni) override.sni = s.tls.sni;
  if (s.tls.pinnedFingerprint) override.pinnedFingerprint = s.tls.pinnedFingerprint;
  return override;
}

function formatRelative(iso: string): string {
  const then = new Date(iso).getTime();
  if (!then) return iso;
  const now = Date.now();
  const s = Math.floor((now - then) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  return `${Math.floor(s / 86400)} d ago`;
}

/**
 * Dial the host with TLS ignoring cert errors, wait a few seconds for the
 * host to send its first bytes, and return a Markdown report. Does not do
 * TN3270 negotiation — the goal is to isolate the TLS layer from higher
 * layers so the user can see exactly what the server is offering.
 */
async function runTlsDiagnose(host: string, port: number): Promise<string> {
  const tls = await import('tls');
  const net = await import('net');
  const startedAt = new Date().toISOString();

  return new Promise<string>((resolve) => {
    const lines: string[] = [];
    const log = (s: string) => lines.push(s);
    log(`# TN3270 TLS diagnose — ${host}:${port}`);
    log('');
    log(`- Started: ${startedAt}`);
    log(`- Node: ${process.version}`);
    log('');

    const hostIsIp = net.isIP(host) !== 0;
    const opts: import('tls').ConnectionOptions = {
      host,
      port,
      rejectUnauthorized: false,
      minVersion: 'TLSv1' as any,
    };
    if (!hostIsIp) opts.servername = host;

    const bytes: Buffer[] = [];
    const t0 = Date.now();
    let phase = 'tcp';
    let finished = false;
    const done = () => {
      if (finished) return;
      finished = true;
      try { sock.destroy(); } catch { /* ignore */ }
      const total = Buffer.concat(bytes);
      log('## Server data captured');
      log('');
      if (total.length === 0) {
        log('_No bytes received in the first 5s after handshake._');
        log('');
        log('That means the host expects the CLIENT to send the first Telnet option — which the extension now does starting in 2.3.0.');
      } else {
        log(`Received ${total.length} bytes:`);
        log('');
        log('```');
        log(total.subarray(0, 256).toString('hex').replace(/(..)/g, '$1 ').trim());
        log('```');
        // Try to decode Telnet IAC negotiations from the first bytes
        if (total[0] === 0xFF) {
          log('');
          log('First byte is `0xFF` (IAC) → server sent Telnet negotiation. Common opcodes:');
          for (let i = 0; i + 2 < total.length && i < 60; i += 3) {
            if (total[i] !== 0xFF) break;
            const verb = { 0xFB: 'WILL', 0xFC: 'WONT', 0xFD: 'DO', 0xFE: 'DONT' }[total[i + 1] as 0xFB | 0xFC | 0xFD | 0xFE] || `?${total[i + 1].toString(16)}`;
            const opt = { 0x00: 'BINARY', 0x18: 'TERMINAL-TYPE', 0x19: 'EOR', 0x28: 'TN3270E' }[total[i + 2] as 0x00 | 0x18 | 0x19 | 0x28] || `?${total[i + 2].toString(16)}`;
            log(`  - IAC ${verb} ${opt}`);
          }
        }
      }
      resolve(lines.join('\n'));
    };

    log('## Handshake');
    log('');
    const sock = tls.connect(opts);
    sock.once('connect', () => { phase = 'tls'; log(`- TCP established after ${Date.now() - t0}ms`); });
    sock.once('secureConnect', () => {
      const cipher = sock.getCipher();
      const cert = sock.getPeerCertificate();
      log(`- TLS handshake OK after ${Date.now() - t0}ms`);
      log(`- Protocol: **${sock.getProtocol() || 'unknown'}**`);
      log(`- Cipher: **${cipher?.name || '?'}** (${cipher?.version || '?'})`);
      log(`- Authorized: ${sock.authorized} ${sock.authorizationError ? `(${sock.authorizationError})` : ''}`);
      log('');
      log('## Certificate');
      log('');
      if (cert && cert.subject) {
        const subj = typeof cert.subject === 'object' ? Object.entries(cert.subject).map(([k, v]) => `${k}=${v}`).join(', ') : String(cert.subject);
        const iss = typeof cert.issuer === 'object' ? Object.entries(cert.issuer).map(([k, v]) => `${k}=${v}`).join(', ') : String(cert.issuer);
        log(`- Subject: \`${subj}\``);
        log(`- Issuer: \`${iss}\``);
        log(`- Valid: ${cert.valid_from} → ${cert.valid_to}`);
        log(`- SHA-256: \`${cert.fingerprint256 || cert.fingerprint || 'n/a'}\``);
        if ((cert as any).subjectaltname) {
          log(`- SAN: \`${(cert as any).subjectaltname}\``);
        }
      } else {
        log('_No peer certificate available._');
      }
      log('');
      // Give the server 5s to send its first bytes without any prompting from us
      setTimeout(done, 5000);
    });
    sock.on('data', (buf: Buffer) => { bytes.push(buf); });
    sock.once('error', (err: any) => {
      log(`- **Error** after ${Date.now() - t0}ms in phase \`${phase}\`: \`${err.code || err.name || 'ERR'}\` — ${err.message}`);
      log('');
      log('## Interpretation');
      log('');
      if (phase === 'tcp') {
        log('TCP connection failed. Wrong port, firewall, or host unreachable.');
      } else if (err.code === 'ERR_SSL_WRONG_VERSION_NUMBER') {
        log('The server is NOT speaking TLS on this port. If Mocha connects on the same port, try disabling TLS in the extension (uncheck the "🔒 Use TLS" checkbox).');
      } else if (err.code === 'ERR_SSL_PROTOCOL_VERSION') {
        log('Server only supports a TLS version below the client minimum. Try the Legacy preset (TLSv1.0+).');
      } else {
        log('Unexpected TLS error. See the error code above.');
      }
      resolve(lines.join('\n'));
    });

    // Overall guard
    setTimeout(() => {
      if (!finished) {
        log(`- **Timeout**: no handshake completion within 10s (phase=${phase}).`);
        log('');
        log('## Interpretation');
        log('');
        if (phase === 'tcp') {
          log('TCP handshake never completed — port silently dropped by firewall, or wrong host/port.');
        } else {
          log('TLS handshake started but never completed. The server accepted the TCP connection but is not responding with ServerHello. This can happen if the port is Telnet-only (not TLS), or the server requires a specific ClientHello parameter.');
        }
        resolve(lines.join('\n'));
        try { sock.destroy(); } catch { /* ignore */ }
      }
    }, 10000);
  });
}

function updateStatusBar(item: vscode.StatusBarItem, server: BridgeServer): void {
  const state = server.state;
  const client = server.getClient();
  const tls = client?.state.tls;

  if (state.connected) {
    const lockIcon = tls?.enabled ? '$(lock)' : '$(unlock)';
    const protoTag = tls?.enabled ? ` [TLS ${tls.version || ''}]`.replace('  ', ' ') : '';
    item.text = `${lockIcon} TN3270: ${state.host}${protoTag}`;
    item.backgroundColor = undefined;
    const certLine = tls?.peerCertificate ? `\nCert: ${tls.peerCertificate.subject} (issued by ${tls.peerCertificate.issuer}, valid to ${tls.peerCertificate.validTo})` : '';
    item.tooltip = `Connected to ${state.host} on bridge :${state.port}${tls?.enabled ? `\nTLS: ${tls.version} / ${tls.cipher}${certLine}` : '\nPlaintext (no encryption)'}`;
  } else if (state.running) {
    item.text = '$(plug) TN3270: Ready';
    item.backgroundColor = undefined;
    item.tooltip = `Bridge running on :${state.port} — Click to connect`;
  } else {
    item.text = '$(debug-disconnect) TN3270: Off';
    item.backgroundColor = new vscode.ThemeColor('statusBarItem.warningBackground');
    item.tooltip = 'Click to start TN3270 bridge';
  }
}

function showConnectionError(result: { error?: string; errorCode?: string; errorHint?: string }): void {
  const code = result.errorCode || 'ERROR';
  const hint = result.errorHint || result.error || 'Unknown error';
  vscode.window.showErrorMessage(`TN3270 [${code}]: ${hint}`, 'Open Settings').then(choice => {
    if (choice === 'Open Settings') {
      vscode.commands.executeCommand('workbench.action.openSettings', '@ext:ricel-leite.tn3270-bridge');
    }
  });
}

export function deactivate(): void {
  // Cleanup handled by disposables
}
