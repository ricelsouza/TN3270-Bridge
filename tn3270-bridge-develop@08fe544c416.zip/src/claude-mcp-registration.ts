import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import * as vscode from 'vscode';

const execFileAsync = promisify(execFile);
const SERVER_NAME = 'tn3270-bridge';
const STATE_KEY = 'tn3270.claudeMcpRegistration';

interface ManagedRegistration {
  runtimePath: string;
  serverPath: string;
  version: string;
}

export function claudeMcpAddArguments(runtimePath: string, serverPath: string): string[] {
  return [
    'mcp', 'add',
    '--scope', 'user',
    '--transport', 'stdio',
    SERVER_NAME,
    '-e', 'ELECTRON_RUN_AS_NODE=1',
    '--',
    runtimePath,
    serverPath,
  ];
}

export async function ensureClaudeMcpRegistration(
  context: vscode.ExtensionContext,
  output: vscode.OutputChannel,
): Promise<void> {
  const serverPath = context.asAbsolutePath('out/mcp-server.js');
  const desired: ManagedRegistration = {
    runtimePath: process.execPath,
    serverPath,
    version: context.extension.packageJSON.version,
  };
  const managed = context.globalState.get<ManagedRegistration>(STATE_KEY);

  try {
    await execFileAsync('claude', ['--version'], { windowsHide: true, timeout: 5000 });
  } catch {
    output.appendLine('[Claude MCP] Claude Code not found; automatic registration skipped.');
    return;
  }

  let exists = false;
  try {
    await execFileAsync('claude', ['mcp', 'get', SERVER_NAME], { windowsHide: true, timeout: 10000 });
    exists = true;
  } catch {
    exists = false;
  }

  if (exists && !managed) {
    output.appendLine('[Claude MCP] Existing unmanaged registration preserved.');
    return;
  }
  if (exists && managed
      && managed.runtimePath === desired.runtimePath
      && managed.serverPath === desired.serverPath
      && managed.version === desired.version) {
    output.appendLine('[Claude MCP] User registration is current.');
    return;
  }

  if (exists && managed) {
    await execFileAsync('claude', ['mcp', 'remove', '--scope', 'user', SERVER_NAME], {
      windowsHide: true,
      timeout: 10000,
    });
  }

  await execFileAsync('claude', claudeMcpAddArguments(desired.runtimePath, desired.serverPath), {
    windowsHide: true,
    timeout: 15000,
  });
  await context.globalState.update(STATE_KEY, desired);
  output.appendLine(`[Claude MCP] Registered ${SERVER_NAME} for all projects.`);
}