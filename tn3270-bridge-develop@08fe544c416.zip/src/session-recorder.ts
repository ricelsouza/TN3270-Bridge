/**
 * Session recording — v2.6.0.
 *
 * When enabled via `tn3270Bridge.recording.enabled`, every screenUpdate
 * emitted by the client is captured as a JSON frame in a bounded in-memory
 * ring buffer. The user can then run `TN3270 Bridge: Save Session Recording`
 * to write the buffer to a JSONL file on disk for audit, incident review,
 * or replay.
 *
 * Recordings are ALWAYS memory-only until explicitly saved. Nothing is
 * written to disk automatically. This matches the enterprise expectation
 * that transcripts must be a deliberate act.
 *
 * PII masking (enabled by default) removes:
 *  - Password fields on well-known 3270 logon panels (`EMSP00`, `TSO`,
 *    `USSMSG10`, LU login) — line containing `Password`/`New Password`/
 *    `PASSWORD` has the value redacted.
 *  - Credit-card-shaped numbers (13-19 digits with optional separators).
 *  - Lines containing `Bearer <token>` or `Authorization: <secret>`.
 * The masking is heuristic — for real regulated PII, disable recording or
 * use it only in air-gapped debug environments.
 */

import * as vscode from 'vscode';
import { promises as fs } from 'fs';

export interface RecordedFrame {
  /** ISO timestamp when the frame was captured. */
  ts: string;
  /** Wall-clock ms since recording start. */
  offsetMs: number;
  /** Detected ISPF/SDSF panel id, if any. */
  panelId: string | null;
  /** Full screen as an array of trimmed lines. */
  lines: string[];
  /** Whether the keyboard was locked when this frame was captured. */
  keyboardLocked: boolean;
  /** Cursor as {row, col} (1-indexed). */
  cursor: { row: number; col: number };
  /** Named session id if not default. */
  sessionId?: string;
}

export interface RecordingMetadata {
  version: '2.6.0';
  startedAt: string;
  stoppedAt: string | null;
  frameCount: number;
  droppedForCapacity: number;
  masked: boolean;
  host?: string;
  port?: number;
}

/**
 * Ring buffer with PII-masking. Not tied to any one session — the caller
 * pushes frames as they arrive. Keeps oldest → newest order; drops from
 * the head when full.
 */
export class SessionRecorder {
  private frames: RecordedFrame[] = [];
  private dropped: number = 0;
  private readonly startedAt: string = new Date().toISOString();
  private startedAtMs: number = Date.now();
  private stoppedAt: string | null = null;

  constructor(
    private readonly maxFrames: number,
    private readonly maskSecrets: boolean,
    private readonly host?: string,
    private readonly port?: number,
  ) {}

  push(input: Omit<RecordedFrame, 'ts' | 'offsetMs'>): void {
    if (this.stoppedAt) return;
    const now = Date.now();
    const frame: RecordedFrame = {
      ts: new Date(now).toISOString(),
      offsetMs: now - this.startedAtMs,
      panelId: input.panelId,
      lines: this.maskSecrets ? maskLines(input.lines) : input.lines.slice(),
      keyboardLocked: input.keyboardLocked,
      cursor: input.cursor,
      sessionId: input.sessionId,
    };
    this.frames.push(frame);
    while (this.frames.length > this.maxFrames) {
      this.frames.shift();
      this.dropped++;
    }
  }

  stop(): void {
    if (!this.stoppedAt) this.stoppedAt = new Date().toISOString();
  }

  get frameCount(): number { return this.frames.length; }
  get isStopped(): boolean { return this.stoppedAt !== null; }

  metadata(): RecordingMetadata {
    return {
      version: '2.6.0',
      startedAt: this.startedAt,
      stoppedAt: this.stoppedAt,
      frameCount: this.frames.length,
      droppedForCapacity: this.dropped,
      masked: this.maskSecrets,
      host: this.host,
      port: this.port,
    };
  }

  /**
   * Serialize the recording to a JSONL string. First line is the metadata,
   * subsequent lines are frames one-per-line. This format streams well and
   * can be tail'd or grep'd without a full JSON parser.
   */
  toJsonl(): string {
    const out: string[] = [];
    out.push(JSON.stringify({ meta: this.metadata() }));
    for (const f of this.frames) out.push(JSON.stringify(f));
    return out.join('\n') + '\n';
  }

  /** Save the recording as a JSONL file. Returns the absolute path. */
  async saveTo(uri: vscode.Uri): Promise<void> {
    await fs.writeFile(uri.fsPath, this.toJsonl(), 'utf8');
  }
}

// ─── PII masking heuristics ────────────────────────────────────────────
const PASSWORD_LABEL = /(password|new password)(\s*\.)*\s*\.?/i;
const CC_LIKE = /\b(?:\d[ -]?){12,18}\d\b/g;
const BEARER = /\b(bearer|authorization)\s*[:=]\s*\S+/gi;

function maskLines(lines: string[]): string[] {
  return lines.map(line => {
    if (PASSWORD_LABEL.test(line)) {
      // Preserve label, redact everything after the last dot separator.
      return line.replace(/([Pp][Aa][Ss][Ss][Ww][Oo][Rr][Dd].*?\.\s*\.?\s*)(\S.*)$/,
        (_m, label, _value) => `${label}[redacted]`);
    }
    let out = line.replace(CC_LIKE, m => '*'.repeat(m.length));
    out = out.replace(BEARER, (m, kw) => `${kw}: [redacted]`);
    return out;
  });
}
