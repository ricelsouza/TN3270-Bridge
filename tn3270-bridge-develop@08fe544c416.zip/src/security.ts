import { timingSafeEqual } from 'node:crypto';

const QUALIFIER = '[A-Z@#$][A-Z0-9@#$-]{0,7}';
const DATASET_PATTERN = new RegExp(`^${QUALIFIER}(\\.${QUALIFIER}){0,21}$`, 'i');
const MEMBER_PATTERN = /^[A-Z@#$][A-Z0-9@#$]{0,7}$/i;

export function validateDatasetReference(
  rawDsn: string,
  rawMember = '',
): { dsn: string; member: string } {
  const dsn = rawDsn.trim().replace(/^'(.*)'$/, '$1').toUpperCase();
  const member = rawMember.trim().toUpperCase();

  if (!DATASET_PATTERN.test(dsn) || dsn.length > 44) {
    throw new Error(`Invalid dataset name: "${rawDsn}"`);
  }
  if (member && !MEMBER_PATTERN.test(member)) {
    throw new Error(`Invalid member name: "${rawMember}"`);
  }
  return { dsn, member };
}

export function apiTokenMatches(provided: string | undefined, expected: string): boolean {
  if (!provided || !expected) return false;
  const providedBytes = Buffer.from(provided);
  const expectedBytes = Buffer.from(expected);
  return providedBytes.length === expectedBytes.length
    && timingSafeEqual(providedBytes, expectedBytes);
}

export function redactSecrets<T>(value: T, secrets: string[]): T {
  const active = secrets.filter(Boolean);
  if (active.length === 0) return value;
  if (typeof value === 'string') {
    return active.reduce((text, secret) => text.split(secret).join('***'), value) as T;
  }
  if (Array.isArray(value)) {
    return value.map(item => redactSecrets(item, active)) as T;
  }
  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value).map(([key, item]) => [key, redactSecrets(item, active)]),
    ) as T;
  }
  return value;
}