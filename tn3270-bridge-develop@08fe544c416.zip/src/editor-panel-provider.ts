/**
 * Editor Panel Provider — Opens 3270 terminal in the main editor area
 * for full-size visualization (larger than the sidebar).
 */
import * as vscode from 'vscode';
import { BridgeServer } from './bridge-server';

export class EditorPanelProvider {
  private static currentPanel: EditorPanelProvider | undefined;
  private static readonly _onVisibilityChange = new vscode.EventEmitter<boolean>();
  /**
   * Fires whenever the editor panel opens or closes. The sidebar subscribes
   * to this so it can toggle between full-interactive and compact modes
   * — see Fix C in Release 2.5.0.
   */
  static readonly onVisibilityChange = EditorPanelProvider._onVisibilityChange.event;

  /** True if the full-size editor panel is currently open. */
  static isOpen(): boolean {
    return !!EditorPanelProvider.currentPanel;
  }

  private readonly panel: vscode.WebviewPanel;
  private refreshTimer?: ReturnType<typeof setInterval>;
  private disposed = false;
  /** Multi-session UI (v2.6.0): which session this panel is currently showing. */
  private activeSessionId: string = 'default';

  static createOrShow(context: vscode.ExtensionContext, server: BridgeServer): void {
    if (EditorPanelProvider.currentPanel) {
      EditorPanelProvider.currentPanel.panel.reveal(vscode.ViewColumn.One);
      return;
    }
    const panel = vscode.window.createWebviewPanel(
      'tn3270Terminal',
      'TN3270 MAINFRAME',
      vscode.ViewColumn.One,
      { enableScripts: true, retainContextWhenHidden: true }
    );
    EditorPanelProvider.currentPanel = new EditorPanelProvider(panel, server);
    context.subscriptions.push(panel);
    EditorPanelProvider._onVisibilityChange.fire(true);
  }

  private constructor(panel: vscode.WebviewPanel, private server: BridgeServer) {
    this.panel = panel;
    this.renderHtml();

    panel.webview.onDidReceiveMessage(async (msg) => {
      switch (msg.command) {
        case 'refresh':
          this.renderHtml();
          break;
        case 'send':
          await this.handleSend(msg);
          break;
        case 'tabField':
          this.handleTab(msg.direction);
          break;
        case 'disconnect':
          this.server.getClientFor(this.activeSessionId)?.disconnect();
          setTimeout(() => this.renderHtml(), 200);
          break;
        case 'setCursor': {
          // Fix B (2.5.0): click on the 3270 screen moves the cursor.
          const c = this.server.getClientFor(this.activeSessionId);
          if (c && typeof msg.row === 'number' && typeof msg.col === 'number') {
            c.setCursor(msg.row, msg.col);
            this.renderHtml();
          }
          break;
        }
        case 'resetKeyboard':
          this.server.getClientFor(this.activeSessionId)?.resetKeyboard();
          this.renderHtml();
          break;
        case 'switchSession': {
          // Multi-session UI (v2.6.0): change which session this panel shows.
          if (typeof msg.sessionId === 'string' && this.server.getClientFor(msg.sessionId)) {
            this.activeSessionId = msg.sessionId;
            this.renderHtml();
          }
          break;
        }
        case 'newSession': {
          // Prompt for host:port and open a new named session.
          const spec = await vscode.window.showInputBox({
            prompt: 'New session — host:port[?tls]  (e.g. mfz900acw2:992?tls or snet1.us.kyndryl.net:23)',
            placeHolder: 'host:port',
            ignoreFocusOut: true,
            validateInput: v => /^[^\s:]+:\d{1,5}(\?tls)?$/.test(v.trim()) ? undefined : 'Format host:port or host:port?tls',
          });
          if (!spec) break;
          const m = spec.trim().match(/^([^\s:]+):(\d{1,5})(\?tls)?$/);
          if (!m) break;
          const host = m[1];
          const port = parseInt(m[2], 10);
          const tls = !!m[3];
          const sid = `s${Date.now().toString(36)}`;
          const client = new (await import('./tn3270-client')).Tn3270Client({
            host, port,
            timeout: 30000,
            codePage: 37,
            tls: tls ? { enabled: true, minVersion: 'TLSv1.2', rejectUnauthorized: false } : undefined,
          });
          try {
            await client.connect();
            (this.server as any).extraSessions.set(sid, {
              client, host, port, model: 'model2',
              connectedAt: new Date().toISOString(),
              sendQueue: Promise.resolve(),
            });
            this.activeSessionId = sid;
            this.renderHtml();
            vscode.window.setStatusBarMessage(`$(plug) TN3270: session ${sid} → ${host}:${port}`, 4000);
          } catch (e: any) {
            vscode.window.showErrorMessage(`TN3270: new session failed — ${e.message || e}`);
          }
          break;
        }
        case 'closeSession': {
          const sid = typeof msg.sessionId === 'string' ? msg.sessionId : '';
          if (!sid || sid === 'default') break;
          const ok = await this.server.closeSession(sid);
          if (ok && this.activeSessionId === sid) this.activeSessionId = 'default';
          if (ok) this.renderHtml();
          break;
        }
      }
    });

    panel.onDidDispose(() => {
      this.disposed = true;
      this.stopAutoRefresh();
      EditorPanelProvider.currentPanel = undefined;
      EditorPanelProvider._onVisibilityChange.fire(false);
    });

    panel.onDidChangeViewState(() => {
      if (panel.visible) {
        this.renderHtml();
        this.startAutoRefresh();
      } else {
        this.stopAutoRefresh();
      }
    });

    this.startAutoRefresh();
  }

  private startAutoRefresh(): void {
    this.stopAutoRefresh();
    this.refreshTimer = setInterval(() => {
      if (!this.disposed && this.panel.visible) this.renderHtml();
    }, 1500);
  }

  private stopAutoRefresh(): void {
    if (this.refreshTimer) { clearInterval(this.refreshTimer); this.refreshTimer = undefined; }
  }

  private async handleSend(msg: any): Promise<void> {
    const client = this.server.getClientFor(this.activeSessionId);
    if (!client || client.state.status !== 'connected') return;
    try {
      if (Array.isArray(msg.fields) && msg.fields.length > 0) {
        for (const entry of msg.fields) {
          if (typeof entry.field === 'number') client.setCursorToField(entry.field);
          else if (entry.row && entry.col) client.setCursor(entry.row, entry.col);
          if (entry.text) client.typeText(entry.text);
        }
        await client.sendAID(msg.aid || 'ENTER');
      } else {
        if (msg.field !== undefined) client.setCursorToField(msg.field);
        else if (msg.row && msg.col) client.setCursor(msg.row, msg.col);
        if (msg.text) await client.sendText(msg.text, msg.aid || 'ENTER');
        else if (msg.aid) await client.sendAID(msg.aid);
      }
    } catch (e: any) { /* ignore */ }
    setTimeout(() => this.renderHtml(), 100);
  }

  private handleTab(direction: number): void {
    const client = this.server.getClientFor(this.activeSessionId);
    if (!client) return;
    const fields = client.getInputFields().filter((f: any) => !f.protected);
    if (fields.length === 0) return;
    const cursor = client.screenState.cursor;
    const cols = client.screenState.cols;
    let currentIdx = 0;
    for (let i = 0; i < fields.length; i++) {
      const fStart = (fields[i].row - 1) * cols + (fields[i].col - 1);
      if (cursor >= fStart && cursor < fStart + fields[i].length) { currentIdx = i; break; }
    }
    const nextIdx = (currentIdx + direction + fields.length) % fields.length;
    client.setCursorToField(fields[nextIdx].index);
    this.renderHtml();
  }

  private renderHtml(): void {
    if (this.disposed) return;
    // If the active session id points to a session that no longer exists
    // (closed elsewhere), fall back to default so the panel doesn't stay
    // stuck on a dead tab.
    if (this.activeSessionId !== 'default' && !this.server.getClientFor(this.activeSessionId)) {
      this.activeSessionId = 'default';
    }
    const client = this.server.getClientFor(this.activeSessionId);
    const connected = !!(client && client.state.status === 'connected');
    if (!connected) {
      this.panel.webview.html = this.buildNotConnectedHtml();
    } else {
      this.panel.webview.html = this.buildTerminalHtml(client!);
    }
  }

  /**
   * Multi-session tab strip (v2.6.0). Rendered at the top of the editor
   * panel — one chip per open session (default + extras). Click switches,
   * X closes (never on default), + opens the new-session prompt.
   */
  private buildTabStripHtml(): string {
    const sessions = this.server.listSessions();
    const ids = Object.keys(sessions);
    const chips = ids.map(id => {
      const s = sessions[id];
      const active = id === this.activeSessionId ? ' active' : '';
      const label = id === 'default' ? 'default' : id;
      const target = s.connected ? `${s.host}:${s.port}` : 'disconnected';
      const closeBtn = id === 'default' ? '' :
        `<span class="tab-close" onclick="event.stopPropagation();cmd('closeSession',{sessionId:${JSON.stringify(id)}})" title="Close session ${esc(id)}">×</span>`;
      return `<div class="tab${active}" onclick="cmd('switchSession',{sessionId:${JSON.stringify(id)}})">
        <span class="tab-dot ${s.connected ? 'on' : 'off'}"></span>
        <span class="tab-label">${esc(label)}</span>
        <span class="tab-target">${esc(target)}</span>
        ${closeBtn}
      </div>`;
    }).join('');
    return `<div class="tab-strip">
      ${chips}
      <div class="tab tab-add" onclick="cmd('newSession')" title="Open a new named session">+</div>
    </div>`;
  }

  private buildNotConnectedHtml(): string {
    return this.wrap(`
      ${this.buildTabStripHtml()}
      <div class="center-msg">
        <div class="icon">🖥️</div>
        <h2>TN3270 Terminal</h2>
        <p class="muted">Session <b>${esc(this.activeSessionId)}</b> is not connected.<br>
        Use the sidebar to connect the default session, or click <b>+</b> above to open a new named session.</p>
      </div>
      <script>
        const vscode = acquireVsCodeApi();
        function cmd(c, d) { vscode.postMessage(Object.assign({command:c}, d||{})); }
      </script>
    `);
  }

  private buildTerminalHtml(client: any): string {
    const state = this.server.state;
    // Fix D (2.6.0): when the session is in OMVS / NVT / SSCP-LU line
    // mode, the fixed 24-row 3270 grid loses information as fast as the
    // shell scrolls. Render a scrollable terminal-mode view instead —
    // shows deep scrollback (up to 40 frames), single input at the bottom,
    // and no click-to-position (irrelevant in line mode). Detection is
    // handled by Tn3270Client.isTerminalMode().
    if (typeof client.isTerminalMode === 'function' && client.isTerminalMode()) {
      return this.buildTerminalModeHtml(client);
    }

    const screen = client.getScreenText();
    const cursor = client.screenState.cursor;
    const cols = client.screenState.cols;
    const cursorRow = Math.floor(cursor / cols) + 1;
    const cursorCol = (cursor % cols) + 1;
    const fields = client.getInputFields();
    const inputFields = fields.filter((f: any) => !f.protected);
    const kbLocked = client.screenState.keyboardLocked;
    const tlsInfo = client.state.tls;
    const tlsOn = !!(tlsInfo && tlsInfo.enabled);
    const secIcon = tlsOn ? '🔒' : '🔓';
    const secLabel = tlsOn
      ? `TLS ${esc(tlsInfo.version || '')} · ${esc(tlsInfo.cipher || '')}`
      : 'Plain TCP';
    const secTitle = tlsOn && tlsInfo.peerCertificate
      ? `Cert: ${tlsInfo.peerCertificate.subject} · issued by ${tlsInfo.peerCertificate.issuer} · valid to ${tlsInfo.peerCertificate.validTo}`
      : (tlsOn ? secLabel : 'Plain TCP — no encryption');

    // Fix B (2.5.0): each line carries data-row so clicking on the screen
    // can compute the column from the click X-offset within the line and
    // send a setCursor(row, col) to the extension. Matches Mocha/PComm/x3270
    // behavior — click where you want to type.
    const screenHtml = screen.map((line: string, i: number) => {
      const row = i + 1;
      if (i === cursorRow - 1) {
        // Split BEFORE escaping so positions match the original buffer
        const before = esc(line.substring(0, cursorCol - 1));
        const ch = esc(line.substring(cursorCol - 1, cursorCol) || ' ');
        const after = esc(line.substring(cursorCol));
        return `<div class="line" data-row="${row}">${before}<span class="cursor">${ch}</span>${after}</div>`;
      }
      return `<div class="line" data-row="${row}">${esc(line)}</div>`;
    }).join('');

    return this.wrap(`
      ${this.buildTabStripHtml()}
      <div class="header">
        <span class="dot connected"></span>
        <span class="host">${esc(client.state.host || state.host || '?')}:${client.state.port || state.mainframePort || '?'}</span>
        <span class="sec-badge ${tlsOn ? 'sec-tls' : 'sec-plain'}" title="${esc(secTitle)}">${secIcon} ${esc(secLabel)}</span>
        <span class="status ${kbLocked ? 'warn' : 'ok'}">${kbLocked ? '🔒 LOCKED' : '✓ Ready'}</span>
        <span class="pos">R${cursorRow} C${cursorCol} | Fields: ${fields.length}</span>
        <button class="btn-icon" onclick="cmd('disconnect')" title="Disconnect">✕</button>
      </div>

      <div class="screen" id="screen" onclick="handleScreenClick(event)" title="Click to position the 3270 cursor">${screenHtml}</div>

      <!-- Text input area -->
      <div class="input-area">
        <input type="text" id="textInput" placeholder="Type text here, then press Enter or a PF key..."
               onkeydown="handleKey(event)" autocomplete="off" spellcheck="false" />
      </div>

      <!-- AID Keys -->
      <div class="aid-keys">
        <button class="aid enter" onclick="sendWithText('ENTER')">⏎ Enter</button>
        <button class="aid" onclick="sendWithText('PF1')">F1</button>
        <button class="aid" onclick="sendWithText('PF2')">F2</button>
        <button class="aid highlight" onclick="sendWithText('PF3')">F3</button>
        <button class="aid" onclick="sendWithText('PF4')">F4</button>
        <button class="aid" onclick="sendWithText('PF5')">F5</button>
        <button class="aid" onclick="sendWithText('PF6')">F6</button>
        <button class="aid highlight" onclick="sendWithText('PF7')">F7↑</button>
        <button class="aid highlight" onclick="sendWithText('PF8')">F8↓</button>
        <button class="aid" onclick="sendWithText('PF9')">F9</button>
        <button class="aid" onclick="sendWithText('PF10')">F10</button>
        <button class="aid" onclick="sendWithText('PF11')">F11</button>
        <button class="aid" onclick="sendWithText('PF12')">F12</button>
        <button class="aid special" onclick="sendWithText('CLEAR')">Clear</button>
        <button class="aid special" onclick="sendWithText('PA1')">PA1</button>
        <button class="aid special" onclick="sendWithText('PA2')">PA2</button>
      </div>

      <script>
        const vscode = acquireVsCodeApi();
        function cmd(c, d) { vscode.postMessage(Object.assign({command:c}, d||{})); }

        // Fix B (2.5.0): click anywhere on the 3270 screen to move the
        // cursor there. Column is computed from the click X-offset within
        // the line's bounding box, divided by the average character width.
        // Uses a per-line rect + textContent length so it works with any
        // font size the user has configured for the editor.
        function handleScreenClick(e) {
          const line = e.target.closest('div.line');
          if (!line || !line.dataset.row) return;
          const row = parseInt(line.dataset.row, 10);
          const len = Math.max(1, line.textContent.length);
          const rect = line.getBoundingClientRect();
          const x = e.clientX - rect.left;
          const charWidth = rect.width / len;
          let col = Math.floor(x / charWidth) + 1;
          if (col < 1) col = 1;
          if (col > len) col = len;
          cmd('setCursor', { row, col });
          // Auto-focus the typing input after positioning so the user's
          // next keystroke lands on the mainframe field they picked.
          setTimeout(() => document.getElementById('textInput')?.focus(), 0);
        }

        function sendWithText(aid) {
          const input = document.getElementById('textInput');
          const text = input.value;
          input.value = '';
          cmd('send', { text: text || undefined, aid });
        }

        function handleKey(e) {
          if (e.key === 'Enter') { e.preventDefault(); sendWithText('ENTER'); }
          else if (e.key === 'Tab') { e.preventDefault(); cmd('tabField', {direction: e.shiftKey ? -1 : 1}); }
          else if (e.key === 'Escape') { e.preventDefault(); sendWithText('CLEAR'); }
          else if (e.key.match(/^F(\\d+)$/)) {
            e.preventDefault();
            const n = parseInt(e.key.substring(1));
            if (n >= 1 && n <= 12) sendWithText('PF' + n);
          }
        }

        function focusField(idx) {
          const input = document.getElementById('textInput');
          input.focus();
          cmd('send', { field: idx });
        }

        // Focus-preserving re-render (v2.5.0). See sidebar-provider.ts for
        // the full rationale. Never steal focus on a plain auto-refresh —
        // only restore if user was previously typing here.
        (function restoreFocus() {
          const st = vscode.getState() || {};
          if (st.wasTyping) {
            const input = document.getElementById('textInput');
            if (input && input.value === '') {
              if (!document.activeElement || document.activeElement === document.body) {
                input.focus();
              }
            }
          }
        })();
        (function trackFocus() {
          const input = document.getElementById('textInput');
          if (!input) return;
          input.addEventListener('focus', () => vscode.setState({ ...(vscode.getState()||{}), wasTyping: true }));
          input.addEventListener('blur',  () => vscode.setState({ ...(vscode.getState()||{}), wasTyping: false }));
        })();
      </script>
    `);
  }

  /**
   * Fix D (v2.6.0): OMVS / NVT / SSCP-LU terminal-mode renderer.
   * Shows a scrollable pre with the full screen-history flow, a single
   * command line at the bottom, and NO click-to-position (irrelevant for
   * line-mode). The auto-refresh keeps the pre pinned to bottom whenever
   * new content arrives (like a tail -f).
   */
  private buildTerminalModeHtml(client: any): string {
    const state = this.server.state;
    const scrollback: string[] = typeof client.getTerminalScrollback === 'function'
      ? client.getTerminalScrollback(400)
      : client.getScreenText();
    const kbLocked = client.screenState.keyboardLocked;
    const panelId = client.detectPanelId() || 'terminal';
    const tlsInfo = client.state.tls;
    const tlsOn = !!(tlsInfo && tlsInfo.enabled);

    const html = scrollback.map((l: string) => `<div class="tline">${esc(l) || '&nbsp;'}</div>`).join('');

    return this.wrap(`
      ${this.buildTabStripHtml()}
      <div class="header">
        <span class="dot connected"></span>
        <span class="host">${esc(client.state.host || state.host || '?')}:${client.state.port || state.mainframePort || '?'}</span>
        <span class="sec-badge ${tlsOn ? 'sec-tls' : 'sec-plain'}">${tlsOn ? '🔒 TLS' : '🔓 PLAIN'}</span>
        <span class="status ${kbLocked ? 'warn' : 'ok'}">${kbLocked ? '🔒 LOCKED' : '✓ ' + esc(panelId)}</span>
        <span class="pos">Terminal mode · ${scrollback.length} lines</span>
        <button class="btn-icon" onclick="cmd('disconnect')" title="Disconnect">✕</button>
      </div>

      <div class="terminal-scrollback" id="scrollback">${html}</div>

      <div class="input-area">
        <input type="text" id="textInput"
               placeholder="Type command, Enter to send. F3=END, F7/F8 to scroll host paging..."
               onkeydown="handleKey(event)" autocomplete="off" spellcheck="false" />
      </div>

      <div class="aid-keys">
        <button class="aid enter" onclick="sendWithText('ENTER')">⏎ Enter</button>
        <button class="aid highlight" onclick="sendWithText('PF3')">F3 End</button>
        <button class="aid highlight" onclick="sendWithText('PF7')">F7 ↑</button>
        <button class="aid highlight" onclick="sendWithText('PF8')">F8 ↓</button>
        <button class="aid special" onclick="sendWithText('CLEAR')">Clear</button>
        <button class="aid reset" onclick="cmd('resetKeyboard')" title="Local RESET (3270 RESET key)">⏮ RESET</button>
      </div>

      <script>
        const vscode = acquireVsCodeApi();
        function cmd(c, d) { vscode.postMessage(Object.assign({command:c}, d||{})); }

        function sendWithText(aid) {
          const input = document.getElementById('textInput');
          const text = input.value;
          input.value = '';
          cmd('send', { text: text || undefined, aid });
        }
        function handleKey(e) {
          if (e.key === 'Enter') { e.preventDefault(); sendWithText('ENTER'); }
          else if (e.key === 'Escape') { e.preventDefault(); sendWithText('CLEAR'); }
          else if (e.key.match(/^F(\\d+)$/)) {
            e.preventDefault();
            const n = parseInt(e.key.substring(1));
            if (n >= 1 && n <= 12) sendWithText('PF' + n);
          }
        }

        // Auto-scroll to bottom on new content so the pre behaves like a live tail.
        const sb = document.getElementById('scrollback');
        if (sb) sb.scrollTop = sb.scrollHeight;

        // Focus-preserving re-render (v2.5.0 Fix A).
        (function restoreFocus() {
          const st = vscode.getState() || {};
          if (st.wasTyping) {
            const input = document.getElementById('textInput');
            if (input && input.value === '' &&
                (!document.activeElement || document.activeElement === document.body)) {
              input.focus();
            }
          }
        })();
        (function trackFocus() {
          const input = document.getElementById('textInput');
          if (!input) return;
          input.addEventListener('focus', () => vscode.setState({ ...(vscode.getState()||{}), wasTyping: true }));
          input.addEventListener('blur',  () => vscode.setState({ ...(vscode.getState()||{}), wasTyping: false }));
        })();
      </script>
    `);
  }

  private wrap(content: string): string {
    return `<!DOCTYPE html><html><head><style>
* { box-sizing: border-box; }
body { font-family: var(--vscode-font-family); padding: 16px; margin: 0; color: var(--vscode-foreground); font-size: 13px; }
.center-msg { text-align: center; padding-top: 60px; }
.center-msg .icon { font-size: 48px; margin-bottom: 16px; }
.muted { color: var(--vscode-descriptionForeground); margin: 8px 0; }

/* Header */
.header { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; padding: 6px 12px; background: #1a1a2e; border-radius: 6px; }
.dot { width: 10px; height: 10px; border-radius: 50%; }
.dot.connected { background: #4ec9b0; }
.host { font-weight: 600; font-size: 13px; }
.status { font-size: 11px; }
.status.warn { color: #f55; }
.status.ok { color: #4ec9b0; }
.pos { font-size: 11px; color: #888; margin-left: auto; }
.sec-badge { font-size: 11px; padding: 2px 8px; border-radius: 10px; font-weight: 600; }
.sec-tls   { background: #1a4a3a; color: #4ec9b0; border: 1px solid #4ec9b0; }
.sec-plain { background: #3a2a2a; color: #f88; border: 1px solid #844; }
.btn-icon { background: none; border: none; color: #888; cursor: pointer; padding: 4px 8px; border-radius: 4px; font-size: 14px; }
.btn-icon:hover { background: var(--vscode-toolbar-hoverBackground); color: var(--vscode-foreground); }

/* Screen - FULL SIZE for editor area */
.screen {
  font-family: 'Cascadia Mono', 'Courier New', monospace;
  font-size: 14px; line-height: 1.3;
  background: #0a0a1a; color: #00ff41;
  padding: 12px 16px; border-radius: 6px;
  overflow-x: auto; white-space: pre;
  border: 1px solid #2a2a3e;
  min-height: 460px;
  cursor: text;  /* click-to-position (Fix B, v2.5.0) */
}
.line { height: 18px; }
.line:hover { background: rgba(0, 255, 65, 0.04); }
.cursor { background: #00ff41; color: #0a0a1a; }

/* Input area */
.input-area { margin: 12px 0 8px; }
.input-area input {
  width: 100%; padding: 10px 14px; border-radius: 6px; font-size: 14px;
  font-family: 'Cascadia Mono', 'Courier New', monospace;
  background: var(--vscode-input-background); color: #00ff41;
  border: 1px solid var(--vscode-input-border, #444);
}
.input-area input:focus { border-color: #00ff41; outline: none; }
.input-area input::placeholder { color: #555; }

/* AID Keys */
.aid-keys { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 12px; }

/* Multi-session tab strip — v2.6.0 */
.tab-strip { display: flex; gap: 4px; margin-bottom: 8px; padding-bottom: 6px; border-bottom: 1px solid var(--vscode-widget-border, #333); flex-wrap: wrap; }
.tab {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 4px 10px; border-radius: 6px;
  background: #1a1a2e; color: #ccc; border: 1px solid #333;
  cursor: pointer; font-size: 11px; min-width: 100px; user-select: none;
}
.tab:hover { background: #24243e; }
.tab.active { background: #1a4a3a; border-color: #4ec9b0; color: #fff; }
.tab-dot { width: 6px; height: 6px; border-radius: 50%; }
.tab-dot.on { background: #4ec9b0; }
.tab-dot.off { background: #666; }
.tab-label { font-weight: 600; }
.tab-target { color: #888; font-size: 10px; }
.tab-close { margin-left: 6px; color: #f88; font-weight: bold; padding: 0 4px; border-radius: 3px; }
.tab-close:hover { background: rgba(255,120,120,0.15); }
.tab.tab-add { color: #4ec9b0; font-weight: bold; min-width: 30px; justify-content: center; }

/* Terminal-mode (OMVS/NVT) scrollback view — Fix D, v2.6.0 */
.terminal-scrollback {
  font-family: 'Cascadia Mono', 'Courier New', monospace;
  font-size: 13px; line-height: 1.35;
  background: #0a0a1a; color: #00ff41;
  padding: 12px 16px; border-radius: 6px;
  border: 1px solid #2a2a3e;
  height: 62vh; overflow-y: auto; overflow-x: auto;
  white-space: pre;
}
.tline { min-height: 17px; }
.aid.reset { background: #2a3a2a; color: #7c7; border: 1px solid #494; padding: 6px 10px; border-radius: 4px; cursor: pointer; font-size: 12px; }
.aid.reset:hover { background: #3a4a3a; }
.aid { background: #2a2a3e; color: #ccc; border: 1px solid #444; padding: 6px 10px; border-radius: 4px; cursor: pointer; font-size: 12px; min-width: 36px; text-align: center; }
.aid:hover { background: #3a3a5e; border-color: #666; }
.aid.enter { background: #1a4a3a; color: #4ec9b0; border-color: #4ec9b0; font-weight: bold; min-width: 80px; }
.aid.enter:hover { background: #2a5a4a; }
.aid.highlight { background: #2a3a5e; color: #6af; border-color: #4a7acc; }
.aid.highlight:hover { background: #3a4a6e; }
.aid.special { background: #3a2a2a; color: #f88; border-color: #844; }
.aid.special:hover { background: #4a3a3a; }
</style></head><body>${content}</body></html>`;
  }
}

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
