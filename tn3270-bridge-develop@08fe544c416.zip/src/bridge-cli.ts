import { BridgeApiClient } from './bridge-api-client';

async function readStdin(): Promise<string> {
  const chunks: Buffer[] = [];
  for await (const chunk of process.stdin) chunks.push(Buffer.from(chunk));
  return Buffer.concat(chunks).toString('utf8').trim();
}

async function main(): Promise<void> {
  const [method = 'GET', path = '/status', jsonBody] = process.argv.slice(2);
  if (!path.startsWith('/')) throw new Error('Path must start with /');
  // Auto-discover when no explicit URL is set. Prefer a bridge that is
  // already connected to a mainframe so batch scripts and Copilot/Claude
  // MCP calls land on the right VS Code window without configuration.
  const baseUrl = process.env.TN3270_BRIDGE_URL;
  const client = baseUrl
    ? await BridgeApiClient.connect(baseUrl)
    : await BridgeApiClient.discover();
  const body = jsonBody === '-' ? await readStdin() : jsonBody;
  const result = method.toUpperCase() === 'GET'
    ? await client.get(path)
    : await client.request(path, {
      method: method.toUpperCase(),
      body: body || '{}',
    });
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
}

main().catch(error => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
});