import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';
import { BridgeApiClient } from './bridge-api-client';
import { validateDatasetReference } from './security';

// Auto-discover the bridge port. If TN3270_BRIDGE_URL is set, honor it
// (used by tests + power users who want deterministic wiring). Otherwise
// scan 127.0.0.1:7327-7335 for a live bridge and prefer one already
// connected to a mainframe — matches the "Claude/Copilot should just find
// the running extension" expectation regardless of how many VS Code
// windows are open or which port the bridge happened to land on.
const baseUrl = process.env.TN3270_BRIDGE_URL;
const clientPromise = baseUrl
  ? BridgeApiClient.connect(baseUrl)
  : BridgeApiClient.discover();
const server = new McpServer({ name: 'tn3270-bridge', version: '2.6.0' });

async function get(path: string): Promise<unknown> {
  return (await clientPromise).get(path);
}

async function post(path: string, body: unknown = {}): Promise<unknown> {
  return (await clientPromise).post(path, body);
}

function toolResult(value: unknown) {
  return { content: [{ type: 'text' as const, text: JSON.stringify(value, null, 2) }] };
}

function sessionQuery(session?: string): string {
  return session ? `?session=${encodeURIComponent(session)}` : '';
}

server.registerTool('mainframe_status', {
  description: 'Read bridge, connection, screen model, panel and keyboard status.',
  inputSchema: {},
  annotations: { readOnlyHint: true, destructiveHint: false },
}, async () => toolResult(await get('/status')));

server.registerTool('mainframe_read_screen', {
  description: 'Read the current 3270 screen. Hidden fields are always masked.',
  inputSchema: {
    session: z.string().optional(),
    nonblank: z.boolean().default(true),
  },
  annotations: { readOnlyHint: true, destructiveHint: false },
}, async ({ session, nonblank }) => {
  const query = new URLSearchParams();
  if (session) query.set('session', session);
  query.set('nonblank', String(nonblank));
  return toolResult(await get(`/screen?${query}`));
});

server.registerTool('mainframe_fields', {
  description: 'Read formatted 3270 fields, including positions, lengths, protection, and hidden flags. Hidden field content remains masked.',
  inputSchema: { session: z.string().optional() },
  annotations: { readOnlyHint: true, destructiveHint: false },
}, async ({ session }) => toolResult(await get(`/screen/fields${sessionQuery(session)}`)));

server.registerTool('mainframe_find', {
  description: 'Find case-insensitive text on the current screen and return its row and column.',
  inputSchema: { session: z.string().optional(), text: z.string().min(1) },
  annotations: { readOnlyHint: true, destructiveHint: false },
}, async ({ session, text }) => {
  const query = new URLSearchParams({ text });
  if (session) query.set('session', session);
  return toolResult(await get(`/screen/find?${query}`));
});

server.registerTool('mainframe_table', {
  description: 'Parse the current columnar 3270 screen into structured headers and rows.',
  inputSchema: {
    session: z.string().optional(),
    headerRow: z.number().int().positive().optional(),
  },
  annotations: { readOnlyHint: true, destructiveHint: false },
}, async ({ session, headerRow }) => {
  const query = new URLSearchParams();
  if (session) query.set('session', session);
  if (headerRow) query.set('headerRow', String(headerRow));
  return toolResult(await get(`/screen/table?${query}`));
});

server.registerTool('mainframe_extract', {
  description:
    'Structured extraction from the current 3270 screen. Modes:\n' +
    ' - "regex": apply a JS regex, returns matches with capture groups + row/col.\n' +
    ' - "labels": find a label and return the value that follows it on the same line (ISPF `Name . . . value` shape).\n' +
    ' - "anchor": return lines strictly between a start anchor and an end anchor.\n' +
    'Cheaper than reading the whole screen and parsing it in the agent. Read-only.',
  inputSchema: {
    session: z.string().optional(),
    mode: z.enum(['regex', 'labels', 'anchor']),
    pattern: z.string().min(1),
    endPattern: z.string().optional(),
    flags: z.string().optional(),
    maxMatches: z.number().int().min(1).max(500).optional(),
    valueMaxLen: z.number().int().min(1).max(200).optional(),
    valueStopChars: z.string().optional(),
  },
  annotations: { readOnlyHint: true, destructiveHint: false },
}, async ({ session, ...body }) => toolResult(await post(`/screen/extract${sessionQuery(session)}`, body)));

server.registerTool('mainframe_history', {
  description: 'Read up to ten recent masked screen snapshots for navigation diagnosis.',
  inputSchema: {
    session: z.string().optional(),
    last: z.number().int().min(1).max(10).default(5),
  },
  annotations: { readOnlyHint: true, destructiveHint: false },
}, async ({ session, last }) => {
  const query = new URLSearchParams({ last: String(last) });
  if (session) query.set('session', session);
  return toolResult(await get(`/screen/history?${query}`));
});

server.registerTool('mainframe_read_all', {
  description: 'Scroll through a multi-page host display and return accumulated lines with an explicit stop reason.',
  inputSchema: {
    session: z.string().optional(),
    scrollKey: z.string().default('PF8'),
    stopText: z.string().default('BOTTOM OF DATA'),
    maxPages: z.number().int().min(1).max(500).default(200),
    timeout: z.number().int().min(1).max(120000).default(30000),
    skipHeaderRows: z.number().int().min(0).max(10).default(0),
  },
  annotations: { readOnlyHint: false, destructiveHint: false },
}, async ({ session, ...body }) => toolResult(await post(`/screen/readall${sessionQuery(session)}`, body)));

server.registerTool('mainframe_cursor', {
  description: 'Move the local 3270 cursor without pressing an AID key. Use before typing into unformatted SDSF, ISPF Edit, or OMVS fields.',
  inputSchema: {
    session: z.string().optional(),
    row: z.number().int().positive().optional(),
    col: z.number().int().positive().optional(),
    field: z.number().int().min(0).optional(),
    fieldName: z.string().optional(),
    labelLeft: z.string().optional(),
    labelAbove: z.string().optional(),
  },
  annotations: { readOnlyHint: false, destructiveHint: false },
}, async ({ session, ...body }) => toolResult(await post(`/cursor${sessionQuery(session)}`, body)));

server.registerTool('mainframe_send', {
  description: 'Type text into a resolved 3270 field and press an AID key. Verify the returned panel and messages before the next action.',
  inputSchema: {
    session: z.string().optional(),
    text: z.string().optional(),
    aid: z.string().default('ENTER'),
    fieldName: z.string().optional(),
    labelLeft: z.string().optional(),
    labelAbove: z.string().optional(),
    row: z.number().int().positive().optional(),
    col: z.number().int().positive().optional(),
    clearField: z.boolean().default(true),
  },
  annotations: { readOnlyHint: false, destructiveHint: true },
}, async ({ session, ...body }) => toolResult(await post(`/send${sessionQuery(session)}`, body)));

server.registerTool('mainframe_wait', {
  description: 'Wait for screen text, a panel ID, keyboard unlock, or screen change without using sleeps.',
  inputSchema: {
    session: z.string().optional(),
    type: z.enum(['text', 'panel', 'keyboardUnlock', 'screenChange']).default('text'),
    text: z.string().optional(),
    panelId: z.string().optional(),
    timeout: z.number().int().min(1).max(120000).default(10000),
  },
  annotations: { readOnlyHint: true, destructiveHint: false },
}, async ({ session, ...body }) => toolResult(await post(`/wait${sessionQuery(session)}`, body)));

server.registerTool('mainframe_exec', {
  description: 'Execute an ordered sequence of send and wait steps on one serialized session.',
  inputSchema: {
    session: z.string().optional(),
    steps: z.array(z.record(z.string(), z.unknown())).min(1).max(100),
    stopOnError: z.boolean().default(true),
  },
  annotations: { readOnlyHint: false, destructiveHint: true },
}, async ({ session, ...body }) => toolResult(await post(`/exec${sessionQuery(session)}`, body)));

server.registerTool('mainframe_read_dataset', {
  description: 'Read a sequential dataset or PDS member through ISPF View and restore the prior panel.',
  inputSchema: {
    session: z.string().optional(),
    dsn: z.string().min(1),
    member: z.string().optional(),
  },
  annotations: { readOnlyHint: true, destructiveHint: false },
}, async ({ session, dsn, member }) => {
  const query = new URLSearchParams({ dsn });
  if (member) query.set('member', member);
  if (session) query.set('session', session);
  return toolResult(await get(`/file/get?${query}`));
});

server.registerTool('mainframe_write_dataset', {
  description: 'Replace a sequential dataset or PDS member through ISPF Edit. Incomplete writes are cancelled before SAVE.',
  inputSchema: {
    session: z.string().optional(),
    dsn: z.string().min(1),
    member: z.string().optional(),
    content: z.union([z.string(), z.array(z.string())]),
  },
  annotations: { readOnlyHint: false, destructiveHint: true },
}, async ({ session, ...body }) => toolResult(await post(`/file/put${sessionQuery(session)}`, body)));

server.registerTool('mainframe_sessions', {
  description: 'List default and named TN3270 sessions.',
  inputSchema: {},
  annotations: { readOnlyHint: true, destructiveHint: false },
}, async () => toolResult(await get('/sessions')));

server.registerTool('mainframe_session_create', {
  description: 'Create an additional named TN3270 session without replacing the default session.',
  inputSchema: {
    host: z.string().min(1),
    port: z.number().int().min(1).max(65535).default(23),
    sessionId: z.string().regex(/^[A-Za-z0-9_-]+$/).optional(),
    luName: z.string().optional(),
    model: z.enum(['model2', 'model3', 'model4', 'model5']).default('model2'),
    tls: z.boolean().optional(),
  },
  annotations: { readOnlyHint: false, destructiveHint: false },
}, async body => toolResult(await post('/session', body)));

server.registerTool('mainframe_session_delete', {
  description: 'Disconnect and remove a named TN3270 session. The default session requires an explicit sessionId of default.',
  inputSchema: { sessionId: z.string().min(1) },
  annotations: { readOnlyHint: false, destructiveHint: false },
}, async ({ sessionId }) => toolResult(await (await clientPromise).delete(`/session/${encodeURIComponent(sessionId)}`)));

server.registerTool('mainframe_connect', {
  description: 'Connect or replace the default TN3270 session using explicit host parameters.',
  inputSchema: {
    host: z.string().min(1),
    port: z.number().int().min(1).max(65535).default(23),
    luName: z.string().optional(),
    model: z.enum(['model2', 'model3', 'model4', 'model5']).optional(),
    tls: z.boolean().optional(),
  },
  annotations: { readOnlyHint: false, destructiveHint: false },
}, async body => toolResult(await post('/connect', body)));

server.registerTool('mainframe_disconnect', {
  description: 'Disconnect a TN3270 session without changing host datasets or jobs.',
  inputSchema: { session: z.string().optional() },
  annotations: { readOnlyHint: false, destructiveHint: false },
}, async ({ session }) => toolResult(await post(`/disconnect${sessionQuery(session)}`, {})));

server.registerTool('mainframe_login', {
  description: 'Run a configured login profile. Passwords are read by the extension from VS Code SecretStorage and never enter the MCP conversation.',
  inputSchema: {
    profile: z.string().min(1),
    userid: z.string().min(1),
  },
  annotations: { readOnlyHint: false, destructiveHint: false },
}, async body => toolResult(await post('/login', body)));

server.registerTool('mainframe_interrupt', {
  description: 'Send Telnet Interrupt Process to break a hung TSO command. Use only after confirming the keyboard remains locked.',
  inputSchema: { session: z.string().optional() },
  annotations: { readOnlyHint: false, destructiveHint: true },
}, async ({ session }) => toolResult(await post(`/attn${sessionQuery(session)}`)));

server.registerTool('mainframe_submit_job', {
  description: 'Submit an existing JCL dataset or member with TSO SUBMIT from an ISPF command field. Returns the resulting screen for job ID verification.',
  inputSchema: {
    session: z.string().optional(),
    dsn: z.string().min(1),
    member: z.string().optional(),
  },
  annotations: { readOnlyHint: false, destructiveHint: true },
}, async ({ session, dsn: rawDsn, member: rawMember }) => {
  const { dsn, member } = validateDatasetReference(rawDsn, rawMember);
  const reference = member ? `${dsn}(${member})` : dsn;
  return toolResult(await post(`/send${sessionQuery(session)}`, {
    fieldName: 'COMMAND',
    text: `TSO SUBMIT '${reference}'`,
    aid: 'ENTER',
    clearField: true,
    waitTimeout: 30000,
  }));
});

async function main(): Promise<void> {
  await server.connect(new StdioServerTransport());
}

main().catch(error => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
});