/**
 * Sidebar WebView Provider — Rich visual 3270 terminal UI
 * Everything is clickable/visual — no commands to remember
 */
import * as vscode from 'vscode';
import { BridgeServer } from './bridge-server';
import { SavedSessionsStore, SavedSession, TlsPreset, ScreenModel } from './saved-sessions';
import { EditorPanelProvider } from './editor-panel-provider';

export class SidebarProvider implements vscode.WebviewViewProvider {
  private view?: vscode.WebviewView;
  private refreshTimer?: ReturnType<typeof setInterval>;
  private readonly sessions: SavedSessionsStore;
  /** Id of the saved session most recently loaded into the form; empty if none. */
  private loadedSessionId = '';

  constructor(
    private context: vscode.ExtensionContext,
    private server: BridgeServer,
  ) {
    this.sessions = new SavedSessionsStore(context);
    // Fix C (2.5.0): when the full-size editor panel opens or closes, the
    // sidebar re-renders so it can switch between full and compact modes —
    // no duplicate input area competing for keystrokes.
    context.subscriptions.push(
      EditorPanelProvider.onVisibilityChange(() => this.renderHtml())
    );
  }

  /** Exposed for the command palette handlers in extension.ts. */
  getSessions(): SavedSessionsStore { return this.sessions; }

  resolveWebviewView(view: vscode.WebviewView): void {
    this.view = view;
    view.webview.options = { enableScripts: true };
    this.renderHtml();

    view.webview.onDidReceiveMessage(async (msg) => {
      switch (msg.command) {
        case 'connect':
          await this.handleConnect(msg);
          break;
        case 'disconnect':
          this.server.getClient()?.disconnect();
          setTimeout(() => this.renderHtml(), 200);
          break;
        case 'toggle':
          this.server.toggle();
          setTimeout(() => this.renderHtml(), 200);
          break;
        case 'refresh':
          this.renderHtml();
          break;
        case 'send':
          await this.handleSend(msg);
          break;
        case 'tabField':
          this.handleTab(msg.direction);
          break;
        case 'diagnoseTls':
          void vscode.commands.executeCommand('tn3270Bridge.diagnoseTls');
          break;
        case 'loadSession':
          this.loadedSessionId = msg.id || '';
          this.renderHtml();
          break;
        case 'connectSession':
          await this.handleConnectSession(msg.id);
          break;
        case 'saveSession':
          await this.handleSaveSession(msg);
          break;
        case 'deleteSession':
          await this.handleDeleteSession(msg.id);
          break;
        case 'resetKeyboard':
          this.server.getClient()?.resetKeyboard();
          this.renderHtml();
          break;
        case 'focusField': {
          const c = this.server.getClient();
          if (c && typeof msg.index === 'number') {
            c.setCursorToField(msg.index);
            this.renderHtml();
          }
          break;
        }
        case 'setCursor': {
          // Fix B (2.5.0): click on the 3270 screen moves the cursor.
          const c = this.server.getClient();
          if (c && typeof msg.row === 'number' && typeof msg.col === 'number') {
            c.setCursor(msg.row, msg.col);
            this.renderHtml();
          }
          break;
        }
      }
    });

    view.onDidChangeVisibility(() => {
      if (view.visible) {
        this.renderHtml();
        this.startAutoRefresh();
      } else {
        this.stopAutoRefresh();
      }
    });

    this.startAutoRefresh();
  }

  refresh(): void { this.renderHtml(); }
  dispose(): void { this.stopAutoRefresh(); }

  private startAutoRefresh(): void {
    this.stopAutoRefresh();
    this.refreshTimer = setInterval(() => {
      if (this.view?.visible) this.renderHtml();
    }, 2000);
  }

  private stopAutoRefresh(): void {
    if (this.refreshTimer) { clearInterval(this.refreshTimer); this.refreshTimer = undefined; }
  }

  private async handleConnect(msg: any): Promise<void> {
    const host = msg.host;
    const port = parseInt(msg.port) || 23;
    const luName = msg.luName || '';
    if (!host) return;

    if (!this.server.state.running) this.server.start();
    await new Promise(r => setTimeout(r, 300)); // wait for server start

    const tlsOverride = await this.buildTlsOverrideAsync(msg, host, port);
    if (tlsOverride && tlsOverride.rejectUnauthorized === false && !msg.silentInsecure) {
      const proceed = await vscode.window.showWarningMessage(
        'You are about to connect with TLS but WITHOUT certificate verification. The traffic will be encrypted, but you cannot be sure you are talking to the real host. Continue?',
        { modal: true },
        'Connect anyway'
      );
      if (proceed !== 'Connect anyway') {
        setTimeout(() => this.renderHtml(), 100);
        return;
      }
    }

    const result = await this.server.connectTo(host, port, luName, tlsOverride);
    if (!result.success) {
      // If the failure is a certificate-trust issue and the user hasn't
      // already opted out of verification, offer a Mocha-style one-click
      // retry with rejectUnauthorized=false. Match both our translated
      // codes and Node's raw codes so any classification miss in the
      // translator still surfaces the retry dialog.
      const certCodes = new Set([
        'TLS_SELF_SIGNED', 'TLS_CA_NOT_TRUSTED',
        'TLS_CERT_EXPIRED', 'TLS_HOSTNAME_MISMATCH',
        // Raw Node codes:
        'DEPTH_ZERO_SELF_SIGNED_CERT', 'SELF_SIGNED_CERT_IN_CHAIN',
        'UNABLE_TO_GET_ISSUER_CERT_LOCALLY', 'UNABLE_TO_GET_ISSUER_CERT',
        'UNABLE_TO_VERIFY_LEAF_SIGNATURE', 'CERT_HAS_EXPIRED',
        'ERR_TLS_CERT_ALTNAME_INVALID', 'CERT_UNTRUSTED',
      ]);
      const isCertError =
        !!tlsOverride &&
        tlsOverride.rejectUnauthorized !== false &&
        certCodes.has(result.errorCode || '');

      if (isCertError) {
        // Grab the cert the server just presented (captured during the
        // failed handshake) so we can offer to pin it.
        const presentedCert = this.server.getClient()?.state.tls?.peerCertificate;
        const fingerprint = presentedCert?.fingerprint;
        const certSummary = presentedCert
          ? `\n\nServer certificate:\n  Subject: ${presentedCert.subject || 'n/a'}\n  Issuer:  ${presentedCert.issuer || 'n/a'}\n  Valid:   ${presentedCert.validFrom || '?'} → ${presentedCert.validTo || '?'}\n  SHA-256: ${fingerprint || 'n/a'}`
          : '';

        const trustLabel = fingerprint ? 'Trust this cert (pin fingerprint)' : undefined;
        const buttons: string[] = [];
        if (trustLabel) buttons.push(trustLabel);
        buttons.push('Retry without cert verification', 'Import corporate CA…');

        const choice = await vscode.window.showWarningMessage(
          `TN3270: TLS handshake failed — ${result.errorCode}.\n\n${result.errorHint || ''}${certSummary}\n\n"Trust this cert" stores the SHA-256 in VS Code SecretStorage and auto-accepts it on every future connect — same effect as Mocha's SSL checkbox but bound to THIS specific cert. "Retry without cert verification" only skips verification for this attempt.`,
          { modal: true },
          ...buttons
        );

        // Give the mainframe a moment to release any per-source rate limit
        // before the retry TCP+TLS handshake starts.
        const preRetryDelay = () => new Promise(r => setTimeout(r, 1500));

        if (choice === trustLabel && fingerprint) {
          await this.context.secrets.store(certPinSecretKey(host, port), fingerprint);
          // Mirror the pin into any matching saved session so it rides
          // along via Settings Sync (pin is not a secret).
          await this.sessions.updatePinByHostPort(host, port, fingerprint);
          vscode.window.setStatusBarMessage(
            `$(shield) TN3270: certificate pinned for ${host}:${port}`, 4000
          );
          await preRetryDelay();
          const pinnedOverride = { ...tlsOverride, pinnedFingerprint: fingerprint };
          const retry = await this.server.connectTo(host, port, luName, pinnedOverride);
          if (!retry.success) {
            const codeTag = retry.errorCode ? ` [${retry.errorCode}]` : '';
            vscode.window.showErrorMessage(
              `TN3270: retry with pinned cert failed${codeTag} — ${retry.error || 'unknown error'}${retry.errorHint ? `\n\nHint: ${retry.errorHint}` : ''}`
            );
          } else {
            const info = this.server.getClient()?.state.tls;
            vscode.window.setStatusBarMessage(
              `$(lock) TN3270: Connected with TLS (pinned) — ${info?.version || '?'} / ${info?.cipher || '?'}`,
              5000
            );
          }
        } else if (choice === 'Retry without cert verification') {
          await preRetryDelay();
          const insecureOverride = { ...tlsOverride, rejectUnauthorized: false, pinnedFingerprint: undefined };
          const retry = await this.server.connectTo(host, port, luName, insecureOverride);
          if (!retry.success) {
            const codeTag = retry.errorCode ? ` [${retry.errorCode}]` : '';
            vscode.window.showErrorMessage(
              `TN3270: retry failed${codeTag} — ${retry.error || 'unknown error'}${retry.errorHint ? `\n\nHint: ${retry.errorHint}` : ''}`
            );
          } else {
            const info = this.server.getClient()?.state.tls;
            vscode.window.setStatusBarMessage(
              `$(unlock) TN3270: Connected with TLS (unverified) — ${info?.version || '?'} / ${info?.cipher || '?'}`,
              5000
            );
          }
        } else if (choice === 'Import corporate CA…') {
          const picked = await vscode.window.showOpenDialog({
            canSelectMany: false,
            openLabel: 'Use this CA bundle',
            filters: { PEM: ['pem', 'crt', 'cer', 'ca-bundle', 'txt'] },
          });
          if (picked && picked[0]) {
            await preRetryDelay();
            const caOverride = { ...tlsOverride, caBundle: picked[0].fsPath, rejectUnauthorized: true };
            const retry = await this.server.connectTo(host, port, luName, caOverride);
            if (!retry.success) {
              const codeTag = retry.errorCode ? ` [${retry.errorCode}]` : '';
              vscode.window.showErrorMessage(
                `TN3270: retry with CA failed${codeTag} — ${retry.error || 'unknown error'}${retry.errorHint ? `\n\nHint: ${retry.errorHint}` : ''}`
              );
            }
          }
        }
      } else {
        const detail = result.errorHint ? `\n\nHint: ${result.errorHint}` : '';
        const codeTag = result.errorCode ? ` [${result.errorCode}]` : '';
        vscode.window.showErrorMessage(
          `TN3270: connection failed${codeTag} — ${result.error || 'unknown error'}${detail}`
        );
      }
    } else if (tlsOverride) {
      const info = this.server.getClient()?.state.tls;
      vscode.window.setStatusBarMessage(
        `$(lock) TN3270: Connected with TLS (${info?.version || '?'} / ${info?.cipher || '?'})`,
        4000
      );
    }
    // On successful connect, touch the matching saved session so it
    // surfaces first in the dropdown next time.
    if (result.success) {
      await this.sessions.touchByHostPort(host, port);
    }
    setTimeout(() => this.renderHtml(), 300);
  }

  /**
   * Load a saved session by id and immediately dispatch a connect. Called
   * from the sidebar dropdown's "Connect" button and from the
   * `tn3270Bridge.pickSession` command-palette entry.
   */
  private async handleConnectSession(id: string): Promise<void> {
    const session = this.sessions.get(id);
    if (!session) {
      vscode.window.showErrorMessage(`TN3270: saved session not found (id=${id})`);
      return;
    }
    this.loadedSessionId = id;
    await this.handleConnect(sessionToConnectMsg(session));
  }

  /**
   * Save the current sidebar form values as a new saved session. The
   * webview posts `{command:'saveSession', host, port, luName, tls}` with
   * the form snapshot; we prompt the user for a display name and persist.
   * If `msg.id` is set (rare: "update this saved session"), we overwrite.
   */
  private async handleSaveSession(msg: any): Promise<void> {
    const host = String(msg.host || '').trim();
    if (!host) {
      vscode.window.showWarningMessage('TN3270: fill in a host before saving.');
      return;
    }
    const port = parseInt(msg.port) || 23;
    const luName = String(msg.luName || '').trim() || undefined;

    const existing = msg.id ? this.sessions.get(String(msg.id)) : undefined;
    const proposedName = existing?.name || `${host}${port !== 23 && port !== 992 ? ':' + port : ''}`;
    const name = await vscode.window.showInputBox({
      prompt: existing ? 'Rename saved session' : 'Name for this saved session',
      value: proposedName,
      ignoreFocusOut: true,
      validateInput: v => (v && v.trim().length > 0) ? undefined : 'Name is required',
    });
    if (!name) return;

    const tlsForm = msg.tls;
    let tls: SavedSession['tls'] | undefined;
    if (tlsForm && tlsForm.enabled === true) {
      const preset = (tlsForm.preset as TlsPreset) || 'modern-verified';
      tls = { enabled: true, preset };
      if (tlsForm.caBundle) tls.caBundle = String(tlsForm.caBundle);
      if (tlsForm.sni) tls.sni = String(tlsForm.sni);
      // Pin (if any) is looked up from SecretStorage and mirrored into the
      // saved session so the trust decision follows the user via Sync.
      const pin = await this.context.secrets.get(certPinSecretKey(host, port));
      if (pin) tls.pinnedFingerprint = pin;
    }

    const saved = await this.sessions.save({
      id: existing?.id || '',
      name: name.trim(),
      host,
      port,
      luName,
      tls,
      createdAt: existing?.createdAt || '',
      lastUsedAt: existing?.lastUsedAt,
    });
    this.loadedSessionId = saved.id;
    vscode.window.setStatusBarMessage(`$(check) TN3270: session "${saved.name}" saved`, 3000);
    this.renderHtml();
  }

  private async handleDeleteSession(id: string): Promise<void> {
    const session = this.sessions.get(id);
    if (!session) return;
    const confirm = await vscode.window.showWarningMessage(
      `Delete saved session "${session.name}"?`,
      { modal: true },
      'Delete'
    );
    if (confirm !== 'Delete') return;
    await this.sessions.delete(id);
    if (this.loadedSessionId === id) this.loadedSessionId = '';
    this.renderHtml();
  }

  /**
   * Translate the sidebar TLS form payload into a TlsOptions override.
   * Returns undefined when TLS is off — the server then keeps plain TCP or the
   * global tn3270Bridge.tls.* configuration, whichever applies.
   *
   * When the user has previously pinned a certificate for this host, the
   * pinned SHA-256 is attached to the override so the connect succeeds
   * without re-prompting.
   */
  private async buildTlsOverrideAsync(msg: any, host: string, port: number): Promise<any | undefined> {
    const tls = msg?.tls;
    if (!tls || tls.enabled !== true) return undefined;

    const override: any = { enabled: true };
    const preset = tls.preset || 'modern-verified';

    switch (preset) {
      case 'modern-verified':
        override.minVersion = 'TLSv1.2';
        override.rejectUnauthorized = true;
        break;
      case 'corporate-ca':
        override.minVersion = 'TLSv1.2';
        override.rejectUnauthorized = true;
        if (tls.caBundle) override.caBundle = String(tls.caBundle);
        break;
      case 'legacy':
        override.minVersion = 'TLSv1';
        override.rejectUnauthorized = true;
        break;
      case 'encrypted-only':
        override.minVersion = 'TLSv1.2';
        override.rejectUnauthorized = false;
        break;
      case 'custom':
        // Leave preset fields unset — resolveTlsOptions() will merge the
        // tn3270Bridge.tls.* configuration on top of {enabled: true}.
        break;
      default:
        override.minVersion = 'TLSv1.2';
        override.rejectUnauthorized = true;
    }

    if (tls.sni) override.sni = String(tls.sni);

    // Attach a previously pinned fingerprint for this host, if any. This
    // lets a Modern Verified attempt succeed against a self-signed cert
    // once the user has explicitly trusted it.
    const pin = await this.context.secrets.get(certPinSecretKey(host, port));
    if (pin) override.pinnedFingerprint = pin;

    return override;
  }

  private async handleSend(msg: any): Promise<void> {
    const client = this.server.getClient();
    if (!client || client.state.status !== 'connected') return;
    try {
      // Multi-field support: {fields: [{field, text}, ...], aid}
      if (Array.isArray(msg.fields) && msg.fields.length > 0) {
        for (const entry of msg.fields) {
          if (typeof entry.field === 'number') {
            client.setCursorToField(entry.field);
          } else if (entry.row && entry.col) {
            client.setCursor(entry.row, entry.col);
          }
          if (entry.text) {
            client.typeText(entry.text);
          }
        }
        await client.sendAID(msg.aid || 'ENTER');
      } else {
        // Position cursor if field specified
        if (msg.field !== undefined) {
          client.setCursorToField(msg.field);
        } else if (msg.row && msg.col) {
          client.setCursor(msg.row, msg.col);
        }
        if (msg.text) {
          await client.sendText(msg.text, msg.aid || 'ENTER');
        } else if (msg.aid) {
          await client.sendAID(msg.aid);
        }
      }
    } catch (e: any) { /* ignore */ }
    setTimeout(() => this.renderHtml(), 100);
  }

  private handleTab(direction: number): void {
    const client = this.server.getClient();
    if (!client) return;
    const fields = client.getInputFields().filter(f => !f.protected);
    if (fields.length === 0) return;

    const cursor = client.screenState.cursor;
    const cols = client.screenState.cols;

    // Find current field
    let currentIdx = 0;
    for (let i = 0; i < fields.length; i++) {
      const fStart = (fields[i].row - 1) * cols + (fields[i].col - 1);
      if (cursor >= fStart && cursor < fStart + fields[i].length) {
        currentIdx = i;
        break;
      }
    }

    const nextIdx = (currentIdx + direction + fields.length) % fields.length;
    client.setCursorToField(fields[nextIdx].index);
    this.renderHtml();
  }

  private renderHtml(): void {
    if (!this.view) return;

    const state = this.server.state;
    const client = this.server.getClient();
    const connected = !!(client && client.state.status === 'connected');

    if (!state.running) {
      this.view.webview.html = this.buildStoppedHtml();
    } else if (!connected) {
      this.view.webview.html = this.buildConnectFormHtml();
    } else {
      this.view.webview.html = this.buildTerminalHtml(client!);
    }
  }

  private buildStoppedHtml(): string {
    return this.wrap(`
      <div class="card center">
        <div class="icon">⚡</div>
        <h3>TN3270 Bridge</h3>
        <p class="muted">Bridge server is stopped</p>
        <button class="btn-primary" onclick="cmd('toggle')">▶ Start Bridge</button>
      </div>
    `);
  }

  private buildConnectFormHtml(): string {
    const cfg = vscode.workspace.getConfiguration('tn3270Bridge');
    const savedList = this.sessions.loadAll();
    const loaded = this.loadedSessionId ? this.sessions.get(this.loadedSessionId) : undefined;

    // If a saved session is loaded, seed the form from it; otherwise from
    // the user's default settings.
    const defaultHost = loaded?.host ?? cfg.get<string>('defaultHost', '');
    const defaultPort = loaded?.port ?? cfg.get<number>('defaultPort', 23);
    const defaultLuName = loaded?.luName ?? cfg.get<string>('luName', '');
    const tlsPreconfigured = loaded ? !!loaded.tls?.enabled : cfg.get<boolean>('tls.enabled', false);
    const defaultCa = loaded?.tls?.caBundle ?? cfg.get<string>('tls.caBundle', '');
    const defaultSni = loaded?.tls?.sni ?? '';
    const port = this.server.state.port;

    // If the global tls.enabled=true (or a loaded session has TLS), pre-arm
    // the toggle and default to port 992.
    const initialPort = tlsPreconfigured && (!defaultPort || defaultPort === 23) ? 992 : defaultPort;
    const initialPreset: string = loaded?.tls?.preset ?? (tlsPreconfigured ? 'custom' : 'modern-verified');

    const savedOptions = savedList.map(s => {
      const label = `${esc(s.name)} — ${esc(s.host)}:${s.port}${s.tls?.enabled ? ' 🔒' : ''}`;
      return `<option value="${esc(s.id)}" ${s.id === this.loadedSessionId ? 'selected' : ''}>${label}</option>`;
    }).join('');
    const savedSectionHtml = `
      <div class="saved-block">
        <div class="saved-title">📌 Saved sessions</div>
        ${savedList.length > 0 ? `
          <div class="form-group">
            <select id="savedPick" onchange="onSavedPick()">
              <option value="">— pick a saved session —</option>
              ${savedOptions}
            </select>
          </div>
          <div class="saved-actions">
            <button class="btn-secondary" onclick="doConnectSaved()" ${this.loadedSessionId ? '' : 'disabled'} id="btnConnectSaved" title="Load and connect in one click">🔌 Connect</button>
            <button class="btn-secondary" onclick="doDeleteSaved()" ${this.loadedSessionId ? '' : 'disabled'} id="btnDeleteSaved" title="Delete this saved session">🗑</button>
          </div>
        ` : `<div class="hint" style="margin-bottom:6px">No saved sessions yet. Fill the form below and click 💾 Save.</div>`}
      </div>
    `;

    return this.wrap(`
      <div class="card">
        <div class="header">
          <span class="dot ready"></span>
          <span>Bridge ready on :${port}</span>
        </div>

        ${savedSectionHtml}

        <h3 style="margin-top:12px">🖥️ Connect to Mainframe</h3>

        <div class="form-group">
          <label>Host</label>
          <input type="text" id="host" value="${esc(defaultHost)}" placeholder="hostname or IP" />
        </div>

        <div class="form-group">
          <label>Port</label>
          <input type="number" id="port" value="${initialPort}" placeholder="23" />
          <div class="hint" id="portHint">Plain TCP · default 23</div>
        </div>

        <div class="form-group">
          <label>LU Name (optional)</label>
          <input type="text" id="luName" value="${esc(defaultLuName)}" placeholder="e.g. TN30003" />
        </div>

        <!-- TLS toggle -->
        <div class="tls-block">
          <label class="tls-toggle">
            <input type="checkbox" id="tlsEnabled" ${tlsPreconfigured ? 'checked' : ''} onchange="onTlsToggle()" />
            <span>🔒 Use TLS (encrypted connection)</span>
          </label>

          <div id="tlsOptions" class="tls-options" style="display:${tlsPreconfigured ? 'block' : 'none'};">
            <div class="form-group">
              <label>TLS profile</label>
              <select id="tlsPreset" onchange="onPresetChange()">
                <option value="modern-verified" ${initialPreset === 'modern-verified' ? 'selected' : ''}>Modern verified (TLSv1.2+, OS trust)</option>
                <option value="corporate-ca"    ${initialPreset === 'corporate-ca'    ? 'selected' : ''}>Corporate CA bundle (TLSv1.2+)</option>
                <option value="legacy"          ${initialPreset === 'legacy'          ? 'selected' : ''}>Legacy host (TLSv1.0+, verified)</option>
                <option value="encrypted-only"  ${initialPreset === 'encrypted-only'  ? 'selected' : ''}>Encrypted only, skip cert (≈ Mocha "SSL/TLS" checkbox)</option>
                <option value="custom"          ${initialPreset === 'custom'          ? 'selected' : ''}>Use tn3270Bridge.tls.* settings</option>
              </select>
              <div class="hint" id="presetHint"></div>
            </div>

            <div class="form-group" id="caGroup" style="display:none;">
              <label>Corporate root CA (PEM file path)</label>
              <input type="text" id="tlsCa" value="${esc(defaultCa)}" placeholder="C:\\certs\\corp-root-ca.pem" />
            </div>

            <div class="form-group">
              <label>SNI override (optional)</label>
              <input type="text" id="tlsSni" value="${esc(defaultSni)}" placeholder="mainframe.example.com" />
              <div class="hint">Fill only when connecting by IP but the cert is for a hostname.</div>
            </div>
          </div>
        </div>

        <div style="display:flex; gap:6px;">
          <button class="btn-primary" style="flex:1" onclick="doConnect()" id="connectBtn">🔌 Connect</button>
          <button class="btn-secondary" onclick="doSaveSession()" title="Save the current form as a named session">💾 Save…</button>
        </div>

        <div class="separator"></div>
        <div style="display:flex; gap:6px;">
          <button class="btn-secondary" onclick="cmd('diagnoseTls')" title="Run a TLS handshake and open a report — useful when connect times out">🔍 Diagnose TLS</button>
          <button class="btn-secondary" onclick="cmd('toggle')">⏹ Stop Bridge</button>
        </div>
      </div>

      <script>
        const vscode = acquireVsCodeApi();
        function cmd(c, d) { vscode.postMessage(Object.assign({command:c}, d||{})); }

        const portEl = document.getElementById('port');
        const portHintEl = document.getElementById('portHint');
        const tlsCheckEl = document.getElementById('tlsEnabled');
        const tlsOptionsEl = document.getElementById('tlsOptions');
        const presetEl = document.getElementById('tlsPreset');
        const presetHintEl = document.getElementById('presetHint');
        const caGroupEl = document.getElementById('caGroup');
        const btnEl = document.getElementById('connectBtn');

        function refreshPortHint() {
          const p = parseInt(portEl.value) || 23;
          const tls = tlsCheckEl.checked;
          portHintEl.textContent = tls
            ? (p === 992 ? 'TLS · standard port 992' : 'TLS · non-standard port ' + p)
            : (p === 23  ? 'Plain TCP · default 23'   : 'Plain TCP · port ' + p);
        }

        function refreshPresetHint() {
          const v = presetEl.value;
          const hints = {
            'modern-verified': 'Verifies the server certificate against the OS/Node trust store. Best default.',
            'corporate-ca':    'Verifies against the CA bundle you supply below. Use when the corporate root is not in the OS trust store.',
            'legacy':          'Allows TLSv1.0+ for older LPARs that have not been upgraded to TLSv1.2 yet.',
            'encrypted-only':  'Encrypts the traffic but SKIPS certificate verification. Same effective behavior as Mocha TN3270 SSL/TLS checkbox — use when the mainframe presents a self-signed / internal-CA cert.',
            'custom':          'Uses tn3270Bridge.tls.* from settings.json exactly as configured.',
          };
          presetHintEl.textContent = hints[v] || '';
          caGroupEl.style.display = (v === 'corporate-ca') ? 'block' : 'none';
        }

        function onTlsToggle() {
          const on = tlsCheckEl.checked;
          tlsOptionsEl.style.display = on ? 'block' : 'none';
          btnEl.textContent = on ? '🔒 Connect with TLS' : '🔌 Connect';
          // Auto-swap default ports so users don't have to guess.
          const cur = parseInt(portEl.value) || 0;
          if (on && (cur === 23 || cur === 0)) portEl.value = 992;
          if (!on && cur === 992) portEl.value = 23;
          refreshPortHint();
        }

        function onPresetChange() { refreshPresetHint(); }

        function doConnect() {
          const host = document.getElementById('host').value.trim();
          const port = portEl.value.trim();
          const luName = document.getElementById('luName').value.trim();
          if (!host) return;

          let tlsPayload;
          if (tlsCheckEl.checked) {
            tlsPayload = {
              enabled: true,
              preset: presetEl.value,
              caBundle: document.getElementById('tlsCa').value.trim() || undefined,
              sni:      document.getElementById('tlsSni').value.trim() || undefined,
            };
          }
          cmd('connect', {host, port, luName, tls: tlsPayload});
        }

        ['host','port','luName'].forEach(id => {
          document.getElementById(id).addEventListener('keydown', e => { if (e.key==='Enter') doConnect(); });
        });
        portEl.addEventListener('input', refreshPortHint);

        // Saved-session controls (may be absent if the list is empty)
        function onSavedPick() {
          const el = document.getElementById('savedPick');
          cmd('loadSession', { id: el.value });
        }
        function doConnectSaved() {
          const el = document.getElementById('savedPick');
          if (el && el.value) cmd('connectSession', { id: el.value });
        }
        function doDeleteSaved() {
          const el = document.getElementById('savedPick');
          if (el && el.value) cmd('deleteSession', { id: el.value });
        }
        function doSaveSession() {
          const host = document.getElementById('host').value.trim();
          const port = portEl.value.trim();
          const luName = document.getElementById('luName').value.trim();
          if (!host) return;
          let tlsPayload;
          if (tlsCheckEl.checked) {
            tlsPayload = {
              enabled: true,
              preset: presetEl.value,
              caBundle: document.getElementById('tlsCa').value.trim() || undefined,
              sni:      document.getElementById('tlsSni').value.trim() || undefined,
            };
          }
          cmd('saveSession', { id: '${esc(this.loadedSessionId)}', host, port, luName, tls: tlsPayload });
        }

        // First paint
        refreshPortHint();
        refreshPresetHint();
        onTlsToggle();
        // The auto-swap in onTlsToggle would clobber a pre-armed port; restore.
        portEl.value = '${initialPort}';
        refreshPortHint();
        btnEl.textContent = tlsCheckEl.checked ? '🔒 Connect with TLS' : '🔌 Connect';
      </script>
    `);
  }

  /**
   * Compact sidebar view used when the full-size editor panel is open.
   * No duplicate screen, no input area, no AID buttons — just status,
   * cert badge, keyboard-lock reset, and field-navigation helpers.
   */
  private buildCompactCompanionHtml(client: any, ctx: {
    cursorRow: number; cursorCol: number;
    fields: any[]; inputFields: any[]; kbLocked: boolean;
    tlsInfo: any; tlsOn: boolean; secIcon: string; secLabel: string; secTitle: string;
  }): string {
    const state = this.server.state;
    const { cursorRow, cursorCol, fields, inputFields, kbLocked,
      tlsOn, secIcon, secLabel, secTitle } = ctx;

    const fieldsHtml = inputFields.length > 0
      ? inputFields.slice(0, 12).map((f: any) => {
        const label = f.content.trim() || `(empty)`;
        return `<div class="field-item" onclick="cmd('focusField', {index:${f.index}})">
          <span class="field-pos">R${f.row}:C${f.col}</span>
          <span class="field-val">${esc(label)}</span>
        </div>`;
      }).join('')
      : '<div class="hint" style="padding:6px 0">No input fields on this screen.</div>';

    return this.wrap(`
      <div class="header">
        <span class="dot connected"></span>
        <span class="host">${state.host}:${state.mainframePort}</span>
        <span class="sec-badge ${tlsOn ? 'sec-tls' : 'sec-plain'}" title="${esc(secTitle)}">${secIcon} ${tlsOn ? 'TLS' : 'PLAIN'}</span>
        <button class="btn-icon" onclick="cmd('disconnect')" title="Disconnect">✕</button>
      </div>

      <div class="companion-banner">
        <span>📺 Editor panel is the active surface</span>
      </div>

      <div class="status-bar">
        <span>R${cursorRow} C${cursorCol}</span>
        <span>Fields: ${fields.length}</span>
        <span class="${kbLocked ? 'warn clickable' : 'ok'}" ${kbLocked ? `onclick="cmd('resetKeyboard')" title="Click to RESET the keyboard"` : ''}>${kbLocked ? '🔒 LOCKED — click to RESET' : '✓ Ready'}</span>
      </div>

      <div class="section">
        <div class="section-title">
          📋 Input Fields
          <span class="nav-btns">
            <button class="btn-icon" onclick="cmd('tabField',{direction:-1})" title="Previous field">◀</button>
            <button class="btn-icon" onclick="cmd('tabField',{direction:1})" title="Next field">▶</button>
          </span>
        </div>
        <div class="fields-list">${fieldsHtml}</div>
      </div>

      <div class="section">
        <div class="section-title">⚡ Quick Actions</div>
        <div class="quick-actions">
          <button class="action" onclick="cmd('send',{aid:'ENTER'})">⏎ Enter</button>
          <button class="action" onclick="cmd('send',{aid:'PF3'})">F3</button>
          <button class="action" onclick="cmd('send',{aid:'PF7'})">F7↑</button>
          <button class="action" onclick="cmd('send',{aid:'PF8'})">F8↓</button>
          <button class="action" onclick="cmd('send',{aid:'CLEAR'})">Clear</button>
          <button class="action" onclick="cmd('resetKeyboard')">⏮ RESET</button>
          <button class="action" onclick="cmd('refresh')">🔄</button>
        </div>
      </div>

      <div class="hint" style="margin-top:8px; text-align:center">
        Sidebar is in <b>compact mode</b> because the editor panel is open.<br>
        Close the editor tab to return to full sidebar controls.
      </div>

      <div class="api-info">
        <code>http://127.0.0.1:${state.port}</code>
      </div>

      <script>
        const vscode = acquireVsCodeApi();
        function cmd(c, d) { vscode.postMessage(Object.assign({command:c}, d||{})); }
      </script>
    `);
  }

  private buildTerminalHtml(client: any): string {
    const state = this.server.state;
    const screen = client.getScreenText();
    const cursor = client.screenState.cursor;
    const cols = client.screenState.cols;
    const cursorRow = Math.floor(cursor / cols) + 1;
    const cursorCol = (cursor % cols) + 1;
    const fields = client.getInputFields();
    const inputFields = fields.filter((f: any) => !f.protected);
    const kbLocked = client.screenState.keyboardLocked;
    const tlsInfo = client.state.tls;
    const tlsOn = !!(tlsInfo && tlsInfo.enabled);
    const secIcon = tlsOn ? '🔒' : '🔓';
    const secLabel = tlsOn
      ? `TLS ${esc(tlsInfo.version || '')} · ${esc(tlsInfo.cipher || '')}`
      : 'Plain TCP (no encryption)';
    const secTitle = tlsOn && tlsInfo.peerCertificate
      ? `Cert: ${tlsInfo.peerCertificate.subject} · issued by ${tlsInfo.peerCertificate.issuer} · valid to ${tlsInfo.peerCertificate.validTo}`
      : secLabel;

    // Fix C (2.5.0): if the full-size editor panel is open, the sidebar
    // renders a compact companion view — no duplicate 3270 screen, no
    // duplicate input, no AID keys competing for focus. The editor is
    // the primary interaction surface; the sidebar becomes a control
    // strip with status, cert info, field navigation and quick actions.
    if (EditorPanelProvider.isOpen()) {
      return this.buildCompactCompanionHtml(client, {
        cursorRow, cursorCol, fields, inputFields, kbLocked,
        tlsInfo, tlsOn, secIcon, secLabel, secTitle,
      });
    }

    // Screen with cursor highlight — Fix B (2.5.0): each line carries a
    // data-row so clicking the screen moves the 3270 cursor to that position.
    const screenHtml = screen.map((line: string, i: number) => {
      const row = i + 1;
      if (i === cursorRow - 1) {
        // Split BEFORE escaping so positions match the original buffer
        const before = esc(line.substring(0, cursorCol - 1));
        const ch = esc(line.substring(cursorCol - 1, cursorCol) || ' ');
        const after = esc(line.substring(cursorCol));
        return `<div class="line" data-row="${row}">${before}<span class="cursor">${ch}</span>${after}</div>`;
      }
      return `<div class="line" data-row="${row}">${esc(line)}</div>`;
    }).join('');

    // Input fields list (for quick field access)
    let fieldsHtml = '';
    if (inputFields.length > 0) {
      fieldsHtml = inputFields.slice(0, 8).map((f: any) => {
        const label = f.content.trim() || `(empty)`;
        return `<div class="field-item" onclick="focusField(${f.index})">
          <span class="field-pos">R${f.row}:C${f.col}</span>
          <span class="field-val">${esc(label)}</span>
        </div>`;
      }).join('');
    }

    return this.wrap(`
      <div class="header">
        <span class="dot connected"></span>
        <span class="host">${state.host}:${state.mainframePort}</span>
        <span class="sec-badge ${tlsOn ? 'sec-tls' : 'sec-plain'}" title="${esc(secTitle)}">${secIcon} ${tlsOn ? 'TLS' : 'PLAIN'}</span>
        <button class="btn-icon" onclick="cmd('disconnect')" title="Disconnect">✕</button>
      </div>

      <div class="screen" id="screen" onclick="handleScreenClick(event)" title="Click to position the 3270 cursor">${screenHtml}</div>

      <div class="status-bar">
        <span>R${cursorRow} C${cursorCol}</span>
        <span>Fields: ${fields.length}</span>
        <span class="${kbLocked ? 'warn clickable' : 'ok'}" ${kbLocked ? `onclick="cmd('resetKeyboard')" title="Click to RESET the keyboard (clears LOCKED locally, like the 3270 RESET key)"` : ''}>${kbLocked ? '🔒 LOCKED — click to RESET' : '✓ Ready'}</span>
        <span class="sec-detail" title="${esc(secTitle)}">${secIcon} ${esc(secLabel)}</span>
      </div>

      <!-- Text input area -->
      <div class="input-area">
        <input type="text" id="textInput" placeholder="Type text here, then press Enter or a PF key..."
               onkeydown="handleKey(event)" autocomplete="off" spellcheck="false" />
      </div>

      <!-- AID Keys -->
      <div class="aid-keys">
        <button class="aid enter" onclick="sendWithText('ENTER')">⏎ Enter</button>
        <button class="aid" onclick="sendWithText('PF1')">F1</button>
        <button class="aid" onclick="sendWithText('PF2')">F2</button>
        <button class="aid highlight" onclick="sendWithText('PF3')">F3</button>
        <button class="aid" onclick="sendWithText('PF4')">F4</button>
        <button class="aid" onclick="sendWithText('PF5')">F5</button>
        <button class="aid" onclick="sendWithText('PF6')">F6</button>
        <button class="aid highlight" onclick="sendWithText('PF7')">F7↑</button>
        <button class="aid highlight" onclick="sendWithText('PF8')">F8↓</button>
        <button class="aid" onclick="sendWithText('PF9')">F9</button>
        <button class="aid" onclick="sendWithText('PF10')">F10</button>
        <button class="aid" onclick="sendWithText('PF11')">F11</button>
        <button class="aid" onclick="sendWithText('PF12')">F12</button>
        <button class="aid special" onclick="sendWithText('CLEAR')">Clear</button>
        <button class="aid special" onclick="sendWithText('PA1')">PA1</button>
        <button class="aid special" onclick="sendWithText('PA2')">PA2</button>
        <button class="aid reset" onclick="cmd('resetKeyboard')" title="Local RESET — clear the LOCKED indicator without sending anything to the host (equivalent to 3270 RESET key)">⏮ RESET</button>
      </div>

      <!-- Field Navigation -->
      ${inputFields.length > 0 ? `
      <div class="section">
        <div class="section-title">
          📋 Input Fields
          <span class="nav-btns">
            <button class="btn-icon" onclick="cmd('tabField',{direction:-1})" title="Previous field">◀</button>
            <button class="btn-icon" onclick="cmd('tabField',{direction:1})" title="Next field">▶</button>
          </span>
        </div>
        <div class="fields-list">${fieldsHtml}</div>
      </div>` : ''}

      <!-- Quick Actions -->
      <div class="section">
        <div class="section-title">⚡ Quick Actions</div>
        <div class="quick-actions">
          <button class="action" onclick="cmd('send',{text:'LOGON TSO',aid:'ENTER'})">TSO Login</button>
          <button class="action" onclick="cmd('send',{text:'ISPF',aid:'ENTER'})">ISPF</button>
          <button class="action" onclick="cmd('send',{text:'3.4',aid:'ENTER'})">DS List</button>
          <button class="action" onclick="cmd('send',{text:'=X',aid:'ENTER'})">Exit ISPF</button>
          <button class="action" onclick="cmd('send',{text:'LOGOFF',aid:'ENTER'})">Logoff</button>
          <button class="action" onclick="cmd('refresh')">🔄 Refresh</button>
        </div>
      </div>

      <div class="api-info">
        <code>http://127.0.0.1:${state.port}</code>
      </div>

      <script>
        const vscode = acquireVsCodeApi();
        function cmd(c, d) { vscode.postMessage(Object.assign({command:c}, d||{})); }

        // Fix B (2.5.0): click the 3270 screen to move the cursor.
        function handleScreenClick(e) {
          const line = e.target.closest('div.line');
          if (!line || !line.dataset.row) return;
          const row = parseInt(line.dataset.row, 10);
          const len = Math.max(1, line.textContent.length);
          const rect = line.getBoundingClientRect();
          const x = e.clientX - rect.left;
          const charWidth = rect.width / len;
          let col = Math.floor(x / charWidth) + 1;
          if (col < 1) col = 1;
          if (col > len) col = len;
          cmd('setCursor', { row, col });
          setTimeout(() => document.getElementById('textInput')?.focus(), 0);
        }

        function sendWithText(aid) {
          const input = document.getElementById('textInput');
          const text = input.value;
          input.value = '';
          cmd('send', { text: text || undefined, aid });
        }

        function handleKey(e) {
          if (e.key === 'Enter') { e.preventDefault(); sendWithText('ENTER'); }
          else if (e.key === 'Tab') { e.preventDefault(); cmd('tabField', {direction: e.shiftKey ? -1 : 1}); }
          else if (e.key === 'Escape') { e.preventDefault(); sendWithText('CLEAR'); }
          else if (e.key.match(/^F(\\d+)$/)) {
            e.preventDefault();
            const n = parseInt(e.key.substring(1));
            if (n >= 1 && n <= 12) sendWithText('PF' + n);
          }
        }

        function focusField(idx) {
          const input = document.getElementById('textInput');
          input.focus();
          cmd('send', { field: idx });
        }

        // Focus-preserving re-render (v2.5.0):
        // The auto-refresh timer rewrites this webview's HTML every 2s. In
        // the earlier version we auto-focused #textInput unconditionally,
        // which stole focus from the editor panel every refresh — combined
        // with the editor's own auto-focus it created a focus-pinball that
        // dropped keystrokes and made OMVS unusable. We now:
        //  1. Persist "did the user interact with THIS panel" flag in the
        //     webview's own state (vscode.setState — private per webview).
        //  2. Only auto-focus if the user was previously typing here AND
        //     the input value was empty (i.e. mid-type restore).
        //  3. Never auto-focus on a plain refresh — a click is required.
        (function restoreFocus() {
          const st = vscode.getState() || {};
          if (st.wasTyping) {
            const input = document.getElementById('textInput');
            if (input && input.value === '') {
              // Non-aggressive: only focus if nothing else already grabbed.
              if (!document.activeElement || document.activeElement === document.body) {
                input.focus();
              }
            }
          }
        })();
        (function trackFocus() {
          const input = document.getElementById('textInput');
          if (!input) return;
          input.addEventListener('focus', () => vscode.setState({ ...(vscode.getState()||{}), wasTyping: true }));
          input.addEventListener('blur',  () => vscode.setState({ ...(vscode.getState()||{}), wasTyping: false }));
        })();
      </script>
    `);
  }

  private wrap(content: string): string {
    return `<!DOCTYPE html><html><head><style>
* { box-sizing: border-box; }
body { font-family: var(--vscode-font-family); padding: 8px; margin: 0; color: var(--vscode-foreground); font-size: 12px; }
h3 { margin: 0 0 8px; font-size: 14px; }
.card { padding: 12px; }
.card.center { text-align: center; padding-top: 30px; }
.icon { font-size: 32px; margin-bottom: 8px; }
.muted { color: var(--vscode-descriptionForeground); margin: 8px 0; }

/* Header */
.header { display: flex; align-items: center; gap: 6px; margin-bottom: 6px; }
.dot { width: 8px; height: 8px; border-radius: 50%; }
.dot.connected { background: #4ec9b0; }
.dot.ready { background: #dcdcaa; }
.dot.off { background: #808080; }
.host { flex: 1; font-weight: 500; }

/* Form */
.form-group { margin-bottom: 10px; }
.form-group label { display: block; font-size: 11px; color: var(--vscode-descriptionForeground); margin-bottom: 3px; }
.form-group input, .form-group select {
  width: 100%; padding: 6px 8px; border-radius: 4px; font-size: 12px;
  background: var(--vscode-input-background); color: var(--vscode-input-foreground);
  border: 1px solid var(--vscode-input-border, #444);
}
.form-group input:focus, .form-group select:focus { border-color: var(--vscode-focusBorder); outline: none; }
.hint { font-size: 10px; color: var(--vscode-descriptionForeground); margin-top: 3px; }
.separator { border-top: 1px solid var(--vscode-widget-border, #333); margin: 12px 0; }

/* TLS block */
.tls-block { margin: 8px 0 10px; padding: 8px; border: 1px dashed var(--vscode-widget-border, #444); border-radius: 4px; }
.tls-toggle { display: flex; align-items: center; gap: 6px; cursor: pointer; font-size: 12px; }
.tls-toggle input { margin: 0; }
.tls-options { margin-top: 8px; padding-top: 8px; border-top: 1px solid var(--vscode-widget-border, #333); }

/* Saved sessions block */
.saved-block { margin: 6px 0 10px; padding: 8px; border: 1px solid var(--vscode-widget-border, #444); border-radius: 4px; background: var(--vscode-sideBarSectionHeader-background, transparent); }
.saved-title { font-size: 11px; font-weight: 600; margin-bottom: 6px; color: var(--vscode-descriptionForeground); }
.saved-actions { display: flex; gap: 6px; }
.saved-actions button:disabled { opacity: 0.4; cursor: not-allowed; }

/* Security badges (connected view) */
.sec-badge { font-size: 10px; padding: 1px 6px; border-radius: 8px; font-weight: 600; margin-right: 4px; }
.sec-tls   { background: #1a4a3a; color: #4ec9b0; border: 1px solid #4ec9b0; }
.sec-plain { background: #3a2a2a; color: #f88; border: 1px solid #844; }
.sec-detail { margin-left: auto; color: #888; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 160px; }

/* Buttons */
.btn-primary { background: var(--vscode-button-background); color: var(--vscode-button-foreground); border: none; padding: 7px 14px; border-radius: 4px; cursor: pointer; font-size: 12px; font-weight: 500; }
.btn-primary:hover { background: var(--vscode-button-hoverBackground); }
.btn-primary.full { width: 100%; }
.btn-secondary { background: transparent; color: var(--vscode-descriptionForeground); border: 1px solid var(--vscode-widget-border, #444); padding: 5px 10px; border-radius: 4px; cursor: pointer; font-size: 11px; }
.btn-secondary:hover { color: var(--vscode-foreground); }
.btn-icon { background: none; border: none; color: var(--vscode-descriptionForeground); cursor: pointer; padding: 2px 6px; border-radius: 3px; font-size: 12px; }
.btn-icon:hover { background: var(--vscode-toolbar-hoverBackground); color: var(--vscode-foreground); }

/* Screen */
.screen {
  font-family: 'Cascadia Mono', 'Courier New', monospace;
  font-size: 8.5px; line-height: 1.15;
  background: #0a0a1a; color: #00ff41;
  padding: 5px; border-radius: 4px;
  overflow-x: auto; white-space: pre;
  max-height: 340px; overflow-y: auto;
  border: 1px solid #2a2a3e;
  min-height: 160px;
  cursor: text;  /* click-to-position (Fix B, v2.5.0) */
}
.line:hover { background: rgba(0, 255, 65, 0.06); }
.line { height: 10px; }
.cursor { background: #00ff41; color: #0a0a1a; }
.empty { color: #555; font-style: italic; padding: 40px; text-align: center; }

/* Status bar */
.status-bar { display: flex; gap: 10px; font-size: 10px; color: #888; padding: 3px 0; border-bottom: 1px solid var(--vscode-widget-border, #333); }
.companion-banner { display: flex; align-items: center; justify-content: center; gap: 6px; padding: 8px 6px; margin: 8px 0; background: rgba(78,201,176,0.08); border: 1px solid rgba(78,201,176,0.3); border-radius: 4px; font-size: 11px; color: #4ec9b0; }
.status-bar .warn { color: #f55; }
.status-bar .ok { color: #4ec9b0; }
.status-bar .clickable { cursor: pointer; text-decoration: underline; }
.status-bar .clickable:hover { color: #fbb; }

/* Input area */
.input-area { margin: 8px 0 6px; }
.input-area input {
  width: 100%; padding: 7px 10px; border-radius: 4px; font-size: 12px;
  font-family: 'Cascadia Mono', 'Courier New', monospace;
  background: var(--vscode-input-background); color: #00ff41;
  border: 1px solid var(--vscode-input-border, #444);
}
.input-area input:focus { border-color: #00ff41; outline: none; }
.input-area input::placeholder { color: #555; }

/* AID Keys */
.aid-keys { display: flex; flex-wrap: wrap; gap: 3px; margin-bottom: 10px; }
.aid { background: #2a2a3e; color: #ccc; border: 1px solid #444; padding: 4px 6px; border-radius: 3px; cursor: pointer; font-size: 10px; min-width: 28px; text-align: center; }
.aid:hover { background: #3a3a5e; border-color: #666; }
.aid.enter { background: #1a4a3a; color: #4ec9b0; border-color: #4ec9b0; font-weight: bold; min-width: 60px; }
.aid.enter:hover { background: #2a5a4a; }
.aid.highlight { background: #2a3a5e; color: #6af; border-color: #4a7acc; }
.aid.highlight:hover { background: #3a4a6e; }
.aid.special { background: #3a2a2a; color: #f88; border-color: #844; }
.aid.special:hover { background: #4a3a3a; }
.aid.reset { background: #2a3a2a; color: #7c7; border-color: #494; }
.aid.reset:hover { background: #3a4a3a; }

/* Sections */
.section { margin-top: 10px; padding-top: 8px; border-top: 1px solid var(--vscode-widget-border, #333); }
.section-title { font-size: 11px; font-weight: 600; margin-bottom: 6px; display: flex; align-items: center; justify-content: space-between; }
.nav-btns { display: flex; gap: 2px; }

/* Fields list */
.fields-list { display: flex; flex-direction: column; gap: 2px; max-height: 120px; overflow-y: auto; }
.field-item { display: flex; gap: 6px; padding: 3px 6px; border-radius: 3px; cursor: pointer; font-size: 10px; }
.field-item:hover { background: var(--vscode-list-hoverBackground); }
.field-pos { color: #888; font-family: monospace; min-width: 50px; }
.field-val { color: #4ec9b0; font-family: monospace; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

/* Quick actions */
.quick-actions { display: flex; flex-wrap: wrap; gap: 4px; }
.action { background: var(--vscode-button-secondaryBackground, #333); color: var(--vscode-button-secondaryForeground, #ccc); border: none; padding: 4px 10px; border-radius: 4px; cursor: pointer; font-size: 11px; }
.action:hover { background: var(--vscode-button-secondaryHoverBackground, #444); }

/* API info */
.api-info { margin-top: 10px; text-align: center; }
.api-info code { font-size: 9px; color: #888; background: var(--vscode-textCodeBlock-background); padding: 2px 6px; border-radius: 3px; }
</style></head><body>${content}</body></html>`;
  }
}

/**
 * SecretStorage key for a pinned certificate. Host is lowercased and paired
 * with port so a distinct port on the same host can pin a different cert.
 */
/**
 * Convert a SavedSession record into the message shape handleConnect
 * expects (matches what the webview posts on the Connect button).
 */
function sessionToConnectMsg(s: SavedSession): any {
  return {
    command: 'connect',
    host: s.host,
    port: String(s.port),
    luName: s.luName || '',
    tls: s.tls?.enabled ? {
      enabled: true,
      preset: s.tls.preset,
      caBundle: s.tls.caBundle,
      sni: s.tls.sni,
    } : undefined,
  };
}

function certPinSecretKey(host: string, port: number): string {
  return `tn3270.certpin.${host.toLowerCase()}:${port}`;
}

function esc(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
