# I built a TN3270 mainframe terminal inside VS Code. Here's why.

Last month I was debugging a batch issue on z/OS. I had VS Code open with analysis scripts, a browser with AWR reports, and a separate TN3270 emulator eating screen real estate just to check a JCL member. Alt-tabbing, copying text manually, losing context every time.

So I built a TN3270 terminal extension for VS Code. Not a wrapper around an external tool — a from-scratch TypeScript implementation of the full 3270 protocol: Telnet negotiation, EBCDIC translation, structured fields, Write Structured Field, Query Reply, everything.

**What it does**

You get a live mainframe terminal directly in your editor. Sidebar panel for quick access, or open it full-size in an editor tab. Connect to any TN3270 host, navigate ISPF, edit datasets, submit jobs, check SDSF — all without leaving VS Code.

But the real power is the HTTP bridge. The extension runs a local REST API on localhost that exposes the 3270 session programmatically. Read the screen as JSON. Send keystrokes. Wait for specific text to appear.

```
GET  /screen          → current screen as text lines
GET  /screen/fields   → all fields with positions and content
POST /send            → type text and press a key
POST /wait            → block until text appears on screen
```

**AI meets the mainframe**

Here's what changes everything: GitHub Copilot can now interact with the mainframe directly through this extension.

I tested it side by side with different AI assistants. GitHub Copilot in VS Code nailed it — I asked it to log into TSO, navigate ISPF, open a Unix System Services shell, explore directories, and log off. It did the entire sequence autonomously — reading screens, deciding which option to select, handling multi-step login flows. No human intervention. It understood the 3270 screen layout, picked the right fields, pressed the right PF keys, and adapted when screens changed unexpectedly.

Think about what this unlocks. An AI agent that checks job output in SDSF when your batch fails at 3am. A prompt that says "check if dataset X exists and show me member Y" and it just does it. Automated health checks that navigate ISPF panels and produce reports — driven by natural language instead of brittle screen-scraping scripts.

The 3270 protocol hasn't changed in decades, which makes it entirely predictable. The REST API gives AI models clean JSON — field positions, content, cursor location — instead of raw escape sequences. That structured data is exactly what they need to reason about what's on screen and what to do next.

**Why this matters**

Mainframes process 90% of credit card transactions globally. The people who know how to operate them are retiring every year, taking decades of ISPF muscle memory with them.

AI with mainframe access changes that. A junior developer asks "how do I check the JCL output for job X" and the AI shows them live on the system. The barrier drops from "learn 40 years of navigation" to "describe what you need."

**The hard parts**

Getting TN3270 right from scratch was not trivial. Read Modified responses need to include protected fields with MDT set — something even established open source implementations got wrong. Query Reply, EBCDIC code pages, field attributes, cursor addressing — all of it matters.

**Get it**

The extension is free. Install the VSIX in VS Code and connect to your mainframe in seconds. No Java, no external emulator, no license fees. TypeScript, zero runtime dependencies. Windows, macOS, Linux.

If you work with mainframes and want GitHub Copilot to finally understand what's on that green screen, this is for you.
