# TN3270 Bridge 2.2.0 Project

This is a VS Code extension that provides a TN3270 mainframe terminal emulator with an HTTP bridge API.

## Mainframe Navigation

When asked to interact with the mainframe, read `MAINFRAME_NAVIGATION.md` for complete API documentation, navigation patterns, and troubleshooting.

Key points:
- Bridge API runs on http://localhost:7327
- Always read the screen after sending (wait 1-2s)
- Use /screen/fields to find input field positions before typing
- Pad text with spaces when overwriting fields with prior content
- Never expose passwords in output (hidden fields return empty)

## Build & Deploy

```bash
# Verify metadata, compile, test, and bundle all entry points
npm run check

# Package VSIX
npm run package
```

## Project Structure

- `src/tn3270-client.ts` — Core TN3270 protocol client (connect, negotiate, screen buffer)
- `src/tn3270-protocol.ts` — Protocol constants, EBCDIC tables, type definitions
- `src/bridge-server.ts` — HTTP REST API server
- `src/mcp-server.ts` — Copilot/Claude MCP adapter over REST
- `src/local-credential-broker.ts` — same-user token delivery
- `src/sidebar-provider.ts` — VS Code sidebar WebView UI
- `src/editor-panel-provider.ts` — Full-size editor panel WebView UI
- `src/extension.ts` — Extension entry point
