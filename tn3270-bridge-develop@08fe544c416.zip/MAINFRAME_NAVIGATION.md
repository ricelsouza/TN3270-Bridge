# TN3270 Bridge 2.2.0 — Mainframe Navigation Instructions

> **Authentication:** use the bundled MCP server or `bridge-cli.js`.
> Both obtain credentials transparently from the Extension Host over same-user
> IPC. No token copy, prompt or environment variable is required. Raw REST calls
> still require bearer authentication for backward compatibility.
> Supplying only `http://127.0.0.1:7327` to an agent is insufficient; Claude Code
> discovers the user-scoped `tn3270-bridge` MCP registration created at extension
> activation and calls its `mainframe_*` tools.

## Connecting with TLS (1.5.0+)

Most production mainframes require TLS on **port 992**. Four ways to enable it:

### 1. Command Palette wizard (easiest)

`Ctrl+Shift+P` → **TN3270 Bridge: Connect with TLS (Secure)**.

Pick one preset:

| Preset | When to use | What it sets |
|--------|-------------|--------------|
| 🛡️ Modern strict | Most production hosts | TLS 1.2+, full cert verification |
| 🛡️ Corporate CA | Cert signed by an internal CA | TLS 1.2+, verify against a PEM you point to |
| 🛡️ Legacy compatible | Older z/OS LPARs | TLS 1.0+, broader cipher list |
| ⚠️ Dev / self-signed | Test environments | TLS 1.2+, **skip verification (insecure)** |
| ⚙️ Custom | Use settings.json as-is | No preset override |

### 2. Settings (persistent)

```jsonc
"tn3270Bridge.tls.enabled": true,
"tn3270Bridge.tls.minVersion": "TLSv1.2",
"tn3270Bridge.tls.rejectUnauthorized": true,
"tn3270Bridge.tls.caBundle": "C:\\certs\\corp-root-ca.pem",  // if your CA isn't trusted by Windows
"tn3270Bridge.defaultPort": 992
```

### 3. POST /connect with `tls` parameter

```bash
# Boolean shortcut — uses all settings, but forces TLS on
curl.exe -sS -X POST http://127.0.0.1:7327/connect \
  -H 'Content-Type: application/json' \
  -d '{"host":"mfssl.example.com","port":992,"tls":true}'

# Object — override specific knobs for this connection
curl.exe -sS -X POST http://127.0.0.1:7327/connect \
  -H 'Content-Type: application/json' \
  -d '{"host":"...","port":992,"tls":{"enabled":true,"caBundle":"C:/certs/corp.pem"}}'
```

Response includes the TLS info actually negotiated:

```json
{
  "success": true,
  "tls": {
    "enabled": true,
    "version": "TLSv1.2",
    "cipher": "ECDHE-RSA-AES256-GCM-SHA384",
    "authorized": true,
    "peerCertificate": { "subject": "...", "issuer": "...", "validTo": "..." }
  }
}
```

### 4. Per-profile TLS in `loginProfiles`

```jsonc
"tn3270Bridge.loginProfiles": {
  "PROD-SECURE": {
    "host": "mfssl.prod.bank.com",
    "port": 992,
    "tls": { "enabled": true, "minVersion": "TLSv1.2", "caBundle": "C:\\certs\\corp.pem" },
    "steps": [ ... ]
  },
  "DEV-PLAIN": {
    "host": "mfz900acw2",
    "port": 23,
    "steps": [ ... ]
  }
}
```

Then `POST /login {profile:"PROD-SECURE", userid:"..."}` connects with TLS automatically.

### TLS errors translated to action

When TLS fails, the response includes a translated `errorCode` and a `errorHint`:

| errorCode | Hint |
|-----------|------|
| `TLS_SELF_SIGNED` | Self-signed cert — set `rejectUnauthorized=false` for testing or add via `caBundle` |
| `TLS_CA_NOT_TRUSTED` | Signed by a CA not in OS trust store — add `caBundle` with corporate root CA |
| `TLS_CERT_EXPIRED` | Renew the host cert or temporarily bypass |
| `TLS_HOSTNAME_MISMATCH` | Set `sni` to the cert's hostname, or connect by name not IP |
| `TLS_VERSION_MISMATCH` | Server doesn't speak TLS on this port — try 992, or lower `minVersion` |
| `TLS_PROTOCOL_UNSUPPORTED` | Server too old for chosen `minVersion` — try TLSv1.1 or TLSv1 |
| `TLS_NO_CIPHER_MATCH` | No common cipher — configure `ciphers` |
| `CONN_REFUSED` | Wrong host/port |
| `CONN_RESET` | Host hung up — maybe TLS expected but you sent plain |
| `CONN_TIMEOUT` | Network/VPN issue |
| `DNS_NOT_FOUND` | Hostname doesn't resolve |

### Mutual TLS (client certificate)

```jsonc
"tn3270Bridge.tls.clientCert": "C:\\certs\\client.pem",
"tn3270Bridge.tls.clientKey":  "C:\\certs\\client.key",
"tn3270Bridge.tls.passphraseKey": "prod-key"
```

The private-key passphrase goes through VS Code's SecretStorage, not settings.json:
1. `Ctrl+Shift+P` → **TN3270 Bridge: Store TLS Passphrase**
2. Identifier: `prod-key` (matches `passphraseKey` above)
3. Enter the passphrase — stored encrypted by the OS.

---

# TN3270 Bridge 2.2.0 — Bridge API Reference

## MCP parity tools (2.2.0)

The MCP surface includes the existing REST capabilities for fields,
find/table/history/read-all, cursor positioning, named-session lifecycle, and
default connect/disconnect. Existing tools keep their names and behavior.
`mainframe_read_all` and `mainframe_cursor` change navigation state only; they
are not marked as destructive host operations.

## Bridge API (localhost:7327)

The TN3270 bridge exposes a REST API for interacting with a z/OS mainframe via 3270 protocol.

All endpoints except `GET /health` require `Authorization: Bearer <token>` or
`X-TN3270-Token` when `tn3270Bridge.requireApiToken` is enabled. Prefer MCP or
`bridge-cli.js`, which acquire the token over same-user IPC without exposing it.

### Endpoints

```
GET  /status                           Connection status, panelId, cursor, lock
GET  /screen                            Compact screen (default in 1.4.0)
GET  /screen?compact=false              Full 24×80 lines (1.3.x shape)
GET  /screen?nonblank=true              Only non-blank rows as [{row, content}]
GET  /screen/fields                     All fields with positions and content
GET  /screen/text?row=&col=&length=     Text slice
GET  /screen/region?row=&col=&rows=&cols=   Rectangular region
POST /send                              Send text + AID (JSON or form body)
GET  /send?text=&aid=&row=&col=         Same, via query string (shell-safe)
POST /key/<AID>                         Press just an AID (PF1..PF24, ENTER, PA1..PA3, CLEAR)
POST /cursor                            Move cursor locally without pressing a key
POST /wait                              {text} | {type: keyboardUnlock|panel|screenChange}
POST /exec                              {steps: [{send:{...}} | {wait:{...}}]}
POST /login                             Run a configured login profile
GET  /debug                             Diagnostics
```

### POST /send — accepted shapes

JSON body:
```json
{ "text": "3.4", "aid": "ENTER" }
```

Form body (handy in PowerShell/cmd):
```
text=3.4&aid=ENTER
```

GET query (no body):
```
GET /send?text=3.4&aid=ENTER
```

Semantic field resolution (no row/col needed):
```json
{ "fieldName": "OPTION", "text": "3.4", "aid": "ENTER" }
{ "labelLeft": "Dsname Level", "text": "C30T158", "aid": "ENTER" }
{ "labelAbove": "PASSWORD",    "text": "${password}", "aid": "ENTER" }
```

Multi-field login form:
```json
{ "fields": [
    {"labelLeft":"Userid","text":"USERID"},
    {"labelLeft":"Password","text":"PWD"}
  ], "aid": "ENTER" }
```

### POST /send — return shape (1.4.0)

```json
{
  "success": true,
  "lines": ["..."],
  "cursor": {"row": 4, "col": 14},
  "keyboardLocked": false,
  "waitedForUnlock": true,
  "unlocked": true,
  "panelId": "ISR@PRI",
  "panelChanged": true,
  "changedLines": [{"row": 7, "content": "..."}]
}
```

By default (`defaultWaitForUnlock=true`) /send waits for the host to clear the
keyboard lock before returning, so the `lines` you receive are the post-AID
screen. Override per call:

```json
{ "text": "3.4", "aid": "ENTER", "waitForUnlock": false }
{ "aid": "PF3", "waitForUnlock": true, "waitTimeout": 8000 }
```

### POST /key/<AID>

No body needed — just press the key:
```
POST /key/PF3
POST /key/ENTER
POST /key/PA1
```

### POST /cursor

Move cursor to a specific position **without** sending any key to the host.
The cursor address is transmitted as part of the next Read Modified response,
so repositioning it here is sufficient before pressing a key separately.

Accepted shapes:
```json
{ "row": 12, "col": 3 }                        ← absolute 1-based position
{ "field": 2 }                                 ← field index from /screen/fields
{ "fieldName": "OPTION" }                       ← semantic name
{ "labelLeft": "Dsname Level" }                ← label-based
{ "labelAbove": "Command" }                    ← label above field
```

Response:
```json
{ "success": true, "cursor": { "row": 12, "col": 3 } }
```

Typical use — type a line command in SDSF or ISPF editor without using `/send`:
```bash
# Position to the line command area at row 12, col 3
curl.exe -sS -X POST http://127.0.0.1:7327/cursor -H 'Content-Type: application/json' -d '{"row":12,"col":3}'
# Type the command and press ENTER
curl.exe -sS -X POST http://127.0.0.1:7327/send -H 'Content-Type: application/json' -d '{"text":"B","aid":"ENTER"}'
```

Or in one shot using `/send` with row/col:
```bash
curl.exe -sS -X POST http://127.0.0.1:7327/send \
  -H 'Content-Type: application/json' \
  -d '{"row":12,"col":3,"text":"B","aid":"ENTER"}'
```


```json
{ "text": "READY", "timeout": 10000 }                  ← default: match text
{ "type": "keyboardUnlock", "timeout": 5000 }
{ "type": "panel", "panelId": "ISR@PRI", "timeout": 10000 }
{ "type": "screenChange", "timeout": 5000 }
```

### POST /exec — chained operations

```json
{
  "steps": [
    { "send": { "aid": "PF3" } },
    { "wait": { "text": "Primary Option Menu" } },
    { "send": { "fieldName": "OPTION", "text": "3.4", "aid": "ENTER" } },
    { "wait": { "type": "panel", "panelId": "ISRUDLP" } }
  ],
  "stopOnError": true
}
```

A step without `send` or `wait` is treated as a send.

### POST /login — profile-driven login

Configure profiles in VS Code settings:
```jsonc
"tn3270Bridge.loginProfiles": {
  "ACW2": {
    "host": "mfz900acw2", "port": 23,
    "steps": [
      { "waitFor": "Userid",  "fields": [
          {"labelLeft":"Userid","text":"${userid}"},
          {"labelLeft":"Password","text":"${password}"}
        ], "aid": "ENTER" },
      { "waitFor": "Application", "text": "1", "aid": "ENTER" },
      { "waitFor": "***", "aid": "ENTER" },
      { "waitFor": "Primary Option Menu" }
    ]
  }
}
```

Then:
```
POST /login { "profile": "ACW2", "userid": "C30T158" }
```

- Password lookup order: explicit body → SecretStorage (`tn3270.<profile>.password`) → VS Code input box.
- Send `{"savePassword": true}` on first login to store it in SecretStorage.
- The model never sees the password — it goes from input box / secret store straight to the host buffer.

### How to call from PowerShell

PowerShell mangles quoting in `-d`. Pick one:

```powershell
# Option A — form body
Invoke-RestMethod http://127.0.0.1:7327/send -Method POST `
  -ContentType 'application/x-www-form-urlencoded' -Body 'text=3.4&aid=ENTER'

# Option B — GET shortcut
Invoke-RestMethod 'http://127.0.0.1:7327/send?text=3.4&aid=ENTER' -Method POST

# Option C — dedicated key
Invoke-RestMethod http://127.0.0.1:7327/key/PF3 -Method POST

# Option D — JSON via Invoke-RestMethod's serializer (recommended)
Invoke-RestMethod http://127.0.0.1:7327/send -Method POST `
  -ContentType 'application/json' `
  -Body (@{text='3.4'; aid='ENTER'} | ConvertTo-Json)
```

### Critical rules

1. **Default behavior is now wait-for-unlock.** No more sleeps in scripts.
2. **panelId is in /status and /send response.** Use it to confirm where you are.
3. **changedLines tells you what differed** post-send — easier than diffing two screens manually.
4. **Hidden fields** (passwords) return empty content — security guarantee preserved.
5. **Concurrent /send calls are serialized** — agent races on cursor are prevented.

## Navigation Patterns

### Login (EMSP00 → ISPF) — preferred 1.4.0 way

```
POST /login { "profile": "ACW2", "userid": "C30T158" }
```

Manual fallback (when no profile):
```json
POST /send {
  "fields":[
    {"labelLeft":"Userid","text":"C30T158"},
    {"labelLeft":"Password","text":"<pw>"}
  ],
  "aid":"ENTER"
}
POST /send { "text": "1", "aid": "ENTER" }
POST /key/ENTER
```

### ISPF navigation

- **Option field**: `{"fieldName":"OPTION", "text":"3.4", "aid":"ENTER"}`
- **PF3 back**: `POST /key/PF3`
- **Exit to TSO**: `{"fieldName":"OPTION", "text":"=X", "aid":"ENTER"}`
- **Scroll**: `POST /key/PF8` / `POST /key/PF7`

### Dataset List (3.4)

```json
POST /send {
  "labelLeft": "Dsname Level",
  "text": "C30T158",
  "aid": "ENTER"
}
```

### OMVS

```json
POST /send { "fieldName": "OPTION", "text": "6", "aid": "ENTER" }
POST /send { "text": "OMVS", "aid": "ENTER" }
POST /send { "text": "pwd", "aid": "ENTER" }
```

### Logoff

```json
POST /exec {
  "steps": [
    { "send": { "fieldName": "OPTION", "text": "=X", "aid": "ENTER" } },
    { "send": { "text": "LOGOFF", "aid": "ENTER" } },
    { "send": { "text": "LOGOFF", "aid": "ENTER" } }
  ]
}
```

## Troubleshooting

- **"ISPF screen input error - code = 32"**: typed into a protected field. Use `fieldName` / `labelLeft` instead of hard-coded row/col.
- **"Bridge does not support cursor repositioning"**: use `POST /cursor {"row":R,"col":C}` or include `"row"`/`"col"` in the `/send` body. Both reposition the cursor before the next key press.
- **"Screen not updating"**: should be gone in 1.4.0 — /send now waits. If you set `waitForUnlock:false`, you own the wait.
- **Login profile asks for password every time**: pass `"savePassword": true` once.
- **/screen looks different from 1.3.x**: it's now compact by default. Pass `?compact=false` for the legacy shape.

## Changelog

### 1.6.0
- New `POST /cursor` endpoint — reposition cursor without pressing a key
- Accepts `row`+`col`, `field` index, `fieldName`, `labelLeft`, `labelAbove`
- Fixes agent navigation on SDSF rows, ISPF editor, and unformatted screens

### 1.5.0
- TLS/SSL support (port 992) with full cert verification
- Connect via TLS boolean shortcut, per-call object override, or settings
- TLS preset wizard in Command Palette
- Mutual TLS (client certificate + SecretStorage passphrase)
- Error codes translated to actionable hints (TLS_SELF_SIGNED, etc.)

### 1.4.0
- /send waits for keyboard unlock by default
- /screen is compact by default; new `?nonblank=true` shape
- Semantic field resolution: `fieldName`, `labelLeft`, `labelAbove`
- New /key/<AID> endpoint
- /send accepts JSON, form-urlencoded, and GET query string
- panelId detection in /status and /send response
- changedLines diff in /send response
- /wait supports `type: keyboardUnlock|panel|screenChange`
- /exec for chained send/wait steps
- /login with profile-driven scripts and SecretStorage passwords
- Concurrent /send calls are serialized internally
- /screen/region endpoint
